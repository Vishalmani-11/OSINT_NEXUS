# 🔍 OSINT Nexus

> **Educational OSINT learning platform** — professional investigation workspace
> running entirely in Docker. Uses publicly available data only.

---

## ⚡ Quickstart (Docker)

```bash
# 1. Clone
git clone https://github.com/your-org/osint-nexus.git
cd osint-nexus

# 2. Configure (edit passwords + SECRET_KEY)
cp .env.example .env
nano .env

# 3. Launch everything
make setup
# — or without make: —
# docker compose build && docker compose up -d
# docker compose exec backend alembic upgrade head

# 4. (Optional) seed demo data
make seed
```

| URL | Service |
|-----|---------|
| http://localhost:3000 | Frontend (React) |
| http://localhost | Nginx gateway (routes to both) |
| http://localhost:8000/api/v1/docs | API Swagger UI |
| http://localhost:7474 | Neo4j browser |

**Register at http://localhost:3000/register — first account is Admin.**

---

## 🗂️ Features

| Module | What it does |
|--------|-------------|
| **Username OSINT** | Sherlock scan across 400+ platforms → stored in PostgreSQL |
| **Face Analysis** | Local InsightFace / OpenCV — zero external API calls |
| **Case Workspace** | Subjects · Evidence · Notes · Timeline per investigation |
| **Graph Intel** | Neo4j entity graph (Person → Username → Profile → Email) |
| **Dashboard** | Live stats, activity feed, platform distribution charts |
| **Reports** | One-click PDF / HTML / JSON generation via Celery |
| **Audit Log** | Every action logged with user, IP, timestamp |

---

## 🐳 Docker Services

```
osint_nginx          ← Reverse proxy + rate limiting (:80)
osint_frontend       ← Vite React dev server (:3000)
osint_backend        ← FastAPI + Alembic (:8000)
osint_celery_worker  ← Background tasks
osint_celery_beat    ← Scheduled maintenance
osint_postgres       ← Primary datastore (:5432)
osint_redis          ← Broker + cache (:6379)
osint_neo4j          ← Graph DB (:7687 / :7474)
```

---

## 🔧 Common Commands

```bash
make up              # Start
make down            # Stop
make restart         # Restart
make logs            # Tail all logs
make logs-backend    # Backend only
make migrate         # Run Alembic migrations
make seed            # Load demo data
make test            # Run pytest
make test-cov        # With HTML coverage report
make shell           # bash in backend container
make shell-db        # psql in postgres container
make health          # Check /api/v1/health
make clean-all       # Remove everything including volumes ⚠️
```

---

## 📁 Project Structure

```
osint-nexus/
├── backend/
│   ├── app/
│   │   ├── main.py           # FastAPI app + middleware
│   │   ├── config.py         # Pydantic settings
│   │   ├── database.py       # Async SQLAlchemy
│   │   ├── celery_app.py     # All Celery tasks
│   │   ├── models/           # SQLAlchemy ORM models
│   │   ├── schemas/          # Pydantic request/response
│   │   ├── routers/          # FastAPI route handlers
│   │   ├── services/         # Business logic
│   │   └── middleware/       # Security + audit middleware
│   ├── alembic/              # DB migrations
│   ├── scripts/seed.py       # Demo data loader
│   ├── tests/                # pytest suite (~90% coverage target)
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── pages/            # Dashboard, Cases, Username, Face, Graph, Reports
│   │   ├── components/       # Layout, shared UI components
│   │   ├── services/api.js   # Axios + JWT auto-refresh
│   │   ├── store/authStore.js# Zustand auth state
│   │   ├── hooks/            # useAuth, usePolling
│   │   └── utils/helpers.js  # Formatting, validation, CSV export
│   └── Dockerfile
├── nginx/nginx.conf
├── docs/
│   ├── ARCHITECTURE.md       # System design + data flow
│   └── DEPLOYMENT.md         # Full Docker deployment guide
├── docker-compose.yml
├── Makefile
└── .env.example
```

---

## 🔐 Security

- Passwords hashed with **bcrypt** (cost 12)
- JWT **access tokens** expire in 30 min; **refresh tokens** in 7 days
- **Rate limiting** via slowapi (60 req/min API, 10/min auth endpoints)
- Full **audit log** of all mutations in `activity_logs` table
- **RBAC**: Admin / Analyst / Viewer roles
- Face analysis is **strictly local** — embeddings never leave the server
- CORS locked to configured origins
- All Docker services on isolated `osint_net` bridge network

---

## ⚙️ Configuration (`.env`)

| Key | Example | Note |
|-----|---------|------|
| `SECRET_KEY` | `$(openssl rand -hex 32)` | **Required** |
| `POSTGRES_PASSWORD` | `str0ng_pass` | **Required** |
| `REDIS_PASSWORD` | `r3dis_pass` | **Required** |
| `NEO4J_PASSWORD` | `n3o4j_pass` | Min 8 chars, **Required** |
| `ENVIRONMENT` | `development` | Set `production` for hardened mode |

---

## ⚠️ Legal Notice

This tool is for **authorized educational and investigative use only**.
- Always obtain explicit legal permission before investigating any individual or organisation
- Comply with local privacy laws (GDPR, CCPA, etc.)
- All face analysis is local-only — no biometric data leaves your server
- Sherlock username checks query only **publicly accessible** profile URLs
