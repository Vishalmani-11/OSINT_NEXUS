"""Initial migration - create all OSINT Nexus tables

Revision ID: 001_initial
Revises: 
Create Date: 2024-01-01 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '001_initial'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── users ─────────────────────────────────────────────────────
    op.create_table(
        'users',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('uuid', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('email', sa.String(255), nullable=False),
        sa.Column('username', sa.String(50), nullable=False),
        sa.Column('hashed_password', sa.String(255), nullable=False),
        sa.Column('full_name', sa.String(100), nullable=True),
        sa.Column('role', sa.Enum('admin', 'analyst', 'viewer', name='userrole'), nullable=False, server_default='analyst'),
        sa.Column('is_active', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('is_verified', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('avatar_url', sa.String(500), nullable=True),
        sa.Column('bio', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('last_login', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('uuid'),
        sa.UniqueConstraint('email'),
        sa.UniqueConstraint('username'),
    )
    op.create_index('ix_users_email', 'users', ['email'])
    op.create_index('ix_users_username', 'users', ['username'])
    op.create_index('ix_users_email_active', 'users', ['email', 'is_active'])

    # ── cases ─────────────────────────────────────────────────────
    op.create_table(
        'cases',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('uuid', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('title', sa.String(200), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('case_number', sa.String(20), nullable=True),
        sa.Column('status', sa.Enum('open','active','on_hold','closed','archived', name='casestatus'), nullable=False, server_default='open'),
        sa.Column('priority', sa.Enum('low','medium','high','critical', name='casepriority'), nullable=False, server_default='medium'),
        sa.Column('tags', postgresql.JSONB(), nullable=True, server_default='[]'),
        sa.Column('metadata', postgresql.JSONB(), nullable=True, server_default='{}'),
        sa.Column('is_archived', sa.Boolean(), nullable=False, server_default='false'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('closed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_by_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('assigned_to_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('uuid'),
        sa.UniqueConstraint('case_number'),
    )
    op.create_index('ix_cases_title', 'cases', ['title'])
    op.create_index('ix_cases_status_priority', 'cases', ['status', 'priority'])

    # ── subjects ──────────────────────────────────────────────────
    op.create_table(
        'subjects',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('uuid', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('name', sa.String(200), nullable=False),
        sa.Column('aliases', postgresql.JSONB(), nullable=True, server_default='[]'),
        sa.Column('emails', postgresql.JSONB(), nullable=True, server_default='[]'),
        sa.Column('phone_numbers', postgresql.JSONB(), nullable=True, server_default='[]'),
        sa.Column('locations', postgresql.JSONB(), nullable=True, server_default='[]'),
        sa.Column('websites', postgresql.JSONB(), nullable=True, server_default='[]'),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('profile_image_url', sa.String(500), nullable=True),
        sa.Column('metadata', postgresql.JSONB(), nullable=True, server_default='{}'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('case_id', sa.Integer(), sa.ForeignKey('cases.id', ondelete='CASCADE'), nullable=False),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_subjects_name', 'subjects', ['name'])

    # ── username_searches ─────────────────────────────────────────
    op.create_table(
        'username_searches',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('uuid', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('username', sa.String(100), nullable=False),
        sa.Column('status', sa.Enum('pending','running','found','not_found','error','demo', name='usernamestatus'), nullable=False, server_default='pending'),
        sa.Column('celery_task_id', sa.String(255), nullable=True),
        sa.Column('total_checked', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('total_found', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('platforms_found', postgresql.JSONB(), nullable=True, server_default='[]'),
        sa.Column('started_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('case_id', sa.Integer(), sa.ForeignKey('cases.id', ondelete='CASCADE'), nullable=False),
        sa.Column('subject_id', sa.Integer(), sa.ForeignKey('subjects.id', ondelete='SET NULL'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_username_searches_username', 'username_searches', ['username'])

    # ── profiles ──────────────────────────────────────────────────
    op.create_table(
        'profiles',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('platform', sa.String(100), nullable=False),
        sa.Column('url', sa.String(2000), nullable=False),
        sa.Column('username', sa.String(100), nullable=False),
        sa.Column('http_status', sa.Integer(), nullable=True),
        sa.Column('response_time_ms', sa.Integer(), nullable=True),
        sa.Column('is_found', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('metadata', postgresql.JSONB(), nullable=True, server_default='{}'),
        sa.Column('discovered_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('username_search_id', sa.Integer(), sa.ForeignKey('username_searches.id', ondelete='CASCADE'), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('username_search_id', 'platform', name='uq_profile_search_platform'),
    )
    op.create_index('ix_profiles_platform_username', 'profiles', ['platform', 'username'])

    # ── face_embeddings ───────────────────────────────────────────
    op.create_table(
        'face_embeddings',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('uuid', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('image_filename', sa.String(500), nullable=False),
        sa.Column('image_path', sa.String(1000), nullable=False),
        sa.Column('thumbnail_path', sa.String(1000), nullable=True),
        sa.Column('embedding', postgresql.JSONB(), nullable=True),
        sa.Column('embedding_model', sa.String(50), nullable=True, server_default='buffalo_l'),
        sa.Column('face_count', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('face_index', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('bbox', postgresql.JSONB(), nullable=True),
        sa.Column('confidence', sa.Float(), nullable=True),
        sa.Column('estimated_age', sa.Integer(), nullable=True),
        sa.Column('estimated_gender', sa.String(10), nullable=True),
        sa.Column('landmarks', postgresql.JSONB(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('is_reference', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('case_id', sa.Integer(), sa.ForeignKey('cases.id', ondelete='CASCADE'), nullable=False),
        sa.Column('subject_id', sa.Integer(), sa.ForeignKey('subjects.id', ondelete='SET NULL'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )

    # ── face_matches ──────────────────────────────────────────────
    op.create_table(
        'face_matches',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('similarity_score', sa.Float(), nullable=False),
        sa.Column('is_match', sa.Boolean(), nullable=False),
        sa.Column('threshold_used', sa.Float(), nullable=False),
        sa.Column('compared_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('query_id', sa.Integer(), sa.ForeignKey('face_embeddings.id', ondelete='CASCADE'), nullable=True),
        sa.Column('match_id', sa.Integer(), sa.ForeignKey('face_embeddings.id', ondelete='CASCADE'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )

    # ── evidence ──────────────────────────────────────────────────
    op.create_table(
        'evidence',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('uuid', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('title', sa.String(300), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('evidence_type', sa.Enum('image','screenshot','document','url','note','other', name='evidencetype'), nullable=False),
        sa.Column('file_path', sa.String(1000), nullable=True),
        sa.Column('file_name', sa.String(500), nullable=True),
        sa.Column('file_size', sa.BigInteger(), nullable=True),
        sa.Column('mime_type', sa.String(100), nullable=True),
        sa.Column('url', sa.String(2000), nullable=True),
        sa.Column('source', sa.String(500), nullable=True),
        sa.Column('hash_sha256', sa.String(64), nullable=True),
        sa.Column('tags', postgresql.JSONB(), nullable=True, server_default='[]'),
        sa.Column('metadata', postgresql.JSONB(), nullable=True, server_default='{}'),
        sa.Column('collected_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('is_sensitive', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('case_id', sa.Integer(), sa.ForeignKey('cases.id', ondelete='CASCADE'), nullable=False),
        sa.Column('subject_id', sa.Integer(), sa.ForeignKey('subjects.id', ondelete='SET NULL'), nullable=True),
        sa.Column('uploaded_by_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )

    # ── notes ─────────────────────────────────────────────────────
    op.create_table(
        'notes',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('content', sa.Text(), nullable=False),
        sa.Column('is_pinned', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('case_id', sa.Integer(), sa.ForeignKey('cases.id', ondelete='CASCADE'), nullable=False),
        sa.Column('author_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )

    # ── reports ───────────────────────────────────────────────────
    op.create_table(
        'reports',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('uuid', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('title', sa.String(300), nullable=False),
        sa.Column('format', sa.Enum('pdf','html','json', name='reportformat'), nullable=False),
        sa.Column('status', sa.Enum('pending','generating','completed','failed', name='reportstatus'), nullable=False, server_default='pending'),
        sa.Column('file_path', sa.String(1000), nullable=True),
        sa.Column('file_size', sa.BigInteger(), nullable=True),
        sa.Column('celery_task_id', sa.String(255), nullable=True),
        sa.Column('include_summary', sa.Boolean(), nullable=True, server_default='true'),
        sa.Column('include_evidence', sa.Boolean(), nullable=True, server_default='true'),
        sa.Column('include_timeline', sa.Boolean(), nullable=True, server_default='true'),
        sa.Column('include_graph', sa.Boolean(), nullable=True, server_default='true'),
        sa.Column('sections', postgresql.JSONB(), nullable=True, server_default='{}'),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('case_id', sa.Integer(), sa.ForeignKey('cases.id', ondelete='CASCADE'), nullable=False),
        sa.Column('generated_by_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )

    # ── activity_logs ─────────────────────────────────────────────
    op.create_table(
        'activity_logs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('action', sa.Enum('login','logout','create','read','update','delete','search','upload','download','generate', name='activityaction'), nullable=False),
        sa.Column('resource_type', sa.String(50), nullable=True),
        sa.Column('resource_id', sa.Integer(), nullable=True),
        sa.Column('details', postgresql.JSONB(), nullable=True, server_default='{}'),
        sa.Column('ip_address', sa.String(45), nullable=True),
        sa.Column('user_agent', sa.String(500), nullable=True),
        sa.Column('status_code', sa.Integer(), nullable=True),
        sa.Column('success', sa.Boolean(), nullable=True, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('user_id', sa.Integer(), sa.ForeignKey('users.id', ondelete='SET NULL'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_index('ix_activity_logs_user_action', 'activity_logs', ['user_id', 'action'])
    op.create_index('ix_activity_logs_created_at', 'activity_logs', ['created_at'])


def downgrade() -> None:
    op.drop_table('activity_logs')
    op.drop_table('reports')
    op.drop_table('notes')
    op.drop_table('evidence')
    op.drop_table('face_matches')
    op.drop_table('face_embeddings')
    op.drop_table('profiles')
    op.drop_table('username_searches')
    op.drop_table('subjects')
    op.drop_table('cases')
    op.drop_table('users')

    # Drop enums
    for enum in ['userrole','casestatus','casepriority','usernamestatus',
                 'evidencetype','reportformat','reportstatus','activityaction']:
        op.execute(f"DROP TYPE IF EXISTS {enum}")
