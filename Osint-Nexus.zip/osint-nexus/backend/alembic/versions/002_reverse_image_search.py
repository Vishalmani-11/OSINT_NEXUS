"""Add image_searches, drop face_embeddings and face_matches

Revision ID: 002_reverse_image_search
Revises: 001_initial
Create Date: 2024-07-01

Replaces the local InsightFace face-embedding approach with a reverse
image search model that stores uploaded images + web search results
instead of biometric embeddings.
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '002_reverse_image_search'
down_revision = '001_initial'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── Drop old face tables (local biometric, replaced by web search) ──
    op.drop_table('face_matches')
    op.drop_table('face_embeddings')

    # ── Create new image_searches table ────────────────────────────────
    op.create_table(
        'image_searches',
        sa.Column('id',         sa.Integer(), nullable=False),
        sa.Column('uuid',       postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('filename',   sa.String(500), nullable=False),
        sa.Column('image_path', sa.String(1000), nullable=False),
        sa.Column('file_hash',  sa.String(64), nullable=True),
        sa.Column('file_size',  sa.BigInteger(), nullable=True),
        sa.Column('image_width',  sa.Integer(), nullable=True),
        sa.Column('image_height', sa.Integer(), nullable=True),
        sa.Column('mime_type',    sa.String(100), nullable=True),
        # EXIF / GPS metadata extracted from the image
        sa.Column('exif_data',  postgresql.JSONB(), nullable=True, server_default='{}'),
        # Deep-link URLs the analyst can open in a browser
        sa.Column('search_links', postgresql.JSONB(), nullable=True, server_default='{}'),
        # Structured results returned by optional API keys (SerpAPI / TinEye)
        sa.Column('api_results',    postgresql.JSONB(), nullable=True, server_default='[]'),
        sa.Column('total_found',    sa.Integer(), nullable=True, server_default='0'),
        sa.Column('engines_searched', postgresql.JSONB(), nullable=True, server_default='[]'),
        sa.Column('search_duration_ms', sa.Integer(), nullable=True),
        sa.Column('serpapi_used', sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('tineye_used',  sa.Boolean(), nullable=True, server_default='false'),
        sa.Column('status',         sa.String(20), nullable=True, server_default="'pending'"),
        sa.Column('error_message',  sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True),
                  server_default=sa.text('now()'), nullable=True),
        # Foreign keys
        sa.Column('case_id', sa.Integer(),
                  sa.ForeignKey('cases.id', ondelete='CASCADE'), nullable=False),
        sa.Column('subject_id', sa.Integer(),
                  sa.ForeignKey('subjects.id', ondelete='SET NULL'), nullable=True),
        sa.Column('uploaded_by_id', sa.Integer(),
                  sa.ForeignKey('users.id'), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('uuid'),
    )
    op.create_index('ix_image_searches_case_id',   'image_searches', ['case_id'])
    op.create_index('ix_image_searches_file_hash',  'image_searches', ['file_hash'])


def downgrade() -> None:
    op.drop_table('image_searches')

    # Re-create face tables on downgrade
    op.create_table(
        'face_embeddings',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('uuid', postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column('image_filename', sa.String(500), nullable=False),
        sa.Column('image_path', sa.String(1000), nullable=False),
        sa.Column('thumbnail_path', sa.String(1000), nullable=True),
        sa.Column('embedding', postgresql.JSONB(), nullable=True),
        sa.Column('embedding_model', sa.String(50), nullable=True),
        sa.Column('face_count', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('face_index', sa.Integer(), nullable=True, server_default='0'),
        sa.Column('bbox', postgresql.JSONB(), nullable=True),
        sa.Column('confidence', sa.Float(), nullable=True),
        sa.Column('estimated_age', sa.Integer(), nullable=True),
        sa.Column('estimated_gender', sa.String(10), nullable=True),
        sa.Column('landmarks', postgresql.JSONB(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('is_reference', sa.Boolean(), server_default='false'),
        sa.Column('case_id', sa.Integer(), sa.ForeignKey('cases.id', ondelete='CASCADE'), nullable=False),
        sa.Column('subject_id', sa.Integer(), sa.ForeignKey('subjects.id', ondelete='SET NULL')),
        sa.PrimaryKeyConstraint('id'),
    )
    op.create_table(
        'face_matches',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('similarity_score', sa.Float(), nullable=False),
        sa.Column('is_match', sa.Boolean(), nullable=False),
        sa.Column('threshold_used', sa.Float(), nullable=False),
        sa.Column('compared_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('query_id', sa.Integer(), sa.ForeignKey('face_embeddings.id', ondelete='CASCADE')),
        sa.Column('match_id', sa.Integer(), sa.ForeignKey('face_embeddings.id', ondelete='CASCADE')),
        sa.PrimaryKeyConstraint('id'),
    )
