"""
OSINT Nexus - Celery Application & Background Tasks
Async task queue for username scans, face processing, report generation, and graph updates.
"""
import asyncio
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from celery import Celery
from celery.signals import worker_ready

from app.config import settings

logger = logging.getLogger(__name__)

# ── Celery Application ────────────────────────────────────────────────────────
celery_app = Celery(
    "osint_nexus",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_soft_time_limit=300,    # 5 min soft limit
    task_time_limit=600,          # 10 min hard limit
    task_max_retries=3,
    task_default_retry_delay=60,  # 1 min between retries
    result_expires=86400,         # Keep results 24 hours
    # When True (e.g. CELERY_TASK_ALWAYS_EAGER=true), tasks run synchronously
    # in-process instead of being dispatched to the broker — useful for local
    # debugging without Redis running. Exceptions propagate immediately rather
    # than being swallowed, which is what you want when eager.
    task_always_eager=settings.CELERY_TASK_ALWAYS_EAGER,
    task_eager_propagates=settings.CELERY_TASK_ALWAYS_EAGER,
    beat_schedule={
        "cleanup-old-activity-logs": {
            "task": "app.celery_app.cleanup_old_logs",
            "schedule": 86400.0,  # Daily
        },
    },
)


# ── Sync DB helper (Celery is synchronous) ────────────────────────────────────
def get_sync_session():
    """Get a synchronous SQLAlchemy session for Celery tasks."""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    engine = create_engine(settings.SYNC_DATABASE_URL, pool_pre_ping=True)
    Session = sessionmaker(bind=engine)
    return Session()


def run_async(coro):
    """Run an async coroutine from a synchronous Celery task."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


# ════════════════════════════════════════════════════════════════════
# USERNAME SCAN TASKS
# ════════════════════════════════════════════════════════════════════

@celery_app.task(bind=True, name="app.celery_app.run_username_scan", max_retries=2)
def run_username_scan(self, search_id: int, username: str, case_id: int):
    """
    Background task to run a Sherlock username scan.
    Updates the UsernameSearch record and Profile records as results come in.
    """
    logger.info("Starting username scan task: @%s (search_id=%d)", username, search_id)
    db = get_sync_session()

    try:
        from app.models import UsernameSearch, Profile, UsernameStatus
        from app.services.sherlock import sherlock_service

        # Mark as running
        search = db.query(UsernameSearch).filter(UsernameSearch.id == search_id).first()
        if not search:
            logger.error("UsernameSearch %d not found", search_id)
            return {"error": "Search record not found"}

        search.status = UsernameStatus.RUNNING
        search.started_at = datetime.utcnow()
        search.celery_task_id = self.request.id
        db.commit()

        # Run the actual Sherlock scan
        results = run_async(sherlock_service.search(username))

        found_platforms = []
        profiles_to_add = []

        for result in results:
            profile = Profile(
                username_search_id=search_id,
                platform=result.platform,
                url=result.url,
                username=result.username,
                is_found=result.is_found,
                http_status=result.http_status,
                response_time_ms=result.response_time_ms,
            )
            profiles_to_add.append(profile)
            if result.is_found:
                found_platforms.append(result.platform)

        # Bulk insert profiles
        db.bulk_save_objects(profiles_to_add)

        # Update search record
        search.status = UsernameStatus.FOUND if found_platforms else UsernameStatus.NOT_FOUND
        search.total_checked = len(results)
        search.total_found = len(found_platforms)
        search.platforms_found = found_platforms
        search.completed_at = datetime.utcnow()
        db.commit()

        # Trigger graph update
        update_graph_for_username.delay(search_id=search_id)

        logger.info(
            "Username scan complete: @%s → %d/%d found",
            username, len(found_platforms), len(results)
        )
        return {
            "search_id": search_id,
            "username": username,
            "total_checked": len(results),
            "total_found": len(found_platforms),
            "platforms_found": found_platforms,
        }

    except Exception as exc:
        logger.error("Username scan failed for @%s: %s", username, exc)
        db.rollback()
        try:
            from app.models import UsernameSearch, UsernameStatus
            search = db.query(UsernameSearch).filter(UsernameSearch.id == search_id).first()
            if search:
                search.status = UsernameStatus.ERROR
                search.error_message = str(exc)
                search.completed_at = datetime.utcnow()
                db.commit()
        except Exception:
            pass
        raise self.retry(exc=exc, countdown=30)
    finally:
        db.close()


# ════════════════════════════════════════════════════════════════════
# REPORT GENERATION TASKS
# ════════════════════════════════════════════════════════════════════

@celery_app.task(bind=True, name="app.celery_app.generate_report", max_retries=1)
def generate_report(self, report_id: int):
    """
    Background task to generate an investigation report (PDF/HTML/JSON).
    Assembles all case data and renders the report file.
    """
    logger.info("Generating report: report_id=%d", report_id)
    db = get_sync_session()

    try:
        from app.models import (
            Report, ReportStatus, ReportFormat,
            Case, Subject, UsernameSearch, Profile,
            ImageSearch, Evidence, Note
        )
        from app.services.reporting import reporting_service

        report = db.query(Report).filter(Report.id == report_id).first()
        if not report:
            return {"error": "Report not found"}

        report.status = ReportStatus.GENERATING
        report.celery_task_id = self.request.id
        db.commit()

        case = db.query(Case).filter(Case.id == report.case_id).first()
        if not case:
            raise ValueError(f"Case {report.case_id} not found")

        # Gather all case data
        subjects = db.query(Subject).filter(Subject.case_id == case.id).all()

        username_searches = (
            db.query(UsernameSearch)
            .filter(UsernameSearch.case_id == case.id)
            .all()
        )
        for search in username_searches:
            search.profiles  # Load profiles relationship

        evidence       = db.query(Evidence).filter(Evidence.case_id == case.id).all()
        notes          = db.query(Note).filter(Note.case_id == case.id).all()
        image_searches = db.query(ImageSearch).filter(ImageSearch.case_id == case.id).all()

        # Build report data dict
        report_data = {
            "report": {
                "id": report.id,
                "title": report.title,
                "format": report.format.value,
            },
            "case": {
                "id": case.id,
                "title": case.title,
                "case_number": case.case_number or f"CASE-{case.id:04d}",
                "description": case.description,
                "status": case.status.value,
                "priority": case.priority.value,
                "created_at": case.created_at,
            },
            "stats": {
                "subjects": len(subjects),
                "username_searches": len(username_searches),
                "profiles_found": sum(s.total_found or 0 for s in username_searches),
                "image_searches": len(image_searches),
                "image_results": sum(s.total_found or 0 for s in image_searches),
                "evidence_items": len(evidence),
                "notes": len(notes),
            },
            "subjects": [
                {
                    "name": s.name,
                    "aliases": s.aliases or [],
                    "emails": s.emails or [],
                }
                for s in subjects
            ],
            "username_searches": [
                {
                    "username": s.username,
                    "total_checked": s.total_checked or 0,
                    "total_found": s.total_found or 0,
                    "profiles": [
                        {
                            "platform": p.platform,
                            "url": p.url,
                            "is_found": p.is_found,
                            "http_status": p.http_status,
                        }
                        for p in (s.profiles or [])
                    ],
                }
                for s in username_searches
            ],
            "evidence": [
                {
                    "title": e.title,
                    "description": e.description,
                    "evidence_type": e.evidence_type.value,
                    "url": e.url,
                    "tags": e.tags or [],
                }
                for e in evidence
            ],
            "notes": [
                {
                    "content": n.content,
                    "created_at": n.created_at,
                }
                for n in notes
            ],
            "include_summary": report.include_summary,
            "include_evidence": report.include_evidence,
            "include_timeline": report.include_timeline,
        }

        # Generate the report file
        output_path = reporting_service.get_output_path(str(report.uuid), report.format.value)

        if report.format == ReportFormat.PDF:
            success = run_async(reporting_service.generate_pdf(report_data, output_path))
        elif report.format == ReportFormat.HTML:
            success = run_async(reporting_service.generate_html(report_data, output_path))
        else:  # JSON
            success = run_async(reporting_service.generate_json(report_data, output_path))

        if success and Path(output_path).exists():
            report.status = ReportStatus.COMPLETED
            report.file_path = output_path
            report.file_size = Path(output_path).stat().st_size
            report.completed_at = datetime.utcnow()
        else:
            report.status = ReportStatus.FAILED
            report.error_message = "Report file was not created"

        db.commit()
        logger.info("Report %d generation %s", report_id, report.status.value)
        return {"report_id": report_id, "status": report.status.value, "path": output_path}

    except Exception as exc:
        logger.error("Report generation failed for report_id=%d: %s", report_id, exc)
        db.rollback()
        try:
            from app.models import Report, ReportStatus
            report = db.query(Report).filter(Report.id == report_id).first()
            if report:
                report.status = ReportStatus.FAILED
                report.error_message = str(exc)[:500]
                db.commit()
        except Exception:
            pass
        raise
    finally:
        db.close()


# ════════════════════════════════════════════════════════════════════
# GRAPH UPDATE TASKS
# ════════════════════════════════════════════════════════════════════

@celery_app.task(name="app.celery_app.update_graph_for_username")
def update_graph_for_username(search_id: int):
    """Update Neo4j graph after a username search completes."""
    db = get_sync_session()
    try:
        from app.models import UsernameSearch, Subject
        from app.services.graph import graph_service

        search = db.query(UsernameSearch).filter(UsernameSearch.id == search_id).first()
        if not search:
            return

        subject = None
        if search.subject_id:
            subject = db.query(Subject).filter(Subject.id == search.subject_id).first()

        if subject:
            # Link username to person in graph
            run_async(graph_service.link_username(
                subject_id=subject.id,
                username=search.username,
                platform="multi-platform",
            ))

            # Link each found profile
            if search.profiles:
                for profile in search.profiles:
                    if profile.is_found:
                        run_async(graph_service.link_social_profile(
                            username=search.username,
                            platform=profile.platform,
                            profile_url=profile.url,
                        ))

        logger.info("Graph updated for username search: @%s", search.username)

    except Exception as e:
        logger.error("Graph update failed for search_id=%d: %s", search_id, e)
    finally:
        db.close()


@celery_app.task(name="app.celery_app.update_graph_for_subject")
def update_graph_for_subject(subject_id: int, case_id: int):
    """Create/update graph nodes for a subject and their known data."""
    db = get_sync_session()
    try:
        from app.models import Subject
        from app.services.graph import graph_service

        subject = db.query(Subject).filter(Subject.id == subject_id).first()
        if not subject:
            return

        # Create person node
        run_async(graph_service.create_person(
            subject_id=subject_id,
            name=subject.name,
            case_id=case_id,
        ))

        # Link emails
        for email in (subject.emails or []):
            run_async(graph_service.link_email(subject_id, email))

        # Link websites
        for website in (subject.websites or []):
            run_async(graph_service.link_website(subject_id, website))

        logger.info("Graph updated for subject: %s", subject.name)

    except Exception as e:
        logger.error("Subject graph update failed: %s", e)
    finally:
        db.close()


# ════════════════════════════════════════════════════════════════════
# MAINTENANCE TASKS
# ════════════════════════════════════════════════════════════════════

@celery_app.task(name="app.celery_app.cleanup_old_logs")
def cleanup_old_logs():
    """Remove activity logs older than 90 days."""
    db = get_sync_session()
    try:
        from app.models import ActivityLog
        from datetime import timedelta

        cutoff = datetime.utcnow() - timedelta(days=90)
        deleted = (
            db.query(ActivityLog)
            .filter(ActivityLog.created_at < cutoff)
            .delete(synchronize_session=False)
        )
        db.commit()
        logger.info("Cleaned up %d old activity log entries", deleted)
        return {"deleted": deleted}
    except Exception as e:
        logger.error("Log cleanup failed: %s", e)
        db.rollback()
    finally:
        db.close()


@worker_ready.connect
def on_worker_ready(sender, **kwargs):
    """Initialize resources when Celery worker starts."""
    logger.info("🚀 OSINT Nexus Celery worker ready")
