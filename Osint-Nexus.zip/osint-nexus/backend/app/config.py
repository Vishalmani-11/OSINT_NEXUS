"""
OSINT Nexus - Application Configuration
All settings loaded from environment variables with defaults for development.
"""
from functools import lru_cache
from typing import List, Optional
from pydantic import field_validator, AnyHttpUrl
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # ── Application ──────────────────────────────────────────────
    APP_NAME: str = "OSINT Nexus"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: str = "development"
    DEBUG: bool = False
    API_V1_PREFIX: str = "/api/v1"

    # ── Database ─────────────────────────────────────────────────
    DATABASE_URL: str = (
        "postgresql+asyncpg://osint:osint_secure_pass@localhost:5432/osint_nexus"
    )
    SYNC_DATABASE_URL: str = (
        "postgresql://osint:osint_secure_pass@localhost:5432/osint_nexus"
    )
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 20
    DB_POOL_TIMEOUT: int = 30

    # ── Redis ─────────────────────────────────────────────────────
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_CACHE_TTL: int = 3600  # 1 hour

    # ── Neo4j ─────────────────────────────────────────────────────
    NEO4J_URL: str = "bolt://localhost:7687"
    NEO4J_USER: str = "neo4j"
    NEO4J_PASSWORD: str = "neo4j_secure_pass"
    NEO4J_DATABASE: str = "neo4j"

    # ── JWT Authentication ────────────────────────────────────────
    SECRET_KEY: str = "change-this-to-a-random-256-bit-key-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # ── CORS ──────────────────────────────────────────────────────
    CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
    ]

    # ── File Uploads ─────────────────────────────────────────────
    UPLOAD_DIR: str = "./uploads"
    MAX_UPLOAD_SIZE_MB: int = 10
    ALLOWED_IMAGE_TYPES: List[str] = [
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
        "image/bmp",
    ]

    # ── Rate Limiting ─────────────────────────────────────────────
    RATE_LIMIT_PER_MINUTE: int = 60
    RATE_LIMIT_BURST: int = 10

    # ── Celery ────────────────────────────────────────────────────
    CELERY_BROKER_URL: str = "redis://localhost:6379/0"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/0"
    CELERY_TASK_ALWAYS_EAGER: bool = False  # Set True in testing

    # ── Sherlock ──────────────────────────────────────────────────
    SHERLOCK_TIMEOUT: int = 60  # seconds per platform check
    SHERLOCK_MAX_CONCURRENT: int = 20
    SHERLOCK_DEMO_MODE: bool = False  # Use demo data when Sherlock unavailable

    # ── Face Analysis ─────────────────────────────────────────────
    FACE_SIMILARITY_THRESHOLD: float = 0.6  # Minimum score for a match
    FACE_MODEL_NAME: str = "buffalo_l"
    INSIGHTFACE_CTX_ID: int = 0  # CPU=-1, GPU=0..n

    # ── Reporting ─────────────────────────────────────────────────
    REPORTS_DIR: str = "./uploads/reports"

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def parse_cors_origins(cls, v):
        if isinstance(v, str):
            import json
            return json.loads(v)
        return v

    @property
    def max_upload_size_bytes(self) -> int:
        return self.MAX_UPLOAD_SIZE_MB * 1024 * 1024

    @property
    def is_development(self) -> bool:
        return self.ENVIRONMENT == "development"

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == "production"

    model_config = {
        "env_file": ".env",
        "case_sensitive": True,
        "extra": "ignore",
    }


@lru_cache()
def get_settings() -> Settings:
    """Cached settings instance – call this everywhere."""
    return Settings()


# Convenience singleton
settings = get_settings()
