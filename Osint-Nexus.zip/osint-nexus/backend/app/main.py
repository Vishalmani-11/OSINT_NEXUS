"""
OSINT Nexus - FastAPI Application Entry Point
Full middleware stack, all routers, startup / shutdown lifecycle.
"""
import logging
import os
import time
from contextlib import asynccontextmanager

import redis.asyncio as aioredis
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from app.config import settings
from app.database import engine, check_database_health
from app.middleware import (
    RequestIDMiddleware,
    SecurityHeadersMiddleware,
    AuditLoggingMiddleware,
)

logging.basicConfig(
    level=logging.DEBUG if settings.DEBUG else logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ── Rate limiter ──────────────────────────────────────────────────
limiter = Limiter(key_func=get_remote_address, default_limits=[f"{settings.RATE_LIMIT_PER_MINUTE}/minute"])


# ── Lifespan ──────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 OSINT Nexus v%s starting…", settings.APP_VERSION)

    # PostgreSQL
    if await check_database_health():
        logger.info("✓ PostgreSQL connected")
    else:
        logger.error("✗ PostgreSQL unreachable — check DATABASE_URL")

    # Redis
    try:
        rc = aioredis.from_url(settings.REDIS_URL, socket_connect_timeout=3)
        await rc.ping()
        await rc.close()
        logger.info("✓ Redis connected")
    except Exception as exc:
        logger.warning("⚠ Redis unavailable: %s", exc)

    # Neo4j schema
    try:
        from app.services.graph import graph_service
        connected = await graph_service.setup_schema()
        if connected:
            logger.info("✓ Neo4j schema ready")
        else:
            logger.warning("⚠ Neo4j unreachable — graph features will use demo/mock data")
    except Exception as exc:
        logger.warning("⚠ Neo4j schema skipped: %s", exc)

    # Upload dirs
    for sub in ("faces", "evidence", "reports", "thumbnails"):
        os.makedirs(os.path.join(settings.UPLOAD_DIR, sub), exist_ok=True)

    logger.info("✅ Ready → http://0.0.0.0:8000")
    yield

    # Shutdown
    logger.info("🔄 Shutting down…")
    try:
        from app.services.graph import graph_service
        await graph_service.close()
    except Exception:
        pass
    await engine.dispose()
    logger.info("✓ Shutdown complete")


# ── Application ───────────────────────────────────────────────────
app = FastAPI(
    title="OSINT Nexus API",
    description="""
## 🔍 OSINT Nexus — Educational Intelligence Platform

Professional-grade investigation platform for learning OSINT using **publicly available data only**.

### Modules
- **Username OSINT** — Sherlock-powered social platform discovery
- **Reverse Image Search** — Google, Yandex, TinEye, Bing links + optional API results
- **Case Workspace** — Evidence, notes, subjects, timeline
- **Graph Intel** — Neo4j entity relationships
- **Reports** — PDF, HTML, JSON generation

### Auth
All endpoints require `Authorization: Bearer <access_token>`.
Obtain a token via `POST /api/v1/auth/login`.

> ⚠️ **Authorized use only.** Always obtain legal permission before investigating anyone.
    """,
    version=settings.APP_VERSION,
    docs_url=f"{settings.API_V1_PREFIX}/docs",
    redoc_url=f"{settings.API_V1_PREFIX}/redoc",
    openapi_url=f"{settings.API_V1_PREFIX}/openapi.json",
    lifespan=lifespan,
    contact={"name": "OSINT Nexus", "url": "https://github.com/your-org/osint-nexus"},
    license_info={"name": "MIT"},
)

# ── Middleware stack (outermost first) ────────────────────────────
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(AuditLoggingMiddleware)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(RequestIDMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["X-Request-ID", "X-Process-Time"],
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


@app.middleware("http")
async def add_timing_header(request: Request, call_next):
    t0 = time.perf_counter()
    response = await call_next(request)
    response.headers["X-Process-Time"] = f"{(time.perf_counter()-t0)*1000:.1f}ms"
    return response


# ── Global error handler ──────────────────────────────────────────
@app.exception_handler(Exception)
async def global_handler(request: Request, exc: Exception):
    logger.error("Unhandled %s: %s | %s %s", type(exc).__name__, exc, request.method, request.url)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "Internal server error — see server logs for details."},
    )


# ── Routers ───────────────────────────────────────────────────────
from app.routers.auth import router as auth_router
from app.routers.cases import router as cases_router
from app.routers import (
    username_router,
    images_router,
    reports_router,
    graph_router,
    dashboard_router,
)

P = settings.API_V1_PREFIX

app.include_router(auth_router,      prefix=P)
app.include_router(cases_router,     prefix=P)
app.include_router(username_router,  prefix=P)
app.include_router(images_router,   prefix=P)
app.include_router(reports_router,   prefix=P)
app.include_router(graph_router,     prefix=P)
app.include_router(dashboard_router, prefix=P)


# ── Health ────────────────────────────────────────────────────────
@app.get(f"{P}/health", tags=["System"], summary="Service health check")
async def health():
    from app.schemas import HealthResponse

    db_ok = await check_database_health()

    redis_ok = False
    try:
        rc = aioredis.from_url(settings.REDIS_URL, socket_connect_timeout=2)
        await rc.ping(); await rc.close()
        redis_ok = True
    except Exception:
        pass

    neo4j_ok = False
    try:
        from app.services.graph import graph_service
        neo4j_ok = (await graph_service.get_driver()) is not None
    except Exception:
        pass

    overall = "healthy" if db_ok else "degraded"
    return HealthResponse(
        status=overall, version=settings.APP_VERSION,
        database=db_ok, redis=redis_ok, neo4j=neo4j_ok,
        environment=settings.ENVIRONMENT,
    )


@app.get("/", include_in_schema=False)
async def root():
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "docs": f"{P}/docs",
        "health": f"{P}/health",
        "notice": "For authorized educational use only",
    }
