"""
OSINT Nexus - Security Middleware
Rate limiting, audit logging, and request ID injection.
"""
import time
import uuid
import logging
from typing import Callable

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Attach a unique X-Request-ID to every request/response."""
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())[:8]
        request.state.request_id = request_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Add hardened security headers to every response."""
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Cache-Control"] = "no-store"
        return response


class AuditLoggingMiddleware(BaseHTTPMiddleware):
    """Log all mutating API requests for compliance audit trail."""
    SKIP_PATHS = {"/api/v1/health", "/", "/favicon.ico"}
    SKIP_METHODS = {"GET", "HEAD", "OPTIONS"}

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        start = time.perf_counter()
        response = await call_next(request)
        duration_ms = int((time.perf_counter() - start) * 1000)
        path, method = request.url.path, request.method

        if method not in self.SKIP_METHODS and path not in self.SKIP_PATHS:
            user_id    = getattr(request.state, "user_id", None)
            request_id = getattr(request.state, "request_id", "—")
            logger.info(
                "AUDIT | %s %s | status=%d | user=%s | %dms | req=%s",
                method, path, response.status_code,
                user_id or "anon", duration_ms, request_id,
            )
        return response
