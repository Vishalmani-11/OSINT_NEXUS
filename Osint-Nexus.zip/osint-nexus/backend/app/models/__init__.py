"""
OSINT Nexus - SQLAlchemy ORM Models
Complete data model definitions for all entities in the system.
"""
from datetime import datetime
from typing import Optional, List
import enum
import uuid

from sqlalchemy import (
    Column, Integer, String, Text, Boolean, DateTime, Float,
    ForeignKey, JSON, Enum, BigInteger, LargeBinary, Index,
    UniqueConstraint, func
)
from sqlalchemy.orm import relationship, Mapped, mapped_column
from app.models.types import GUID, PortableJSON

from app.database import Base


# ════════════════════════════════════════════════════════════════════
# ENUMERATIONS
# ════════════════════════════════════════════════════════════════════

class UserRole(str, enum.Enum):
    ADMIN = "admin"
    ANALYST = "analyst"
    VIEWER = "viewer"


class CaseStatus(str, enum.Enum):
    OPEN = "open"
    ACTIVE = "active"
    ON_HOLD = "on_hold"
    CLOSED = "closed"
    ARCHIVED = "archived"


class CasePriority(str, enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class UsernameStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    FOUND = "found"
    NOT_FOUND = "not_found"
    ERROR = "error"
    DEMO = "demo"


class EvidenceType(str, enum.Enum):
    IMAGE = "image"
    SCREENSHOT = "screenshot"
    DOCUMENT = "document"
    URL = "url"
    NOTE = "note"
    OTHER = "other"


class ReportFormat(str, enum.Enum):
    PDF = "pdf"
    HTML = "html"
    JSON = "json"


class ReportStatus(str, enum.Enum):
    PENDING = "pending"
    GENERATING = "generating"
    COMPLETED = "completed"
    FAILED = "failed"


class ActivityAction(str, enum.Enum):
    LOGIN = "login"
    LOGOUT = "logout"
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    SEARCH = "search"
    UPLOAD = "upload"
    DOWNLOAD = "download"
    GENERATE = "generate"


# ════════════════════════════════════════════════════════════════════
# USER MODEL
# ════════════════════════════════════════════════════════════════════

class User(Base):
    """Authenticated user of the OSINT platform."""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    uuid = Column(GUID(), default=uuid.uuid4, unique=True, nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    username = Column(String(50), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(100))
    role = Column(Enum(UserRole, values_callable=lambda obj: [e.value for e in obj]), default=UserRole.ANALYST, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_verified = Column(Boolean, default=False, nullable=False)
    avatar_url = Column(String(500))
    bio = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    last_login = Column(DateTime(timezone=True))

    # Relationships
    cases = relationship("Case", back_populates="created_by", foreign_keys="Case.created_by_id")
    assigned_cases = relationship("Case", back_populates="assigned_to", foreign_keys="Case.assigned_to_id")
    activity_logs = relationship("ActivityLog", back_populates="user")
    reports = relationship("Report", back_populates="generated_by")

    __table_args__ = (
        Index('ix_users_email_active', 'email', 'is_active'),
    )

    def __repr__(self):
        return f"<User {self.username} ({self.role.value})>"


# ════════════════════════════════════════════════════════════════════
# CASE MODEL
# ════════════════════════════════════════════════════════════════════

class Case(Base):
    """Investigation case that groups all OSINT findings."""
    __tablename__ = "cases"

    id = Column(Integer, primary_key=True, index=True)
    uuid = Column(GUID(), default=uuid.uuid4, unique=True, nullable=False)
    title = Column(String(200), nullable=False, index=True)
    description = Column(Text)
    case_number = Column(String(20), unique=True, index=True)  # AUTO: CASE-2024-0001
    status = Column(Enum(CaseStatus, values_callable=lambda obj: [e.value for e in obj]), default=CaseStatus.OPEN, nullable=False, index=True)
    priority = Column(Enum(CasePriority, values_callable=lambda obj: [e.value for e in obj]), default=CasePriority.MEDIUM, nullable=False)
    tags = Column(PortableJSON(), default=list)          # ["social-media", "fraud", ...]
    metadata_ = Column("metadata", PortableJSON(), default=dict)  # Flexible extra data
    is_archived = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    closed_at = Column(DateTime(timezone=True))

    # Foreign keys
    created_by_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    assigned_to_id = Column(Integer, ForeignKey("users.id"))

    # Relationships
    created_by = relationship("User", back_populates="cases", foreign_keys=[created_by_id])
    assigned_to = relationship("User", back_populates="assigned_cases", foreign_keys=[assigned_to_id])
    subjects = relationship("Subject", back_populates="case", cascade="all, delete-orphan")
    username_searches = relationship("UsernameSearch", back_populates="case", cascade="all, delete-orphan")
    evidence = relationship("Evidence", back_populates="case", cascade="all, delete-orphan")
    notes = relationship("Note", back_populates="case", cascade="all, delete-orphan")
    reports = relationship("Report", back_populates="case", cascade="all, delete-orphan")

    __table_args__ = (
        Index('ix_cases_status_priority', 'status', 'priority'),
    )

    def __repr__(self):
        return f"<Case {self.case_number}: {self.title}>"


# ════════════════════════════════════════════════════════════════════
# SUBJECT MODEL
# ════════════════════════════════════════════════════════════════════

class Subject(Base):
    """A person or entity being investigated within a case."""
    __tablename__ = "subjects"

    id = Column(Integer, primary_key=True, index=True)
    uuid = Column(GUID(), default=uuid.uuid4, unique=True)
    name = Column(String(200), nullable=False, index=True)
    aliases = Column(PortableJSON(), default=list)          # Known aliases
    emails = Column(PortableJSON(), default=list)           # Known email addresses
    phone_numbers = Column(PortableJSON(), default=list)    # Known phone numbers
    locations = Column(PortableJSON(), default=list)        # Known locations
    websites = Column(PortableJSON(), default=list)         # Known websites
    description = Column(Text)
    profile_image_url = Column(String(500))
    metadata_ = Column("metadata", PortableJSON(), default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Foreign keys
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)

    # Relationships
    case = relationship("Case", back_populates="subjects")
    usernames = relationship("UsernameSearch", back_populates="subject")
    evidence = relationship("Evidence", back_populates="subject")

    def __repr__(self):
        return f"<Subject {self.name}>"


# ════════════════════════════════════════════════════════════════════
# USERNAME SEARCH MODEL
# ════════════════════════════════════════════════════════════════════

class UsernameSearch(Base):
    """A Sherlock username search session with its results."""
    __tablename__ = "username_searches"

    id = Column(Integer, primary_key=True, index=True)
    uuid = Column(GUID(), default=uuid.uuid4, unique=True)
    username = Column(String(100), nullable=False, index=True)
    status = Column(Enum(UsernameStatus, values_callable=lambda obj: [e.value for e in obj]), default=UsernameStatus.PENDING, nullable=False)
    celery_task_id = Column(String(255))           # Track background job
    total_checked = Column(Integer, default=0)
    total_found = Column(Integer, default=0)
    platforms_found = Column(PortableJSON(), default=list)  # List of found platforms
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    error_message = Column(Text)

    # Foreign keys
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    subject_id = Column(Integer, ForeignKey("subjects.id", ondelete="SET NULL"))

    # Relationships
    case = relationship("Case", back_populates="username_searches")
    subject = relationship("Subject", back_populates="usernames")
    profiles = relationship("Profile", back_populates="username_search", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<UsernameSearch @{self.username} [{self.status.value}]>"


# ════════════════════════════════════════════════════════════════════
# PROFILE MODEL
# ════════════════════════════════════════════════════════════════════

class Profile(Base):
    """A discovered social media or web profile from a username search."""
    __tablename__ = "profiles"

    id = Column(Integer, primary_key=True, index=True)
    platform = Column(String(100), nullable=False, index=True)
    url = Column(String(2000), nullable=False)
    username = Column(String(100), nullable=False)
    http_status = Column(Integer)                  # HTTP response code
    response_time_ms = Column(Integer)
    is_found = Column(Boolean, default=False)
    metadata_ = Column("metadata", PortableJSON(), default=dict)  # Extra data from platform
    discovered_at = Column(DateTime(timezone=True), server_default=func.now())

    # Foreign keys
    username_search_id = Column(
        Integer, ForeignKey("username_searches.id", ondelete="CASCADE"), nullable=False
    )

    # Relationships
    username_search = relationship("UsernameSearch", back_populates="profiles")

    __table_args__ = (
        Index('ix_profiles_platform_username', 'platform', 'username'),
        UniqueConstraint('username_search_id', 'platform', name='uq_profile_search_platform'),
    )

    def __repr__(self):
        return f"<Profile {self.platform}: {self.url}>"


# ════════════════════════════════════════════════════════════════════
# EVIDENCE MODEL
# ════════════════════════════════════════════════════════════════════

class Evidence(Base):
    """Evidence item attached to a case."""
    __tablename__ = "evidence"

    id = Column(Integer, primary_key=True, index=True)
    uuid = Column(GUID(), default=uuid.uuid4, unique=True)
    title = Column(String(300), nullable=False)
    description = Column(Text)
    evidence_type = Column(Enum(EvidenceType, values_callable=lambda obj: [e.value for e in obj]), nullable=False, index=True)
    file_path = Column(String(1000))               # Path for uploaded files
    file_name = Column(String(500))
    file_size = Column(BigInteger)                 # Bytes
    mime_type = Column(String(100))
    url = Column(String(2000))                     # For URL evidence
    source = Column(String(500))                   # Where was this found?
    hash_sha256 = Column(String(64))               # File integrity hash
    tags = Column(PortableJSON(), default=list)
    metadata_ = Column("metadata", PortableJSON(), default=dict)
    collected_at = Column(DateTime(timezone=True), server_default=func.now())
    is_sensitive = Column(Boolean, default=False)

    # Foreign keys
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    subject_id = Column(Integer, ForeignKey("subjects.id", ondelete="SET NULL"))
    uploaded_by_id = Column(Integer, ForeignKey("users.id"))

    # Relationships
    case = relationship("Case", back_populates="evidence")
    subject = relationship("Subject", back_populates="evidence")

    def __repr__(self):
        return f"<Evidence {self.title} [{self.evidence_type.value}]>"


# ════════════════════════════════════════════════════════════════════
# NOTE MODEL
# ════════════════════════════════════════════════════════════════════

class Note(Base):
    """Analyst notes attached to a case."""
    __tablename__ = "notes"

    id = Column(Integer, primary_key=True, index=True)
    content = Column(Text, nullable=False)
    is_pinned = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Foreign keys
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    author_id = Column(Integer, ForeignKey("users.id"))

    # Relationships
    case = relationship("Case", back_populates="notes")

    def __repr__(self):
        return f"<Note case={self.case_id}>"


# ════════════════════════════════════════════════════════════════════
# REPORT MODEL
# ════════════════════════════════════════════════════════════════════

class Report(Base):
    """Generated investigation report."""
    __tablename__ = "reports"

    id = Column(Integer, primary_key=True, index=True)
    uuid = Column(GUID(), default=uuid.uuid4, unique=True)
    title = Column(String(300), nullable=False)
    format = Column(Enum(ReportFormat, values_callable=lambda obj: [e.value for e in obj]), nullable=False)
    status = Column(Enum(ReportStatus, values_callable=lambda obj: [e.value for e in obj]), default=ReportStatus.PENDING, nullable=False)
    file_path = Column(String(1000))
    file_size = Column(BigInteger)
    celery_task_id = Column(String(255))
    include_summary = Column(Boolean, default=True)
    include_evidence = Column(Boolean, default=True)
    include_timeline = Column(Boolean, default=True)
    include_graph = Column(Boolean, default=True)
    sections = Column(PortableJSON(), default=dict)         # Which sections to include
    error_message = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    completed_at = Column(DateTime(timezone=True))

    # Foreign keys
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    generated_by_id = Column(Integer, ForeignKey("users.id"))

    # Relationships
    case = relationship("Case", back_populates="reports")
    generated_by = relationship("User", back_populates="reports")

    def __repr__(self):
        return f"<Report {self.title} [{self.format.value}]>"


# ════════════════════════════════════════════════════════════════════
# ACTIVITY LOG MODEL
# ════════════════════════════════════════════════════════════════════

class ActivityLog(Base):
    """Audit log of all user actions for compliance and security."""
    __tablename__ = "activity_logs"

    id = Column(Integer, primary_key=True, index=True)
    action = Column(Enum(ActivityAction, values_callable=lambda obj: [e.value for e in obj]), nullable=False, index=True)
    resource_type = Column(String(50), index=True)  # "case", "subject", etc.
    resource_id = Column(Integer)
    details = Column(PortableJSON(), default=dict)            # Action-specific details
    ip_address = Column(String(45))                 # IPv4/IPv6
    user_agent = Column(String(500))
    status_code = Column(Integer)                   # HTTP response code
    success = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Foreign keys
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))

    # Relationships
    user = relationship("User", back_populates="activity_logs")

    __table_args__ = (
        Index('ix_activity_logs_user_action', 'user_id', 'action'),
        Index('ix_activity_logs_created_at', 'created_at'),
    )

    def __repr__(self):
        return f"<ActivityLog {self.action.value} by user={self.user_id}>"


# ════════════════════════════════════════════════════════════════════
# IMAGE SEARCH MODEL  (replaces local FaceEmbedding / FaceMatch)
# ════════════════════════════════════════════════════════════════════

class ImageSearch(Base):
    """
    A reverse image search session — upload an image, get back links and
    (optionally) structured results from Google Lens / TinEye / Yandex.
    
    Replaces the local InsightFace face-embedding approach entirely.
    All results come from the public web, not a local biometric database.
    """
    __tablename__ = "image_searches"

    id         = Column(Integer, primary_key=True, index=True)
    uuid       = Column(GUID(), default=uuid.uuid4, unique=True)

    # Uploaded file info
    filename       = Column(String(500), nullable=False)
    image_path     = Column(String(1000), nullable=False)
    file_hash      = Column(String(64), index=True)     # SHA-256 hex
    file_size      = Column(BigInteger)                 # bytes
    image_width    = Column(Integer)
    image_height   = Column(Integer)
    mime_type      = Column(String(100))

    # Extracted metadata
    exif_data      = Column(PortableJSON(), default=dict)  # GPS, camera info, etc.

    # Search results
    search_links   = Column(PortableJSON(), default=dict)  # engine -> URL dict
    api_results    = Column(PortableJSON(), default=list)  # structured matches from APIs
    total_found    = Column(Integer, default=0)
    engines_searched = Column(PortableJSON(), default=list)
    search_duration_ms = Column(Integer)

    # Which engines returned real results (vs just links)
    serpapi_used   = Column(Boolean, default=False)
    tineye_used    = Column(Boolean, default=False)

    status         = Column(String(20), default="pending")  # pending/completed/error
    error_message  = Column(Text)
    created_at     = Column(DateTime(timezone=True), server_default=func.now())

    # Relations
    case_id        = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    subject_id     = Column(Integer, ForeignKey("subjects.id", ondelete="SET NULL"))
    uploaded_by_id = Column(Integer, ForeignKey("users.id"))

    case    = relationship("Case",    backref="image_searches")
    subject = relationship("Subject", backref="image_searches", foreign_keys=[subject_id])

    def __repr__(self):
        return f"<ImageSearch {self.filename} [{self.status}]>"
