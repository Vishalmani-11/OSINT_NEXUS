"""
OSINT Nexus - Portable Column Types
Custom SQLAlchemy types that use PostgreSQL-native storage in production
(UUID, JSONB) while remaining fully compatible with SQLite for fast,
dependency-free unit testing — without forking the model definitions
between environments.

GUID is the canonical "Backend-agnostic GUID Type" recipe from the
SQLAlchemy documentation: native `UUID` on PostgreSQL, `CHAR(32)` hex
string everywhere else.

PortableJSON() returns `JSON` with a PostgreSQL variant of `JSONB`, using
SQLAlchemy's built-in `.with_variant()` — this is not a custom type, just
a configured instance, so it keeps JSONB's indexing/containment-query
benefits in production while working unmodified on SQLite in tests.
"""
import uuid as uuid_lib

from sqlalchemy.types import TypeDecorator, CHAR, JSON
from sqlalchemy.dialects.postgresql import UUID as PG_UUID, JSONB as PG_JSONB


class GUID(TypeDecorator):
    """
    Platform-independent GUID type.

    Uses PostgreSQL's native UUID type when running against PostgreSQL,
    otherwise stores as a stringified hex CHAR(32) (e.g. SQLite in tests).
    Python-side, this always behaves as a `uuid.UUID` instance.
    """
    impl = CHAR
    cache_ok = True

    def load_dialect_impl(self, dialect):
        if dialect.name == "postgresql":
            return dialect.type_descriptor(PG_UUID(as_uuid=True))
        return dialect.type_descriptor(CHAR(32))

    def process_bind_param(self, value, dialect):
        if value is None:
            return value
        if dialect.name == "postgresql":
            return str(value)
        if not isinstance(value, uuid_lib.UUID):
            value = uuid_lib.UUID(value)
        return value.hex

    def process_result_value(self, value, dialect):
        if value is None:
            return value
        if isinstance(value, uuid_lib.UUID):
            return value
        return uuid_lib.UUID(value)


def PortableJSON():
    """
    JSON column that compiles to JSONB on PostgreSQL (indexed, queryable)
    and generic JSON everywhere else (e.g. SQLite for tests).

    Usage: Column(PortableJSON(), default=dict)
    """
    return JSON().with_variant(PG_JSONB(), "postgresql")
