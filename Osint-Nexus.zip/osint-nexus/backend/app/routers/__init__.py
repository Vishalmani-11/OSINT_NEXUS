"""
OSINT Nexus - Feature Routers
Username search, face analysis, reports, graph, and dashboard endpoints.
"""
import hashlib
import logging
import os
import time
from pathlib import Path
from typing import List, Optional

from fastapi import (
    APIRouter, Depends, HTTPException, Query, UploadFile,
    File, Form, BackgroundTasks, status
)
from fastapi.responses import FileResponse
from sqlalchemy import select, func, desc, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database import get_db
from app.models import (
    UsernameSearch, Profile, UsernameStatus,
    ImageSearch,
    Report, ReportStatus, ReportFormat,
    ActivityLog, ActivityAction,
    User, Case, Subject, Evidence,
)
from app.schemas import (
    UsernameSearchCreate, UsernameSearchResponse,
    ImageSearchCreate, ImageSearchResponse,
    ReportCreate, ReportResponse,
    GraphQueryRequest, GraphResponse,
    DashboardStats, RecentActivity,
)
from app.services.auth import get_current_user, require_analyst
from app.config import settings

logger = logging.getLogger(__name__)


# ════════════════════════════════════════════════════════════════════
# USERNAME ROUTER
# ════════════════════════════════════════════════════════════════════
username_router = APIRouter(prefix="/usernames", tags=["Username OSINT"])


@username_router.post("/search", response_model=UsernameSearchResponse, status_code=201)
async def start_username_search(
    body: UsernameSearchCreate,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    """
    Start a Sherlock username search across social platforms.
    The scan runs as a background Celery task.
    Returns immediately with the search record.
    """
    # Validate case exists
    case = await db.scalar(select(Case).where(Case.id == body.case_id))
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    search = UsernameSearch(
        username=body.username.lower().strip(),
        case_id=body.case_id,
        subject_id=body.subject_id,
        status=UsernameStatus.PENDING,
    )
    db.add(search)
    await db.commit()
    await db.refresh(search)

    # Launch background task
    from app.celery_app import run_username_scan
    task = run_username_scan.delay(
        search_id=search.id,
        username=search.username,
        case_id=body.case_id,
    )
    search.celery_task_id = task.id
    await db.commit()

    # Re-fetch with `profiles` eager-loaded: the response_model includes
    # `profiles`, and accessing a lazy relationship during Pydantic's
    # response serialization (outside the session's async context) raises
    # MissingGreenlet. (profiles is always empty at this point since the
    # scan hasn't run yet, but the relationship must still be loaded rather
    # than lazy, or serialization fails before the empty list is even seen.)
    result = await db.execute(
        select(UsernameSearch)
        .options(selectinload(UsernameSearch.profiles))
        .where(UsernameSearch.id == search.id)
    )
    return result.scalar_one()


@username_router.get("/search/{search_id}", response_model=UsernameSearchResponse)
async def get_username_search(
    search_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get the status and results of a username search."""
    result = await db.execute(
        select(UsernameSearch)
        .options(selectinload(UsernameSearch.profiles))
        .where(UsernameSearch.id == search_id)
    )
    search = result.scalar_one_or_none()
    if not search:
        raise HTTPException(status_code=404, detail="Search not found")
    return search


@username_router.get("/case/{case_id}", response_model=List[UsernameSearchResponse])
async def list_case_searches(
    case_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List all username searches for a case."""
    result = await db.execute(
        select(UsernameSearch)
        .options(selectinload(UsernameSearch.profiles))
        .where(UsernameSearch.case_id == case_id)
        .order_by(desc(UsernameSearch.created_at))
    )
    return result.scalars().all()


@username_router.delete("/{search_id}", status_code=204)
async def delete_search(
    search_id: int,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(UsernameSearch).where(UsernameSearch.id == search_id)
    )
    search = result.scalar_one_or_none()
    if not search:
        raise HTTPException(status_code=404, detail="Search not found")
    await db.delete(search)
    await db.commit()


# ════════════════════════════════════════════════════════════════════
# REVERSE IMAGE SEARCH ROUTER
# ════════════════════════════════════════════════════════════════════
images_router = APIRouter(prefix="/images", tags=["Reverse Image Search"])


@images_router.post("/search", response_model=ImageSearchResponse, status_code=201)
async def reverse_image_search(
    case_id: int = Form(...),
    subject_id: Optional[int] = Form(None),
    public_base_url: str = Form(default=""),
    file: UploadFile = File(...),
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    """
    Upload an image and search the web for matches using Google Images,
    Google Lens, TinEye, Yandex, and Bing Visual Search.

    Always returns deep-link search URLs the analyst can open in a browser.
    If SERPAPI_KEY or TINEYE_API_KEY are set in environment, also returns
    structured result lists with matching URLs, domains, and thumbnails.

    No local biometric processing — all results come from public web indexes.
    """
    from app.services.reverse_image_search import reverse_image_service

    # Validate case exists
    case = await db.scalar(select(Case).where(Case.id == case_id))
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    # Validate file type
    if file.content_type not in settings.ALLOWED_IMAGE_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type: {file.content_type}"
        )

    content = await file.read()
    if len(content) > settings.max_upload_size_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"File too large. Maximum: {settings.MAX_UPLOAD_SIZE_MB}MB"
        )

    # Save to disk
    image_path, file_hash = await reverse_image_service.save_upload(
        file.filename, content
    )

    # Run the search (blocking IO wrapped, returns quickly since it's
    # mostly URL generation unless API keys are configured)
    session = await reverse_image_service.search(
        image_path=image_path,
        content=content,
        filename=file.filename,
        public_base_url=public_base_url,
    )

    # Persist to DB
    record = ImageSearch(
        filename=file.filename,
        image_path=image_path,
        file_hash=file_hash,
        file_size=session.file_size,
        image_width=session.image_width,
        image_height=session.image_height,
        mime_type=file.content_type,
        exif_data=session.exif_data,
        search_links=session.search_links,
        api_results=[
            {
                "source": r.source, "url": r.url, "title": r.title,
                "thumbnail_url": r.thumbnail_url, "image_url": r.image_url,
                "domain": r.domain, "score": r.score,
                "width": r.width, "height": r.height,
            }
            for r in session.results
        ],
        total_found=session.total_found,
        engines_searched=session.engines_searched,
        search_duration_ms=session.search_duration_ms,
        serpapi_used="Google Lens (SerpAPI)" in session.engines_searched,
        tineye_used="TinEye" in session.engines_searched,
        status="completed" if not session.error else "error",
        error_message=session.error,
        case_id=case_id,
        subject_id=subject_id,
        uploaded_by_id=current_user.id,
    )
    db.add(record)
    await db.commit()
    await db.refresh(record)
    return record


@images_router.get("/{search_id}", response_model=ImageSearchResponse)
async def get_image_search(
    search_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a specific reverse image search result by ID."""
    result = await db.execute(
        select(ImageSearch).where(ImageSearch.id == search_id)
    )
    record = result.scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=404, detail="Image search not found")
    return record


@images_router.get("/case/{case_id}", response_model=List[ImageSearchResponse])
async def list_case_image_searches(
    case_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List all reverse image searches for a case."""
    result = await db.execute(
        select(ImageSearch)
        .where(ImageSearch.case_id == case_id)
        .order_by(desc(ImageSearch.created_at))
    )
    return result.scalars().all()


@images_router.delete("/{search_id}", status_code=204)
async def delete_image_search(
    search_id: int,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(ImageSearch).where(ImageSearch.id == search_id)
    )
    record = result.scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=404, detail="Image search not found")
    await db.delete(record)
    await db.commit()


# ════════════════════════════════════════════════════════════════════
# REPORTS ROUTER
# ════════════════════════════════════════════════════════════════════
# REPORTS ROUTER
# ════════════════════════════════════════════════════════════════════
reports_router = APIRouter(prefix="/reports", tags=["Reports"])


@reports_router.post("/generate", response_model=ReportResponse, status_code=201)
async def generate_report(
    body: ReportCreate,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    """
    Queue an investigation report for generation.
    Supported formats: PDF, HTML, JSON.
    """
    case = await db.scalar(select(Case).where(Case.id == body.case_id))
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    report = Report(
        title=body.title,
        format=body.format,
        case_id=body.case_id,
        generated_by_id=current_user.id,
        include_summary=body.include_summary,
        include_evidence=body.include_evidence,
        include_timeline=body.include_timeline,
        include_graph=body.include_graph,
        status=ReportStatus.PENDING,
    )
    db.add(report)
    await db.commit()
    await db.refresh(report)

    # Kick off generation task
    from app.celery_app import generate_report as gen_task
    task = gen_task.delay(report_id=report.id)
    report.celery_task_id = task.id
    await db.commit()

    return report


@reports_router.get("", response_model=List[ReportResponse])
async def list_reports(
    case_id: Optional[int] = Query(None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    query = select(Report).order_by(desc(Report.created_at))
    if case_id:
        query = query.where(Report.case_id == case_id)
    result = await db.execute(query)
    return result.scalars().all()


@reports_router.get("/{report_id}", response_model=ReportResponse)
async def get_report(
    report_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(Report).where(Report.id == report_id))
    report = result.scalar_one_or_none()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return report


@reports_router.get("/{report_id}/download")
async def download_report(
    report_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Download a completed report file."""
    result = await db.execute(select(Report).where(Report.id == report_id))
    report = result.scalar_one_or_none()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    if report.status != ReportStatus.COMPLETED:
        raise HTTPException(
            status_code=422,
            detail=f"Report is not ready (status: {report.status.value})"
        )

    if not report.file_path or not Path(report.file_path).exists():
        raise HTTPException(status_code=404, detail="Report file not found on disk")

    media_types = {"pdf": "application/pdf", "html": "text/html", "json": "application/json"}
    return FileResponse(
        path=report.file_path,
        filename=f"report_{report.id}.{report.format.value}",
        media_type=media_types.get(report.format.value, "application/octet-stream"),
    )


# ════════════════════════════════════════════════════════════════════
# GRAPH ROUTER
# ════════════════════════════════════════════════════════════════════
graph_router = APIRouter(prefix="/graph", tags=["Graph Intelligence"])


@graph_router.get("/case/{case_id}", response_model=GraphResponse)
async def get_case_graph(
    case_id: int,
    max_depth: int = Query(default=3, ge=1, le=5),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get the Neo4j relationship graph for a case."""
    from app.services.graph import graph_service
    data = await graph_service.get_case_graph(case_id=case_id, max_depth=max_depth)
    return GraphResponse(**data)


@graph_router.post("/query", response_model=GraphResponse)
async def query_graph(
    body: GraphQueryRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Custom graph query with filters."""
    from app.services.graph import graph_service
    if body.case_id:
        data = await graph_service.get_case_graph(
            case_id=body.case_id,
            max_depth=body.max_depth,
        )
    elif body.subject_id:
        data = await graph_service.get_subject_graph(subject_id=body.subject_id)
    else:
        data = {"nodes": [], "edges": [], "node_count": 0, "edge_count": 0}
    return GraphResponse(**data)


# ════════════════════════════════════════════════════════════════════
# DASHBOARD ROUTER
# ════════════════════════════════════════════════════════════════════
dashboard_router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@dashboard_router.get("/stats", response_model=DashboardStats)
async def get_dashboard_stats(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Return aggregate statistics for the dashboard."""
    total_cases = await db.scalar(select(func.count(Case.id)))
    active_cases = await db.scalar(
        select(func.count(Case.id)).where(Case.status.in_(["open", "active"]))
    )
    total_subjects    = await db.scalar(select(func.count(Subject.id)))
    username_searches = await db.scalar(select(func.count(UsernameSearch.id)))
    username_matches  = await db.scalar(select(func.sum(UsernameSearch.total_found)))
    image_searches    = await db.scalar(select(func.count(ImageSearch.id)))
    image_results     = await db.scalar(
        select(func.sum(ImageSearch.total_found))
    )
    evidence_items    = await db.scalar(select(func.count(Evidence.id)))
    reports           = await db.scalar(
        select(func.count(Report.id)).where(Report.status == "completed")
    )
    recent_activity   = await db.scalar(select(func.count(ActivityLog.id)))

    return DashboardStats(
        total_cases=total_cases or 0,
        active_cases=active_cases or 0,
        total_subjects=total_subjects or 0,
        username_searches=username_searches or 0,
        username_matches=int(username_matches or 0),
        image_searches=image_searches or 0,
        image_results=int(image_results or 0),
        evidence_items=evidence_items or 0,
        reports_generated=reports or 0,
        recent_activity_count=recent_activity or 0,
    )


@dashboard_router.get("/activity", response_model=List[RecentActivity])
async def get_recent_activity(
    limit: int = Query(default=20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get the most recent activity log entries."""
    result = await db.execute(
        select(ActivityLog, User.username)
        .outerjoin(User, ActivityLog.user_id == User.id)
        .order_by(desc(ActivityLog.created_at))
        .limit(limit)
    )
    activities = []
    for log, username in result:
        activities.append(RecentActivity(
            id=log.id,
            action=log.action.value,
            resource_type=log.resource_type,
            details=log.details or {},
            created_at=log.created_at,
            user_username=username,
        ))
    return activities


@dashboard_router.get("/platform-distribution")
async def get_platform_distribution(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get distribution of found social platforms across all searches."""
    result = await db.execute(
        select(Profile.platform, func.count(Profile.id).label("count"))
        .where(Profile.is_found == True)
        .group_by(Profile.platform)
        .order_by(desc("count"))
        .limit(15)
    )
    rows = result.all()
    total = sum(r.count for r in rows)
    return [
        {
            "platform": r.platform,
            "count": r.count,
            "percentage": round(r.count / total * 100, 1) if total > 0 else 0,
        }
        for r in rows
    ]


@dashboard_router.get("/timeline")
async def get_investigation_timeline(
    days: int = Query(default=30, ge=7, le=365),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get daily investigation counts for chart rendering."""
    from sqlalchemy import cast, Date, text
    result = await db.execute(
        text("""
            SELECT
                DATE(created_at) AS date,
                COUNT(*) FILTER (WHERE resource_type = 'case') AS cases,
                COUNT(*) FILTER (WHERE resource_type = 'search') AS searches,
                COUNT(*) FILTER (WHERE resource_type = 'face') AS face_analyses
            FROM activity_logs
            WHERE created_at >= NOW() - INTERVAL ':days days'
            GROUP BY DATE(created_at)
            ORDER BY date ASC
        """).bindparams(days=days)
    )
    rows = result.all()
    return [
        {
            "date": str(r.date),
            "investigations": r.cases or 0,
            "username_searches": r.searches or 0,
            "face_analyses": r.face_analyses or 0,
        }
        for r in rows
    ]


# ── Patch: Replace raw-SQL timeline with ORM version ─────────────

@dashboard_router.get("/timeline-orm")
async def get_investigation_timeline_orm(
    days: int = Query(default=30, ge=7, le=365),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Daily investigation activity counts using ORM (no raw SQL)."""
    from datetime import timedelta, date
    from sqlalchemy import cast, Date

    cutoff = datetime.utcnow() - timedelta(days=days)

    result = await db.execute(
        select(
            cast(ActivityLog.created_at, Date).label("date"),
            func.count(ActivityLog.id).label("total"),
        )
        .where(ActivityLog.created_at >= cutoff)
        .group_by(cast(ActivityLog.created_at, Date))
        .order_by(cast(ActivityLog.created_at, Date).asc())
    )
    rows = result.all()
    return [{"date": str(r.date), "investigations": r.total,
             "username_searches": 0, "face_analyses": 0} for r in rows]
