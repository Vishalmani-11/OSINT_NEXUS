"""
OSINT Nexus - Authentication Router
Handles user registration, login, token refresh, and profile management.
"""
import logging
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import User, UserRole, ActivityLog, ActivityAction
from app.schemas import (
    UserCreate, UserLogin, UserResponse, UserUpdate,
    TokenResponse, TokenRefresh, PasswordChange
)
from app.services.auth import (
    hash_password, verify_password, authenticate_user,
    create_access_token, create_refresh_token, decode_token,
    get_current_user, get_user_by_id
)
from app.services.activity import log_event

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/auth", tags=["Authentication"])


# ── Registration ──────────────────────────────────────────────────────────────

@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register(
    body: UserCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """
    Register a new user account.
    The first registered user is automatically granted ADMIN role.
    """
    # Check for duplicate email
    existing = await db.execute(
        select(User).where(
            (User.email == body.email.lower()) |
            (User.username == body.username.lower())
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A user with this email or username already exists",
        )

    # First user gets admin role
    user_count_result = await db.execute(select(func.count(User.id)))
    user_count = user_count_result.scalar()
    role = UserRole.ADMIN if user_count == 0 else UserRole.ANALYST

    user = User(
        email=body.email.lower(),
        username=body.username.lower(),
        hashed_password=hash_password(body.password),
        full_name=body.full_name,
        role=role,
        is_active=True,
        is_verified=role == UserRole.ADMIN,  # Auto-verify first admin
    )
    db.add(user)
    await db.flush()  # Get the user.id

    await log_event(
        db, ActivityAction.CREATE, user_id=user.id,
        resource_type="auth", details={"type": "registration"}, request=request,
    )
    await db.commit()
    await db.refresh(user)

    logger.info("New user registered: %s (%s)", user.username, user.role.value)
    return user


# ── Login ─────────────────────────────────────────────────────────────────────

@router.post("/login", response_model=TokenResponse)
async def login(
    body: UserLogin,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """
    Authenticate with username/email + password.
    Returns JWT access token + refresh token.
    """
    user = await authenticate_user(body.username, body.password, db)

    if not user:
        await log_event(
            db, ActivityAction.LOGIN, resource_type="auth",
            details={"identifier": body.username, "reason": "invalid_credentials"},
            request=request, success=False,
        )
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username/email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # Update last login
    user.last_login = datetime.utcnow()
    await log_event(
        db, ActivityAction.LOGIN, user_id=user.id,
        resource_type="auth", details={"method": "password"}, request=request,
    )
    await db.commit()
    await db.refresh(user)

    from app.config import settings
    access_token = create_access_token({"sub": str(user.id), "role": user.role.value})
    refresh_token = create_refresh_token({"sub": str(user.id)})

    logger.info("User logged in: %s", user.username)
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user=user,
    )


# ── Token Refresh ─────────────────────────────────────────────────────────────

@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    body: TokenRefresh,
    db: AsyncSession = Depends(get_db),
):
    """Exchange a refresh token for a new access token."""
    payload = decode_token(body.refresh_token)

    if payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token",
        )

    user = await get_user_by_id(int(payload["sub"]), db)
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive",
        )

    from app.config import settings
    access_token = create_access_token({"sub": str(user.id), "role": user.role.value})
    new_refresh = create_refresh_token({"sub": str(user.id)})

    return TokenResponse(
        access_token=access_token,
        refresh_token=new_refresh,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user=user,
    )


# ── Current User ──────────────────────────────────────────────────────────────

@router.get("/me", response_model=UserResponse)
async def get_me(current_user: User = Depends(get_current_user)):
    """Return the currently authenticated user's profile."""
    return current_user


@router.patch("/me", response_model=UserResponse)
async def update_me(
    body: UserUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update the current user's profile information."""
    if body.full_name is not None:
        current_user.full_name = body.full_name
    if body.bio is not None:
        current_user.bio = body.bio
    if body.avatar_url is not None:
        current_user.avatar_url = body.avatar_url

    await db.commit()
    await db.refresh(current_user)
    return current_user


@router.post("/change-password", status_code=status.HTTP_204_NO_CONTENT)
async def change_password(
    body: PasswordChange,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Change the current user's password."""
    if not verify_password(body.current_password, current_user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect",
        )
    current_user.hashed_password = hash_password(body.new_password)
    await db.commit()


# ── Logout ────────────────────────────────────────────────────────────────────

@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Logout the current user.
    JWT tokens are stateless; this logs the event for audit purposes.
    For full token revocation, implement a Redis deny-list.
    """
    await log_event(
        db, ActivityAction.LOGOUT, user_id=current_user.id,
        resource_type="auth", request=request,
    )
    await db.commit()
