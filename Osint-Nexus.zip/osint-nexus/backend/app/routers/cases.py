"""
OSINT Nexus - Cases Router
Full case management: CRUD, subjects, evidence, notes, timeline.
"""
import re
import logging
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select, func, desc, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database import get_db
from app.models import (
    Case, CaseStatus, CasePriority, Subject, Evidence, Note,
    UsernameSearch, User, ActivityLog, ActivityAction
)
from app.schemas import (
    CaseCreate, CaseUpdate, CaseResponse, CaseSummary,
    SubjectCreate, SubjectUpdate, SubjectResponse,
    EvidenceCreate, EvidenceResponse, NoteCreate, NoteResponse,
)
from app.services.auth import get_current_user, require_analyst

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/cases", tags=["Cases"])


def generate_case_number(case_id: int) -> str:
    """Generate a sequential case number like CASE-2024-0001."""
    year = datetime.utcnow().year
    return f"CASE-{year}-{case_id:04d}"


# ════════════════════════════════════════════════════════════════════
# CASE CRUD
# ════════════════════════════════════════════════════════════════════

@router.get("", response_model=List[CaseResponse])
async def list_cases(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List all cases with optional filtering and pagination."""
    query = (
        select(Case)
        .options(selectinload(Case.created_by), selectinload(Case.assigned_to))
        .where(Case.is_archived == False)
        .order_by(desc(Case.created_at))
    )

    if status:
        query = query.where(Case.status == status)
    if priority:
        query = query.where(Case.priority == priority)
    if search:
        query = query.where(Case.title.ilike(f"%{search}%"))

    # Pagination
    offset = (page - 1) * per_page
    query = query.offset(offset).limit(per_page)

    result = await db.execute(query)
    cases = result.scalars().all()

    # Enrich with counts
    case_responses = []
    for case in cases:
        subjects_count = await db.scalar(
            select(func.count(Subject.id)).where(Subject.case_id == case.id)
        )
        evidence_count = await db.scalar(
            select(func.count(Evidence.id)).where(Evidence.case_id == case.id)
        )
        username_count = await db.scalar(
            select(func.count(UsernameSearch.id)).where(UsernameSearch.case_id == case.id)
        )
        case_dict = CaseResponse.model_validate(case).model_dump()
        case_dict["subjects_count"] = subjects_count or 0
        case_dict["evidence_count"] = evidence_count or 0
        case_dict["username_searches_count"] = username_count or 0
        case_responses.append(CaseResponse(**case_dict))

    return case_responses


@router.post("", response_model=CaseResponse, status_code=status.HTTP_201_CREATED)
async def create_case(
    body: CaseCreate,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    """Create a new investigation case."""
    case = Case(
        title=body.title,
        description=body.description,
        priority=body.priority,
        tags=body.tags,
        created_by_id=current_user.id,
        assigned_to_id=body.assigned_to_id or current_user.id,
        status=CaseStatus.OPEN,
    )
    db.add(case)
    await db.flush()  # Get the case.id

    case.case_number = generate_case_number(case.id)

    log = ActivityLog(
        user_id=current_user.id,
        action=ActivityAction.CREATE,
        resource_type="case",
        resource_id=case.id,
        details={"title": case.title},
    )
    db.add(log)
    await db.commit()
    await db.refresh(case)

    result = await db.execute(
        select(Case)
        .options(selectinload(Case.created_by), selectinload(Case.assigned_to))
        .where(Case.id == case.id)
    )
    return result.scalar_one()


@router.get("/{case_id}", response_model=CaseResponse)
async def get_case(
    case_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a specific case by ID with all related data."""
    result = await db.execute(
        select(Case)
        .options(selectinload(Case.created_by), selectinload(Case.assigned_to))
        .where(Case.id == case_id)
    )
    case = result.scalar_one_or_none()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    return case


@router.patch("/{case_id}", response_model=CaseResponse)
async def update_case(
    case_id: int,
    body: CaseUpdate,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    """Update case details, status, or priority."""
    result = await db.execute(select(Case).where(Case.id == case_id))
    case = result.scalar_one_or_none()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    if body.title is not None:
        case.title = body.title
    if body.description is not None:
        case.description = body.description
    if body.status is not None:
        case.status = body.status
        if body.status == CaseStatus.CLOSED:
            case.closed_at = datetime.utcnow()
    if body.priority is not None:
        case.priority = body.priority
    if body.tags is not None:
        case.tags = body.tags
    if body.assigned_to_id is not None:
        case.assigned_to_id = body.assigned_to_id

    log = ActivityLog(
        user_id=current_user.id,
        action=ActivityAction.UPDATE,
        resource_type="case",
        resource_id=case.id,
        details=body.model_dump(exclude_none=True),
    )
    db.add(log)
    await db.commit()
    await db.refresh(case)

    result = await db.execute(
        select(Case)
        .options(selectinload(Case.created_by), selectinload(Case.assigned_to))
        .where(Case.id == case.id)
    )
    return result.scalar_one()


@router.delete("/{case_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_case(
    case_id: int,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    """Archive (soft-delete) a case."""
    result = await db.execute(select(Case).where(Case.id == case_id))
    case = result.scalar_one_or_none()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    case.is_archived = True
    case.status = CaseStatus.ARCHIVED
    await db.commit()


# ════════════════════════════════════════════════════════════════════
# SUBJECTS
# ════════════════════════════════════════════════════════════════════

@router.get("/{case_id}/subjects", response_model=List[SubjectResponse])
async def list_subjects(
    case_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List all subjects for a case."""
    result = await db.execute(
        select(Subject).where(Subject.case_id == case_id).order_by(Subject.name)
    )
    return result.scalars().all()


@router.post("/{case_id}/subjects", response_model=SubjectResponse, status_code=201)
async def create_subject(
    case_id: int,
    body: SubjectCreate,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    """Add a subject to a case."""
    case_result = await db.execute(select(Case).where(Case.id == case_id))
    if not case_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Case not found")

    subject = Subject(
        name=body.name,
        aliases=body.aliases,
        emails=body.emails,
        phone_numbers=body.phone_numbers,
        locations=body.locations,
        websites=body.websites,
        description=body.description,
        case_id=case_id,
    )
    db.add(subject)
    await db.flush()

    # Trigger graph update in background
    from app.celery_app import update_graph_for_subject
    update_graph_for_subject.delay(subject_id=subject.id, case_id=case_id)

    await db.commit()
    await db.refresh(subject)
    return subject


@router.patch("/{case_id}/subjects/{subject_id}", response_model=SubjectResponse)
async def update_subject(
    case_id: int,
    subject_id: int,
    body: SubjectUpdate,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    """Update a subject's information."""
    result = await db.execute(
        select(Subject).where(
            and_(Subject.id == subject_id, Subject.case_id == case_id)
        )
    )
    subject = result.scalar_one_or_none()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")

    for field, value in body.model_dump(exclude_none=True).items():
        setattr(subject, field, value)

    await db.commit()
    await db.refresh(subject)
    return subject


@router.delete("/{case_id}/subjects/{subject_id}", status_code=204)
async def delete_subject(
    case_id: int,
    subject_id: int,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Subject).where(
            and_(Subject.id == subject_id, Subject.case_id == case_id)
        )
    )
    subject = result.scalar_one_or_none()
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found")
    await db.delete(subject)
    await db.commit()


# ════════════════════════════════════════════════════════════════════
# EVIDENCE
# ════════════════════════════════════════════════════════════════════

@router.get("/{case_id}/evidence", response_model=List[EvidenceResponse])
async def list_evidence(
    case_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Evidence)
        .where(Evidence.case_id == case_id)
        .order_by(desc(Evidence.collected_at))
    )
    return result.scalars().all()


@router.post("/{case_id}/evidence", response_model=EvidenceResponse, status_code=201)
async def create_evidence(
    case_id: int,
    body: EvidenceCreate,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    """Add evidence to a case."""
    from app.models import EvidenceType
    evidence = Evidence(
        title=body.title,
        description=body.description,
        evidence_type=body.evidence_type,
        url=body.url,
        source=body.source,
        tags=body.tags,
        case_id=case_id,
        subject_id=body.subject_id,
        uploaded_by_id=current_user.id,
    )
    db.add(evidence)
    await db.commit()
    await db.refresh(evidence)
    return evidence


@router.delete("/{case_id}/evidence/{evidence_id}", status_code=204)
async def delete_evidence(
    case_id: int,
    evidence_id: int,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Evidence).where(
            and_(Evidence.id == evidence_id, Evidence.case_id == case_id)
        )
    )
    ev = result.scalar_one_or_none()
    if not ev:
        raise HTTPException(status_code=404, detail="Evidence not found")
    await db.delete(ev)
    await db.commit()


# ════════════════════════════════════════════════════════════════════
# NOTES
# ════════════════════════════════════════════════════════════════════

@router.get("/{case_id}/notes", response_model=List[NoteResponse])
async def list_notes(
    case_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Note)
        .where(Note.case_id == case_id)
        .order_by(desc(Note.is_pinned), desc(Note.created_at))
    )
    return result.scalars().all()


@router.post("/{case_id}/notes", response_model=NoteResponse, status_code=201)
async def create_note(
    case_id: int,
    body: NoteCreate,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    note = Note(
        content=body.content,
        case_id=case_id,
        is_pinned=body.is_pinned,
        author_id=current_user.id,
    )
    db.add(note)
    await db.commit()
    await db.refresh(note)
    return note


@router.delete("/{case_id}/notes/{note_id}", status_code=204)
async def delete_note(
    case_id: int,
    note_id: int,
    current_user: User = Depends(require_analyst),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Note).where(and_(Note.id == note_id, Note.case_id == case_id))
    )
    note = result.scalar_one_or_none()
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    await db.delete(note)
    await db.commit()


# ════════════════════════════════════════════════════════════════════
# TIMELINE
# ════════════════════════════════════════════════════════════════════

@router.get("/{case_id}/timeline")
async def get_timeline(
    case_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a chronological timeline of all activities in a case."""
    events = []

    # Case creation
    case_result = await db.execute(select(Case).where(Case.id == case_id))
    case = case_result.scalar_one_or_none()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    events.append({
        "type": "case_created", "title": f"Case '{case.title}' opened",
        "timestamp": case.created_at, "icon": "🔍",
    })

    # Subjects
    subjects = await db.execute(
        select(Subject).where(Subject.case_id == case_id).order_by(Subject.created_at)
    )
    for s in subjects.scalars():
        events.append({
            "type": "subject_added", "title": f"Subject added: {s.name}",
            "timestamp": s.created_at, "icon": "👤",
        })

    # Username searches
    searches = await db.execute(
        select(UsernameSearch)
        .where(UsernameSearch.case_id == case_id)
        .order_by(UsernameSearch.created_at)
    )
    for s in searches.scalars():
        events.append({
            "type": "username_search",
            "title": f"Username search: @{s.username} ({s.total_found or 0} found)",
            "timestamp": s.created_at, "icon": "🔎",
        })

    # Evidence
    evidence_result = await db.execute(
        select(Evidence).where(Evidence.case_id == case_id).order_by(Evidence.collected_at)
    )
    for e in evidence_result.scalars():
        events.append({
            "type": "evidence_added", "title": f"Evidence: {e.title}",
            "timestamp": e.collected_at, "icon": "📎",
        })

    # Notes
    notes_result = await db.execute(
        select(Note).where(Note.case_id == case_id).order_by(Note.created_at)
    )
    for n in notes_result.scalars():
        events.append({
            "type": "note_added", "title": f"Note: {n.content[:60]}...",
            "timestamp": n.created_at, "icon": "📝",
        })

    # Sort by timestamp
    events.sort(key=lambda x: x.get("timestamp") or datetime.min)
    return {"case_id": case_id, "events": events}
