"""
OSINT Nexus - Pydantic Schemas
Request/response models for all API endpoints.
"""
from datetime import datetime
from typing import Optional, List, Any, Dict
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field, validator, model_validator


# ════════════════════════════════════════════════════════════════════
# SHARED / BASE SCHEMAS
# ════════════════════════════════════════════════════════════════════

class TimestampMixin(BaseModel):
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class PaginationParams(BaseModel):
    page: int = Field(default=1, ge=1)
    per_page: int = Field(default=20, ge=1, le=100)

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.per_page


class PaginatedResponse(BaseModel):
    items: List[Any]
    total: int
    page: int
    per_page: int
    pages: int

    @model_validator(mode='after')
    def compute_pages(self):
        self.pages = (self.total + self.per_page - 1) // self.per_page
        return self


# ════════════════════════════════════════════════════════════════════
# AUTH SCHEMAS
# ════════════════════════════════════════════════════════════════════

class UserCreate(BaseModel):
    email: EmailStr
    username: str = Field(min_length=3, max_length=50, pattern=r'^[a-zA-Z0-9_-]+$')
    password: str = Field(min_length=8, max_length=128)
    full_name: Optional[str] = Field(None, max_length=100)

    @validator('username')
    def username_lowercase(cls, v):
        return v.lower()


class UserLogin(BaseModel):
    username: str  # Can be username or email
    password: str


class UserResponse(BaseModel):
    id: int
    uuid: UUID
    email: str
    username: str
    full_name: Optional[str]
    role: str
    is_active: bool
    is_verified: bool
    created_at: Optional[datetime]
    last_login: Optional[datetime]

    model_config = {"from_attributes": True}


class UserUpdate(BaseModel):
    full_name: Optional[str] = Field(None, max_length=100)
    bio: Optional[str] = Field(None, max_length=500)
    avatar_url: Optional[str] = None


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # Seconds until access token expires
    user: UserResponse


class TokenRefresh(BaseModel):
    refresh_token: str


class PasswordChange(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)


# ════════════════════════════════════════════════════════════════════
# CASE SCHEMAS
# ════════════════════════════════════════════════════════════════════

class CaseCreate(BaseModel):
    title: str = Field(min_length=3, max_length=200)
    description: Optional[str] = Field(None, max_length=2000)
    priority: str = "medium"
    tags: List[str] = []
    assigned_to_id: Optional[int] = None


class CaseUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=3, max_length=200)
    description: Optional[str] = Field(None, max_length=2000)
    status: Optional[str] = None
    priority: Optional[str] = None
    tags: Optional[List[str]] = None
    assigned_to_id: Optional[int] = None


class CaseResponse(BaseModel):
    id: int
    uuid: UUID
    title: str
    description: Optional[str]
    case_number: Optional[str]
    status: str
    priority: str
    tags: List[str] = []
    created_at: Optional[datetime]
    updated_at: Optional[datetime]
    created_by: Optional[UserResponse]
    assigned_to: Optional[UserResponse]
    subjects_count: Optional[int] = 0
    evidence_count: Optional[int] = 0
    username_searches_count: Optional[int] = 0

    model_config = {"from_attributes": True}


class CaseSummary(BaseModel):
    id: int
    uuid: UUID
    title: str
    case_number: Optional[str]
    status: str
    priority: str
    created_at: Optional[datetime]

    model_config = {"from_attributes": True}


# ════════════════════════════════════════════════════════════════════
# SUBJECT SCHEMAS
# ════════════════════════════════════════════════════════════════════

class SubjectCreate(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    aliases: List[str] = []
    emails: List[str] = []
    phone_numbers: List[str] = []
    locations: List[str] = []
    websites: List[str] = []
    description: Optional[str] = None
    case_id: int


class SubjectUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=200)
    aliases: Optional[List[str]] = None
    emails: Optional[List[str]] = None
    phone_numbers: Optional[List[str]] = None
    locations: Optional[List[str]] = None
    websites: Optional[List[str]] = None
    description: Optional[str] = None


class SubjectResponse(BaseModel):
    id: int
    uuid: UUID
    name: str
    aliases: List[str] = []
    emails: List[str] = []
    phone_numbers: List[str] = []
    locations: List[str] = []
    websites: List[str] = []
    description: Optional[str]
    case_id: int
    created_at: Optional[datetime]

    model_config = {"from_attributes": True}


# ════════════════════════════════════════════════════════════════════
# USERNAME / SHERLOCK SCHEMAS
# ════════════════════════════════════════════════════════════════════

class UsernameSearchCreate(BaseModel):
    username: str = Field(min_length=1, max_length=100, pattern=r'^[a-zA-Z0-9._-]+$')
    case_id: int
    subject_id: Optional[int] = None


class ProfileResponse(BaseModel):
    id: int
    platform: str
    url: str
    username: str
    http_status: Optional[int]
    is_found: bool
    response_time_ms: Optional[int]
    discovered_at: Optional[datetime]

    model_config = {"from_attributes": True}


class UsernameSearchResponse(BaseModel):
    id: int
    uuid: UUID
    username: str
    status: str
    total_checked: int
    total_found: int
    platforms_found: List[str] = []
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    created_at: Optional[datetime]
    error_message: Optional[str]
    case_id: int
    subject_id: Optional[int]
    profiles: List[ProfileResponse] = []

    model_config = {"from_attributes": True}


# ════════════════════════════════════════════════════════════════════
# REVERSE IMAGE SEARCH SCHEMAS
# ════════════════════════════════════════════════════════════════════

class ImageSearchCreate(BaseModel):
    """Request body for starting a reverse image search."""
    case_id: int
    subject_id: Optional[int] = None
    # Optional public-facing base URL so search links point directly
    # to your server's image rather than requiring manual upload.
    # e.g. "https://my-osint-server.example.com"
    public_base_url: str = ""


class WebMatchResult(BaseModel):
    """A single match found on the public web."""
    source: str          # "Google Lens", "TinEye", etc.
    url: str             # page URL where the image appears
    title: str = ""
    thumbnail_url: str = ""
    image_url: str = ""  # direct image URL
    domain: str = ""     # e.g. "twitter.com"
    score: Optional[float] = None
    width: Optional[int] = None
    height: Optional[int] = None


class ImageSearchResponse(BaseModel):
    """Full result of a reverse image search session."""
    id: int
    uuid: UUID
    filename: str
    file_hash: Optional[str]
    file_size: Optional[int]
    image_width: Optional[int]
    image_height: Optional[int]
    mime_type: Optional[str]
    exif_data: Dict[str, Any] = {}
    # Deep-link URLs the analyst can open in a browser – always present
    search_links: Dict[str, str] = {}
    # Structured results from APIs (only if API keys configured)
    api_results: List[Dict[str, Any]] = []
    total_found: int = 0
    engines_searched: List[str] = []
    search_duration_ms: Optional[int]
    serpapi_used: bool = False
    tineye_used: bool = False
    status: str
    error_message: Optional[str]
    case_id: int
    subject_id: Optional[int]
    created_at: Optional[datetime]

    model_config = {"from_attributes": True}


# ════════════════════════════════════════════════════════════════════
# EVIDENCE SCHEMAS
# ════════════════════════════════════════════════════════════════════

class EvidenceCreate(BaseModel):
    title: str = Field(min_length=3, max_length=300)
    description: Optional[str] = None
    evidence_type: str
    url: Optional[str] = None
    source: Optional[str] = None
    tags: List[str] = []
    case_id: int
    subject_id: Optional[int] = None


class EvidenceResponse(BaseModel):
    id: int
    uuid: UUID
    title: str
    description: Optional[str]
    evidence_type: str
    file_name: Optional[str]
    file_size: Optional[int]
    mime_type: Optional[str]
    url: Optional[str]
    source: Optional[str]
    tags: List[str] = []
    is_sensitive: bool
    case_id: int
    subject_id: Optional[int]
    collected_at: Optional[datetime]

    model_config = {"from_attributes": True}


# ════════════════════════════════════════════════════════════════════
# NOTE SCHEMAS
# ════════════════════════════════════════════════════════════════════

class NoteCreate(BaseModel):
    content: str = Field(min_length=1)
    case_id: int
    is_pinned: bool = False


class NoteResponse(BaseModel):
    id: int
    content: str
    is_pinned: bool
    case_id: int
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    model_config = {"from_attributes": True}


# ════════════════════════════════════════════════════════════════════
# REPORT SCHEMAS
# ════════════════════════════════════════════════════════════════════

class ReportCreate(BaseModel):
    title: str = Field(min_length=3, max_length=300)
    case_id: int
    format: str = "pdf"
    include_summary: bool = True
    include_evidence: bool = True
    include_timeline: bool = True
    include_graph: bool = True


class ReportResponse(BaseModel):
    id: int
    uuid: UUID
    title: str
    format: str
    status: str
    file_path: Optional[str]
    file_size: Optional[int]
    error_message: Optional[str]
    case_id: int
    created_at: Optional[datetime]
    completed_at: Optional[datetime]

    model_config = {"from_attributes": True}


# ════════════════════════════════════════════════════════════════════
# GRAPH SCHEMAS
# ════════════════════════════════════════════════════════════════════

class GraphNode(BaseModel):
    id: str
    label: str
    type: str  # "person", "username", "profile", "email", "image"
    properties: Dict[str, Any] = {}
    x: Optional[float] = None
    y: Optional[float] = None


class GraphEdge(BaseModel):
    id: str
    source: str
    target: str
    label: str
    properties: Dict[str, Any] = {}


class GraphResponse(BaseModel):
    nodes: List[GraphNode]
    edges: List[GraphEdge]
    node_count: int
    edge_count: int


class GraphQueryRequest(BaseModel):
    case_id: Optional[int] = None
    subject_id: Optional[int] = None
    max_depth: int = Field(default=3, ge=1, le=5)
    node_types: List[str] = []  # Filter by node types


# ════════════════════════════════════════════════════════════════════
# DASHBOARD SCHEMAS
# ════════════════════════════════════════════════════════════════════

class DashboardStats(BaseModel):
    total_cases: int
    active_cases: int
    total_subjects: int
    username_searches: int
    username_matches: int
    image_searches: int        # reverse image searches run
    image_results: int         # total web matches found across all searches
    evidence_items: int
    reports_generated: int
    recent_activity_count: int


class InvestigationTimelinePoint(BaseModel):
    date: str  # YYYY-MM-DD
    investigations: int
    username_searches: int
    face_analyses: int


class PlatformDistribution(BaseModel):
    platform: str
    count: int
    percentage: float


class RecentActivity(BaseModel):
    id: int
    action: str
    resource_type: Optional[str]
    details: Dict[str, Any] = {}
    created_at: Optional[datetime]
    user_username: Optional[str]

    model_config = {"from_attributes": True}


class HealthResponse(BaseModel):
    status: str
    version: str
    database: bool
    redis: bool
    neo4j: bool
    environment: str
