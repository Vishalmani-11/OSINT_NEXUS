"""
OSINT Nexus - Activity Logging Service
Helper utilities for writing structured audit events to the ActivityLog table.
Keeps routers thin — log calls are one-liners.
"""
from __future__ import annotations

import logging
from typing import Optional, Any, Dict

from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import ActivityLog, ActivityAction, User

logger = logging.getLogger(__name__)


async def log_event(
    db: AsyncSession,
    action: ActivityAction,
    *,
    user: Optional[User] = None,
    user_id: Optional[int] = None,
    resource_type: Optional[str] = None,
    resource_id: Optional[int] = None,
    details: Optional[Dict[str, Any]] = None,
    request: Optional[Request] = None,
    success: bool = True,
    status_code: Optional[int] = None,
) -> None:
    """
    Write a single activity log entry.

    Usage in a router:
        await log_event(db, ActivityAction.CREATE,
                        user=current_user, resource_type="case",
                        resource_id=case.id, details={"title": case.title},
                        request=request)
    """
    resolved_user_id = user_id or (user.id if user else None)

    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    if request:
        ip_address = request.client.host if request.client else None
        user_agent = request.headers.get("user-agent", "")[:500]

    log = ActivityLog(
        action=action,
        user_id=resolved_user_id,
        resource_type=resource_type,
        resource_id=resource_id,
        details=details or {},
        ip_address=ip_address,
        user_agent=user_agent,
        success=success,
        status_code=status_code,
    )
    db.add(log)
    # Let the caller commit — avoids nested transaction issues


async def log_login(
    db: AsyncSession,
    user: Optional[User],
    request: Request,
    success: bool = True,
    reason: Optional[str] = None,
) -> None:
    await log_event(
        db, ActivityAction.LOGIN,
        user=user,
        resource_type="auth",
        details={"success": success, "reason": reason or ("ok" if success else "bad_credentials")},
        request=request,
        success=success,
    )


async def log_crud(
    db: AsyncSession,
    action: ActivityAction,
    user: User,
    resource_type: str,
    resource_id: int,
    details: Optional[Dict] = None,
    request: Optional[Request] = None,
) -> None:
    await log_event(
        db, action,
        user=user,
        resource_type=resource_type,
        resource_id=resource_id,
        details=details or {},
        request=request,
        success=True,
    )
