"""
OSINT Nexus - Authentication Service
JWT tokens, bcrypt password hashing, role-based access control.

NOTE on bcrypt: we call the `bcrypt` library directly rather than going through
passlib's CryptContext. passlib (last released 2020) reads an internal
`bcrypt.__about__.__version__` attribute for backend detection that modern
bcrypt releases (4.1+) removed, which makes passlib raise spurious
"password cannot be longer than 72 bytes" errors on *every* hash call,
not just long passwords. Calling bcrypt directly avoids that unmaintained
compatibility shim entirely.
"""
from datetime import datetime, timedelta, timezone
from typing import Optional, Union

import bcrypt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database import get_db
from app.models import User, UserRole

# ── HTTP Bearer Token Extractor ───────────────────────────────────────────────
security = HTTPBearer(auto_error=False)

# bcrypt's algorithm only uses the first 72 *bytes* of input — anything beyond
# that is ignored. Modern bcrypt (4.1+) raises ValueError instead of silently
# truncating, so we truncate explicitly here to keep hashing/verification safe
# for any password length the Pydantic schema allows (up to 128 chars).
_BCRYPT_MAX_BYTES = 72
_BCRYPT_ROUNDS = 12


def _to_bcrypt_bytes(password: str) -> bytes:
    """Encode a password to UTF-8 and truncate to bcrypt's 72-byte limit."""
    return password.encode("utf-8")[:_BCRYPT_MAX_BYTES]


def hash_password(password: str) -> str:
    """Hash a password using bcrypt (cost factor 12)."""
    pw_bytes = _to_bcrypt_bytes(password)
    hashed = bcrypt.hashpw(pw_bytes, bcrypt.gensalt(rounds=_BCRYPT_ROUNDS))
    return hashed.decode("utf-8")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its bcrypt hash."""
    try:
        pw_bytes = _to_bcrypt_bytes(plain_password)
        return bcrypt.checkpw(pw_bytes, hashed_password.encode("utf-8"))
    except (ValueError, TypeError):
        # Malformed hash (e.g. legacy/corrupt data) — treat as no match rather
        # than raising, so a bad stored hash can't crash the login endpoint.
        return False


# ── Token Creation ────────────────────────────────────────────────────────────

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT access token. Each token gets a unique `jti` so two
    tokens minted in the same second for the same user are never identical
    — this also gives a hook for a future Redis-backed revocation list."""
    import uuid as _uuid

    to_encode = data.copy()
    now = datetime.now(timezone.utc)
    expire = now + (expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({
        "exp": expire,
        "iat": now,
        "jti": _uuid.uuid4().hex,
        "type": "access",
    })
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def create_refresh_token(data: dict) -> str:
    """Create a JWT refresh token with longer expiry and a unique `jti`."""
    import uuid as _uuid

    to_encode = data.copy()
    now = datetime.now(timezone.utc)
    expire = now + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({
        "exp": expire,
        "iat": now,
        "jti": _uuid.uuid4().hex,
        "type": "refresh",
    })
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_token(token: str) -> dict:
    """Decode and validate a JWT token."""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        return payload
    except JWTError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid token: {str(e)}",
            headers={"WWW-Authenticate": "Bearer"},
        )


# ── User Retrieval ────────────────────────────────────────────────────────────

async def get_user_by_username_or_email(
    identifier: str, db: AsyncSession
) -> Optional[User]:
    """Find user by username or email address."""
    result = await db.execute(
        select(User).where(
            (User.username == identifier.lower()) |
            (User.email == identifier.lower())
        )
    )
    return result.scalar_one_or_none()


async def get_user_by_id(user_id: int, db: AsyncSession) -> Optional[User]:
    """Find user by ID."""
    result = await db.execute(select(User).where(User.id == user_id))
    return result.scalar_one_or_none()


# ── FastAPI Dependencies ──────────────────────────────────────────────────────

async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: AsyncSession = Depends(get_db),
) -> User:
    """
    FastAPI dependency – extracts and validates the JWT bearer token,
    then returns the active User object.
    """
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    payload = decode_token(credentials.credentials)

    if payload.get("type") != "access":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token type",
        )

    user_id: Optional[int] = payload.get("sub")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token missing user ID",
        )

    user = await get_user_by_id(int(user_id), db)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
        )
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is disabled",
        )
    return user


async def get_current_active_user(
    current_user: User = Depends(get_current_user),
) -> User:
    """Dependency that ensures the user is active."""
    return current_user


# ── Role-Based Access Control ─────────────────────────────────────────────────

class RequireRole:
    """Dependency factory for role-based access control."""

    def __init__(self, *allowed_roles: UserRole):
        self.allowed_roles = set(allowed_roles)

    async def __call__(
        self, current_user: User = Depends(get_current_user)
    ) -> User:
        if current_user.role not in self.allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"This action requires one of these roles: "
                       f"{', '.join(r.value for r in self.allowed_roles)}",
            )
        return current_user


# Convenience role checkers
require_admin = RequireRole(UserRole.ADMIN)
require_analyst = RequireRole(UserRole.ADMIN, UserRole.ANALYST)
require_any_role = RequireRole(UserRole.ADMIN, UserRole.ANALYST, UserRole.VIEWER)


# ── User Authenticate ─────────────────────────────────────────────────────────

async def authenticate_user(
    identifier: str, password: str, db: AsyncSession
) -> Optional[User]:
    """
    Authenticate a user by username/email and password.
    Returns the User object on success, None on failure.
    """
    user = await get_user_by_username_or_email(identifier, db)
    if not user:
        return None
    if not verify_password(password, user.hashed_password):
        return None
    if not user.is_active:
        return None
    return user
