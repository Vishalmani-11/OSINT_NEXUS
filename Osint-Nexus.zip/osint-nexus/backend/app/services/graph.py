"""
OSINT Nexus - Graph Intelligence Service
Neo4j-backed relationship graph for OSINT entity mapping.
Provides create/query operations for Person, Username, Profile, Email, Image nodes.
"""
import logging
from typing import List, Dict, Any, Optional

from app.config import settings

logger = logging.getLogger(__name__)

# ── Neo4j driver availability check ──────────────────────────────────────────
NEO4J_AVAILABLE = False
driver = None

try:
    from neo4j import AsyncGraphDatabase, AsyncDriver
    NEO4J_AVAILABLE = True
    logger.info("✓ Neo4j driver available")
except ImportError:
    logger.warning("⚠ neo4j package not installed. Graph features disabled.")


class GraphService:
    """
    Service for managing the OSINT entity relationship graph in Neo4j.

    Node types: Person, Username, SocialProfile, Email, Website, Image
    Edge types: HAS_USERNAME, HAS_PROFILE, HAS_EMAIL, HAS_WEBSITE, HAS_IMAGE,
                RELATED_TO, SAME_AS
    """

    def __init__(self):
        self._driver: Optional[Any] = None

    async def get_driver(self):
        """Get or create the Neo4j async driver."""
        if not NEO4J_AVAILABLE:
            return None
        if self._driver is None:
            try:
                from neo4j import AsyncGraphDatabase
                self._driver = AsyncGraphDatabase.driver(
                    settings.NEO4J_URL,
                    auth=(settings.NEO4J_USER, settings.NEO4J_PASSWORD),
                )
                # Verify connectivity
                await self._driver.verify_connectivity()
                logger.info("✓ Connected to Neo4j at %s", settings.NEO4J_URL)
            except Exception as e:
                logger.error("Neo4j connection failed: %s", e)
                self._driver = None
        return self._driver

    async def close(self):
        """Close the Neo4j connection."""
        if self._driver:
            await self._driver.close()
            self._driver = None

    # ── Schema Setup ─────────────────────────────────────────────────────────

    async def setup_schema(self) -> bool:
        """Create indexes and constraints in Neo4j. Returns True only if a
        real connection was made and constraints were applied — callers
        should log accordingly rather than assume success just because no
        exception was raised."""
        driver = await self.get_driver()
        if not driver:
            return False

        constraints = [
            "CREATE CONSTRAINT IF NOT EXISTS FOR (p:Person) REQUIRE p.id IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (u:Username) REQUIRE (u.value, u.platform) IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (e:Email) REQUIRE e.address IS UNIQUE",
            "CREATE CONSTRAINT IF NOT EXISTS FOR (w:Website) REQUIRE w.url IS UNIQUE",
            "CREATE INDEX IF NOT EXISTS FOR (p:Person) ON (p.case_id)",
            "CREATE INDEX IF NOT EXISTS FOR (u:Username) ON (u.platform)",
        ]

        async with driver.session(database=settings.NEO4J_DATABASE) as session:
            for cypher in constraints:
                try:
                    await session.run(cypher)
                except Exception as e:
                    logger.warning("Schema setup warning: %s", e)
        return True

    # ── Person Operations ─────────────────────────────────────────────────────

    async def create_person(
        self, subject_id: int, name: str, case_id: int, properties: Dict = None
    ) -> Optional[Dict]:
        """Create or update a Person node."""
        driver = await self.get_driver()
        if not driver:
            return self._mock_node("Person", subject_id, name)

        async with driver.session(database=settings.NEO4J_DATABASE) as session:
            result = await session.run(
                """
                MERGE (p:Person {id: $id})
                ON CREATE SET
                    p.name = $name,
                    p.case_id = $case_id,
                    p.created_at = datetime()
                ON MATCH SET
                    p.name = $name,
                    p.updated_at = datetime()
                RETURN p
                """,
                id=f"subject:{subject_id}",
                name=name,
                case_id=case_id,
            )
            record = await result.single()
            return dict(record["p"]) if record else None

    # ── Username Operations ───────────────────────────────────────────────────

    async def link_username(
        self, subject_id: int, username: str, platform: str = "unknown"
    ):
        """Link a Person to a Username node."""
        driver = await self.get_driver()
        if not driver:
            return

        async with driver.session(database=settings.NEO4J_DATABASE) as session:
            await session.run(
                """
                MATCH (p:Person {id: $person_id})
                MERGE (u:Username {value: $username, platform: $platform})
                ON CREATE SET u.created_at = datetime()
                MERGE (p)-[r:HAS_USERNAME]->(u)
                ON CREATE SET r.created_at = datetime()
                """,
                person_id=f"subject:{subject_id}",
                username=username,
                platform=platform,
            )

    async def link_social_profile(
        self, username: str, platform: str, profile_url: str
    ):
        """Link a Username to a discovered SocialProfile."""
        driver = await self.get_driver()
        if not driver:
            return

        async with driver.session(database=settings.NEO4J_DATABASE) as session:
            await session.run(
                """
                MERGE (u:Username {value: $username, platform: $platform})
                MERGE (sp:SocialProfile {url: $url})
                ON CREATE SET sp.platform = $platform, sp.created_at = datetime()
                MERGE (u)-[r:HAS_PROFILE]->(sp)
                ON CREATE SET r.created_at = datetime()
                """,
                username=username,
                platform=platform,
                url=profile_url,
            )

    async def link_email(self, subject_id: int, email: str):
        """Link a Person to an Email address."""
        driver = await self.get_driver()
        if not driver:
            return

        async with driver.session(database=settings.NEO4J_DATABASE) as session:
            await session.run(
                """
                MATCH (p:Person {id: $person_id})
                MERGE (e:Email {address: $email})
                ON CREATE SET e.created_at = datetime()
                MERGE (p)-[r:HAS_EMAIL]->(e)
                ON CREATE SET r.created_at = datetime()
                """,
                person_id=f"subject:{subject_id}",
                email=email,
            )

    async def link_website(self, subject_id: int, website: str):
        """Link a Person to a Website."""
        driver = await self.get_driver()
        if not driver:
            return

        async with driver.session(database=settings.NEO4J_DATABASE) as session:
            await session.run(
                """
                MATCH (p:Person {id: $person_id})
                MERGE (w:Website {url: $url})
                ON CREATE SET w.created_at = datetime()
                MERGE (p)-[r:HAS_WEBSITE]->(w)
                ON CREATE SET r.created_at = datetime()
                """,
                person_id=f"subject:{subject_id}",
                url=website,
            )

    async def link_image(self, subject_id: int, image_id: int, image_path: str):
        """Link a Person to an Image embedding."""
        driver = await self.get_driver()
        if not driver:
            return

        async with driver.session(database=settings.NEO4J_DATABASE) as session:
            await session.run(
                """
                MATCH (p:Person {id: $person_id})
                MERGE (img:Image {id: $image_id})
                ON CREATE SET img.path = $path, img.created_at = datetime()
                MERGE (p)-[r:HAS_IMAGE]->(img)
                ON CREATE SET r.created_at = datetime()
                """,
                person_id=f"subject:{subject_id}",
                image_id=f"image:{image_id}",
                path=image_path,
            )

    # ── Graph Query ───────────────────────────────────────────────────────────

    async def get_case_graph(
        self, case_id: int, max_depth: int = 3
    ) -> Dict[str, Any]:
        """Get the full relationship graph for a case."""
        driver = await self.get_driver()
        if not driver:
            return self._mock_graph(case_id)

        async with driver.session(database=settings.NEO4J_DATABASE) as session:
            result = await session.run(
                f"""
                MATCH (p:Person {{case_id: $case_id}})
                CALL apoc.path.subgraphAll(p, {{maxLevel: {max_depth}}})
                YIELD nodes, relationships
                RETURN nodes, relationships
                """,
                case_id=case_id,
            )
            records = await result.data()

            nodes = []
            edges = []
            seen_nodes = set()
            seen_edges = set()

            for record in records:
                for node in record.get("nodes", []):
                    node_id = str(node.id)
                    if node_id not in seen_nodes:
                        seen_nodes.add(node_id)
                        labels = list(node.labels)
                        nodes.append({
                            "id": node_id,
                            "label": dict(node).get("name") or dict(node).get("value") or
                                     dict(node).get("address") or dict(node).get("url") or node_id,
                            "type": labels[0].lower() if labels else "unknown",
                            "properties": dict(node),
                        })

                for rel in record.get("relationships", []):
                    edge_id = str(rel.id)
                    if edge_id not in seen_edges:
                        seen_edges.add(edge_id)
                        edges.append({
                            "id": edge_id,
                            "source": str(rel.start_node.id),
                            "target": str(rel.end_node.id),
                            "label": rel.type,
                            "properties": dict(rel),
                        })

        return {
            "nodes": nodes,
            "edges": edges,
            "node_count": len(nodes),
            "edge_count": len(edges),
        }

    async def get_subject_graph(self, subject_id: int) -> Dict[str, Any]:
        """Get the relationship graph for a single subject."""
        driver = await self.get_driver()
        if not driver:
            return self._mock_graph(subject_id)

        async with driver.session(database=settings.NEO4J_DATABASE) as session:
            result = await session.run(
                """
                MATCH (p:Person {id: $person_id})-[r*1..3]-(related)
                RETURN p, r, related
                """,
                person_id=f"subject:{subject_id}",
            )
            # Process results (same as above)
            return {"nodes": [], "edges": [], "node_count": 0, "edge_count": 0}

    async def delete_case_graph(self, case_id: int):
        """Remove all nodes associated with a case."""
        driver = await self.get_driver()
        if not driver:
            return

        async with driver.session(database=settings.NEO4J_DATABASE) as session:
            await session.run(
                """
                MATCH (p:Person {case_id: $case_id})
                CALL apoc.node.delete(p, []) YIELD value
                RETURN count(value)
                """,
                case_id=case_id,
            )

    # ── Mock Data (when Neo4j is unavailable) ─────────────────────────────────

    def _mock_node(self, type_: str, id_: int, label: str) -> Dict:
        return {"id": f"{type_.lower()}:{id_}", "type": type_.lower(), "name": label}

    def _mock_graph(self, case_id: int) -> Dict[str, Any]:
        """Return a demo graph structure when Neo4j is not available."""
        nodes = [
            {"id": "person:1", "label": "John Doe", "type": "person", "properties": {"case_id": case_id}},
            {"id": "username:1", "label": "johndoe", "type": "username", "properties": {"platform": "github"}},
            {"id": "profile:1", "label": "github.com/johndoe", "type": "socialprofile", "properties": {}},
            {"id": "email:1", "label": "john@example.com", "type": "email", "properties": {}},
        ]
        edges = [
            {"id": "e1", "source": "person:1", "target": "username:1", "label": "HAS_USERNAME", "properties": {}},
            {"id": "e2", "source": "username:1", "target": "profile:1", "label": "HAS_PROFILE", "properties": {}},
            {"id": "e3", "source": "person:1", "target": "email:1", "label": "HAS_EMAIL", "properties": {}},
        ]
        return {"nodes": nodes, "edges": edges, "node_count": len(nodes), "edge_count": len(edges)}


# Module-level singleton
graph_service = GraphService()
