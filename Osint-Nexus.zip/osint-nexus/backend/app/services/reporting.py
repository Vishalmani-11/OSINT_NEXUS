"""
OSINT Nexus - Report Generation Service
Generates PDF, HTML, and JSON investigation reports using ReportLab and Jinja2.
"""
import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional

from jinja2 import Environment, BaseLoader

from app.config import settings

logger = logging.getLogger(__name__)


# ── HTML Report Template ──────────────────────────────────────────────────────
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ report.title }}</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #0a0f1a; color: #e2e8f0; }
        .container { max-width: 1100px; margin: 0 auto; padding: 2rem; }
        header { background: linear-gradient(135deg, #0d1b2a, #1a3a5c); padding: 2rem;
                 border-left: 4px solid #00ff88; margin-bottom: 2rem; }
        header h1 { font-size: 2rem; color: #00ff88; letter-spacing: 2px; }
        header .meta { color: #94a3b8; margin-top: 0.5rem; font-size: 0.9rem; }
        .section { background: #111827; border: 1px solid #1e3a5c; border-radius: 8px;
                   padding: 1.5rem; margin-bottom: 1.5rem; }
        .section h2 { color: #60a5fa; font-size: 1.2rem; margin-bottom: 1rem;
                      padding-bottom: 0.5rem; border-bottom: 1px solid #1e3a5c; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 4px;
                 font-size: 0.75rem; font-weight: bold; }
        .badge-open { background: #064e3b; color: #10b981; }
        .badge-active { background: #1e3a5c; color: #60a5fa; }
        .badge-closed { background: #1f2937; color: #9ca3af; }
        .badge-high { background: #7f1d1d; color: #f87171; }
        .badge-medium { background: #78350f; color: #fbbf24; }
        .badge-low { background: #1e3a5c; color: #60a5fa; }
        .badge-critical { background: #7f1d1d; color: #ff0000; }
        .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; }
        .stat-card { background: #0d1b2a; border: 1px solid #1e3a5c; border-radius: 6px;
                     padding: 1rem; text-align: center; }
        .stat-value { font-size: 2rem; font-weight: bold; color: #00ff88; }
        .stat-label { color: #94a3b8; font-size: 0.85rem; margin-top: 0.25rem; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #0d1b2a; color: #60a5fa; padding: 0.75rem; text-align: left;
             font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; }
        td { padding: 0.75rem; border-bottom: 1px solid #1e3a5c; font-size: 0.9rem; }
        tr:last-child td { border-bottom: none; }
        .found { color: #10b981; }
        .not-found { color: #6b7280; }
        .timeline-item { display: flex; gap: 1rem; margin-bottom: 1rem; }
        .timeline-dot { width: 10px; height: 10px; background: #00ff88; border-radius: 50%;
                        margin-top: 5px; flex-shrink: 0; }
        .timeline-line { width: 2px; background: #1e3a5c; margin-left: 4px; }
        .evidence-item { background: #0d1b2a; border: 1px solid #1e3a5c; border-radius: 6px;
                         padding: 1rem; margin-bottom: 0.75rem; }
        .tag { display: inline-block; background: #1e3a5c; color: #60a5fa; padding: 2px 6px;
               border-radius: 4px; font-size: 0.75rem; margin: 2px; }
        footer { text-align: center; color: #374151; font-size: 0.8rem;
                 margin-top: 3rem; padding-top: 1.5rem; border-top: 1px solid #1e3a5c; }
        .monospace { font-family: 'Courier New', monospace; font-size: 0.85rem; color: #94a3b8; }
    </style>
</head>
<body>
<div class="container">
    <header>
        <h1>🔍 OSINT NEXUS</h1>
        <div class="meta">Investigation Report — CONFIDENTIAL</div>
        <div class="meta">{{ report.title }}</div>
        <div class="meta">Generated: {{ generated_at }} | Case: {{ case.case_number }}</div>
    </header>

    <!-- Summary Stats -->
    {% if include_summary %}
    <div class="section">
        <h2>Investigation Summary</h2>
        <div style="margin-bottom: 1rem;">
            <strong>Case:</strong> {{ case.title }}&nbsp;&nbsp;
            <span class="badge badge-{{ case.status }}">{{ case.status.upper() }}</span>&nbsp;&nbsp;
            <span class="badge badge-{{ case.priority }}">{{ case.priority.upper() }}</span>
        </div>
        {% if case.description %}<p style="color: #94a3b8; margin-bottom: 1rem;">{{ case.description }}</p>{% endif %}
        <div class="grid">
            <div class="stat-card">
                <div class="stat-value">{{ stats.subjects }}</div>
                <div class="stat-label">Subjects</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ stats.username_searches }}</div>
                <div class="stat-label">Username Searches</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ stats.profiles_found }}</div>
                <div class="stat-label">Profiles Found</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ stats.face_embeddings }}</div>
                <div class="stat-label">Face Analyses</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ stats.evidence_items }}</div>
                <div class="stat-label">Evidence Items</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{{ stats.notes }}</div>
                <div class="stat-label">Analyst Notes</div>
            </div>
        </div>
    </div>
    {% endif %}

    <!-- Subjects -->
    {% if subjects %}
    <div class="section">
        <h2>Investigation Subjects</h2>
        {% for subject in subjects %}
        <div style="background: #0d1b2a; padding: 1rem; border-radius: 6px; margin-bottom: 0.75rem; border-left: 3px solid #00ff88;">
            <strong style="color: #e2e8f0;">{{ subject.name }}</strong>
            {% if subject.aliases %}<br><span style="color: #94a3b8;">Aliases: {{ subject.aliases|join(', ') }}</span>{% endif %}
            {% if subject.emails %}<br><span style="color: #60a5fa;">Emails: {{ subject.emails|join(', ') }}</span>{% endif %}
        </div>
        {% endfor %}
    </div>
    {% endif %}

    <!-- Username Searches -->
    {% if username_searches %}
    <div class="section">
        <h2>Username Investigation Results</h2>
        {% for search in username_searches %}
        <div style="margin-bottom: 1.5rem;">
            <h3 style="color: #00ff88; margin-bottom: 0.75rem;">@{{ search.username }} — {{ search.total_found }}/{{ search.total_checked }} platforms found</h3>
            <table>
                <thead><tr><th>Platform</th><th>URL</th><th>Status</th></tr></thead>
                <tbody>
                {% for profile in search.profiles %}
                <tr>
                    <td>{{ profile.platform }}</td>
                    <td class="monospace"><a href="{{ profile.url }}" style="color: #60a5fa;">{{ profile.url }}</a></td>
                    <td>{% if profile.is_found %}<span class="found">● FOUND</span>{% else %}<span class="not-found">○ Not Found</span>{% endif %}</td>
                </tr>
                {% endfor %}
                </tbody>
            </table>
        </div>
        {% endfor %}
    </div>
    {% endif %}

    <!-- Evidence -->
    {% if include_evidence and evidence %}
    <div class="section">
        <h2>Evidence Collected</h2>
        {% for item in evidence %}
        <div class="evidence-item">
            <strong style="color: #e2e8f0;">{{ item.title }}</strong>
            <span style="float: right;" class="badge badge-medium">{{ item.evidence_type.upper() }}</span>
            {% if item.description %}<p style="color: #94a3b8; margin: 0.5rem 0; font-size: 0.9rem;">{{ item.description }}</p>{% endif %}
            {% if item.url %}<a href="{{ item.url }}" style="color: #60a5fa; font-size: 0.85rem;" class="monospace">{{ item.url }}</a>{% endif %}
            {% if item.tags %}
            <div style="margin-top: 0.5rem;">{% for tag in item.tags %}<span class="tag">{{ tag }}</span>{% endfor %}</div>
            {% endif %}
        </div>
        {% endfor %}
    </div>
    {% endif %}

    <!-- Notes -->
    {% if notes %}
    <div class="section">
        <h2>Analyst Notes</h2>
        {% for note in notes %}
        <div style="background: #0d1b2a; padding: 1rem; border-radius: 6px; margin-bottom: 0.75rem;">
            <p style="color: #e2e8f0;">{{ note.content }}</p>
            <p style="color: #374151; font-size: 0.8rem; margin-top: 0.5rem;">{{ note.created_at }}</p>
        </div>
        {% endfor %}
    </div>
    {% endif %}

    <footer>
        <p>OSINT Nexus — Educational OSINT Learning Platform</p>
        <p>Generated {{ generated_at }} — This report is for authorized investigation purposes only.</p>
        <p>Data sourced from publicly available information and authorized datasets.</p>
    </footer>
</div>
</body>
</html>
"""


class ReportingService:
    """Service for generating investigation reports in PDF, HTML, and JSON formats."""

    REPORTS_DIR = Path(settings.UPLOAD_DIR) / "reports"

    def __init__(self):
        self.REPORTS_DIR.mkdir(parents=True, exist_ok=True)

    async def generate_html(
        self, report_data: Dict[str, Any], output_path: str
    ) -> bool:
        """Generate an HTML report from investigation data."""
        try:
            env = Environment(loader=BaseLoader())
            template = env.from_string(HTML_TEMPLATE)

            html_content = template.render(
                **report_data,
                generated_at=datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
            )

            Path(output_path).write_text(html_content, encoding="utf-8")
            logger.info("HTML report generated: %s", output_path)
            return True
        except Exception as e:
            logger.error("HTML report generation failed: %s", e)
            return False

    async def generate_pdf(
        self, report_data: Dict[str, Any], output_path: str
    ) -> bool:
        """Generate a PDF report using ReportLab."""
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import cm
            from reportlab.lib import colors
            from reportlab.platypus import (
                SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
            )
            from reportlab.lib.colors import HexColor

            # Color palette
            BG_DARK = HexColor("#0a0f1a")
            ACCENT_GREEN = HexColor("#00ff88")
            BLUE = HexColor("#60a5fa")
            GRAY = HexColor("#94a3b8")
            WHITE = HexColor("#e2e8f0")

            doc = SimpleDocTemplate(
                output_path,
                pagesize=A4,
                rightMargin=2*cm,
                leftMargin=2*cm,
                topMargin=2*cm,
                bottomMargin=2*cm,
            )

            styles = getSampleStyleSheet()
            style_title = ParagraphStyle(
                "CustomTitle",
                fontSize=22, textColor=ACCENT_GREEN, spaceAfter=12,
                fontName="Helvetica-Bold",
            )
            style_h2 = ParagraphStyle(
                "CustomH2",
                fontSize=14, textColor=BLUE, spaceAfter=8, spaceBefore=16,
                fontName="Helvetica-Bold",
            )
            style_body = ParagraphStyle(
                "CustomBody",
                fontSize=10, textColor=WHITE, spaceAfter=6,
            )
            style_small = ParagraphStyle(
                "CustomSmall",
                fontSize=8, textColor=GRAY, spaceAfter=4,
            )

            story = []
            case = report_data.get("case", {})
            report = report_data.get("report", {})
            stats = report_data.get("stats", {})

            # Header
            story.append(Paragraph("🔍 OSINT NEXUS — Investigation Report", style_title))
            story.append(Paragraph(
                f"Case: {case.get('case_number', 'N/A')} | {case.get('title', '')}",
                style_body
            ))
            story.append(Paragraph(
                f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}",
                style_small
            ))
            story.append(HRFlowable(color=ACCENT_GREEN, thickness=1, spaceAfter=12))

            # Stats
            story.append(Paragraph("Investigation Summary", style_h2))
            stat_data = [
                ["Metric", "Value"],
                ["Subjects Investigated", str(stats.get("subjects", 0))],
                ["Username Searches", str(stats.get("username_searches", 0))],
                ["Social Profiles Found", str(stats.get("profiles_found", 0))],
                ["Face Analyses", str(stats.get("face_embeddings", 0))],
                ["Evidence Items", str(stats.get("evidence_items", 0))],
            ]
            table = Table(stat_data, colWidths=[10*cm, 5*cm])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), BLUE),
                ('TEXTCOLOR', (0, 0), (-1, 0), WHITE),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [HexColor("#111827"), HexColor("#0d1b2a")]),
                ('TEXTCOLOR', (0, 1), (-1, -1), WHITE),
                ('GRID', (0, 0), (-1, -1), 0.5, HexColor("#1e3a5c")),
                ('PADDING', (0, 0), (-1, -1), 8),
            ]))
            story.append(table)
            story.append(Spacer(1, 0.5*cm))

            # Username Searches
            for search in report_data.get("username_searches", []):
                story.append(Paragraph(
                    f"Username: @{search.get('username', '')} — "
                    f"{search.get('total_found', 0)}/{search.get('total_checked', 0)} found",
                    style_h2
                ))
                profiles = search.get("profiles", [])
                found_profiles = [p for p in profiles if p.get("is_found")]
                if found_profiles:
                    profile_data = [["Platform", "URL"]]
                    for p in found_profiles[:20]:  # Limit to 20 for PDF
                        profile_data.append([p.get("platform", ""), p.get("url", "")])
                    ptable = Table(profile_data, colWidths=[6*cm, 10*cm])
                    ptable.setStyle(TableStyle([
                        ('BACKGROUND', (0, 0), (-1, 0), BLUE),
                        ('TEXTCOLOR', (0, 0), (-1, 0), WHITE),
                        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                        ('FONTSIZE', (0, 0), (-1, -1), 8),
                        ('TEXTCOLOR', (0, 1), (-1, -1), GRAY),
                        ('GRID', (0, 0), (-1, -1), 0.3, HexColor("#1e3a5c")),
                        ('PADDING', (0, 0), (-1, -1), 6),
                    ]))
                    story.append(ptable)

            # Evidence section
            if report_data.get("evidence"):
                story.append(Paragraph("Evidence Collected", style_h2))
                for item in report_data["evidence"]:
                    story.append(Paragraph(
                        f"<b>{item.get('title', '')}</b> [{item.get('evidence_type', '').upper()}]",
                        style_body
                    ))
                    if item.get("description"):
                        story.append(Paragraph(item["description"], style_small))
                    story.append(Spacer(1, 0.2*cm))

            # Footer
            story.append(Spacer(1, 1*cm))
            story.append(HRFlowable(color=GRAY, thickness=0.5))
            story.append(Paragraph(
                "OSINT Nexus — Educational OSINT Learning Platform — For authorized use only.",
                style_small
            ))

            doc.build(story)
            logger.info("PDF report generated: %s", output_path)
            return True

        except ImportError:
            logger.warning("ReportLab not available for PDF. Generating HTML instead.")
            html_path = output_path.replace(".pdf", ".html")
            return await self.generate_html(report_data, html_path)
        except Exception as e:
            logger.error("PDF generation failed: %s", e)
            return False

    async def generate_json(
        self, report_data: Dict[str, Any], output_path: str
    ) -> bool:
        """Generate a JSON report (machine-readable format)."""
        try:
            # Clean data for JSON serialization
            clean_data = self._prepare_json_data(report_data)
            json_content = json.dumps(clean_data, indent=2, default=str, ensure_ascii=False)
            Path(output_path).write_text(json_content, encoding="utf-8")
            logger.info("JSON report generated: %s", output_path)
            return True
        except Exception as e:
            logger.error("JSON report generation failed: %s", e)
            return False

    def _prepare_json_data(self, data: Dict) -> Dict:
        """Recursively prepare data for JSON serialization."""
        if isinstance(data, dict):
            return {k: self._prepare_json_data(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._prepare_json_data(i) for i in data]
        elif isinstance(data, datetime):
            return data.isoformat()
        elif hasattr(data, "__dict__"):
            return self._prepare_json_data(data.__dict__)
        return data

    def get_output_path(self, report_uuid: str, format_: str) -> str:
        """Get the output file path for a report."""
        ext_map = {"pdf": "pdf", "html": "html", "json": "json"}
        ext = ext_map.get(format_, "txt")
        return str(self.REPORTS_DIR / f"report_{report_uuid}.{ext}")


# Module-level singleton
reporting_service = ReportingService()
