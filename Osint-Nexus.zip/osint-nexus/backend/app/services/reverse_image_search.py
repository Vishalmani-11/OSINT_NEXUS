"""
OSINT Nexus - Reverse Image Search Service
Searches the live web for image matches using Google Images, Yandex,
TinEye, and Bing Visual Search.

All searches use publicly accessible URLs — no private API access,
no facial-recognition databases, no biometric processing.
Results are links to where the image appears publicly online.

Optional: set SERPAPI_KEY in environment to get actual result lists
from Google Lens / Google Images via SerpAPI (free tier: 100/month).
"""
import asyncio
import base64
import hashlib
import logging
import mimetypes
import os
import time
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import aiohttp

from app.config import settings

logger = logging.getLogger(__name__)

# ── SerpAPI (optional) ────────────────────────────────────────────
SERPAPI_KEY = os.getenv("SERPAPI_KEY", "")
SERPAPI_AVAILABLE = bool(SERPAPI_KEY)

# ── TinEye API (optional, free tier 100/month) ────────────────────
TINEYE_API_KEY = os.getenv("TINEYE_API_KEY", "")
TINEYE_AVAILABLE = bool(TINEYE_API_KEY)


@dataclass
class ReverseSearchResult:
    """A single match found on the web."""
    source: str                        # e.g. "Google Images", "TinEye"
    url: str                           # direct link to the page/image
    title: str = ""                    # page title or description
    thumbnail_url: str = ""            # thumbnail of the matching image
    image_url: str = ""                # direct URL of the matched image
    score: Optional[float] = None      # 0.0-1.0 similarity (if available)
    domain: str = ""                   # e.g. "twitter.com"
    width: Optional[int] = None
    height: Optional[int] = None


@dataclass
class ReverseSearchSession:
    """Complete results from a reverse image search."""
    filename: str
    file_hash: str
    file_size: int
    image_width: Optional[int] = None
    image_height: Optional[int] = None
    exif_data: dict = field(default_factory=dict)
    search_links: dict = field(default_factory=dict)   # engine -> search URL
    results: list = field(default_factory=list)        # ReverseSearchResult items
    total_found: int = 0
    search_duration_ms: int = 0
    engines_searched: list = field(default_factory=list)
    error: Optional[str] = None


class ReverseImageSearchService:
    """
    Upload an image and find where it appears publicly on the web.

    Works in two modes:
    - FREE (always):   generates deep-link search URLs the analyst can open
                       in a browser — Google Images, Yandex, TinEye, Bing
    - API (optional):  if SERPAPI_KEY is set, actually fetches Google Lens
                       results and returns structured match data
    """

    UPLOAD_DIR = Path(settings.UPLOAD_DIR) / "images"

    def __init__(self):
        self.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

    # ── Image Saving ──────────────────────────────────────────────

    async def save_upload(self, filename: str, content: bytes) -> str:
        """Save uploaded image, deduplicating by content hash."""
        content_hash = hashlib.sha256(content).hexdigest()[:16]
        ext = Path(filename).suffix.lower() or ".jpg"
        if ext not in (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"):
            ext = ".jpg"
        save_path = self.UPLOAD_DIR / f"{content_hash}{ext}"
        if not save_path.exists():
            save_path.write_bytes(content)
        return str(save_path), content_hash

    # ── Image Metadata ────────────────────────────────────────────

    def get_image_info(self, image_path: str) -> dict:
        """Extract dimensions and EXIF metadata from image."""
        info = {"width": None, "height": None, "exif": {}}
        try:
            import cv2, numpy as np
            img = cv2.imread(image_path)
            if img is not None:
                h, w = img.shape[:2]
                info["width"] = w
                info["height"] = h
        except Exception:
            pass

        try:
            from PIL import Image as PILImage
            from PIL.ExifTags import TAGS
            with PILImage.open(image_path) as im:
                if info["width"] is None:
                    info["width"], info["height"] = im.size
                raw = im._getexif() if hasattr(im, "_getexif") else None
                if raw:
                    info["exif"] = {
                        TAGS.get(k, k): str(v)[:200]
                        for k, v in raw.items()
                        if isinstance(v, (str, int, float, bytes))
                    }
        except Exception:
            pass

        return info

    # ── Search URL Generation (always free, no API key required) ──

    def build_search_links(self, image_path: str, public_url: str = "") -> dict:
        """
        Generate deep-link URLs to reverse-search this image on major engines.
        
        If `public_url` is provided (e.g. the image is served at a public URL
        from your server), the links will use it directly.
        
        Returns a dict of engine -> search URL the analyst can open in browser.
        """
        links = {}

        if public_url:
            enc = urllib.parse.quote_plus(public_url)

            # Google Images reverse search
            links["Google Images"] = (
                f"https://www.google.com/searchbyimage?image_url={enc}"
                f"&safe=off"
            )
            # Google Lens (newer interface)
            links["Google Lens"] = (
                f"https://lens.google.com/uploadbyurl?url={enc}"
            )
            # Yandex Images (often finds social media profiles Google misses)
            links["Yandex Images"] = (
                f"https://yandex.com/images/search?url={enc}&rpt=imageview"
            )
            # Bing Visual Search
            links["Bing Visual Search"] = (
                f"https://www.bing.com/images/searchbyimage?FORM=IRSBIQ"
                f"&cbir=sbi&imgurl={enc}"
            )
            # TinEye (best for finding image reposts/copies)
            links["TinEye"] = (
                f"https://tineye.com/search?url={enc}"
            )

        # These always work — they open the upload interface
        links["Google Images (Upload)"] = "https://images.google.com/"
        links["Google Lens (Upload)"]   = "https://lens.google.com/"
        links["Yandex (Upload)"]        = "https://yandex.com/images/"
        links["TinEye (Upload)"]        = "https://tineye.com/"
        links["Bing Visual (Upload)"]   = "https://www.bing.com/visualsearch"

        return links

    # ── SerpAPI Google Lens (returns actual results) ──────────────

    async def search_via_serpapi(
        self, image_path: str, public_url: str = ""
    ) -> list[ReverseSearchResult]:
        """
        Use SerpAPI's Google Lens endpoint to get actual result URLs.
        Requires SERPAPI_KEY environment variable.
        Free tier: 100 searches/month at serpapi.com
        """
        if not SERPAPI_AVAILABLE:
            return []

        params = {
            "engine": "google_lens",
            "api_key": SERPAPI_KEY,
        }

        if public_url:
            params["url"] = public_url
        else:
            # Encode as base64 data URI
            with open(image_path, "rb") as f:
                img_bytes = f.read()
            mime = mimetypes.guess_type(image_path)[0] or "image/jpeg"
            b64 = base64.b64encode(img_bytes).decode()
            params["image_content"] = f"data:{mime};base64,{b64}"

        results = []
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    "https://serpapi.com/search.json",
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    data = await resp.json()

                    # Visual matches
                    for item in data.get("visual_matches", []):
                        results.append(ReverseSearchResult(
                            source="Google Lens",
                            url=item.get("link", ""),
                            title=item.get("title", ""),
                            thumbnail_url=item.get("thumbnail", ""),
                            image_url=item.get("image", ""),
                            domain=item.get("source", ""),
                            width=item.get("image_width"),
                            height=item.get("image_height"),
                        ))

                    # Exact / similar image matches
                    for item in data.get("image_results", []):
                        results.append(ReverseSearchResult(
                            source="Google Images",
                            url=item.get("original_image", {}).get("link", item.get("link", "")),
                            title=item.get("title", ""),
                            thumbnail_url=item.get("thumbnail", {}).get("link", ""),
                            domain=item.get("source", ""),
                        ))

        except Exception as exc:
            logger.error("SerpAPI Google Lens error: %s", exc)

        return results

    # ── TinEye API (returns exact copies found online) ─────────────

    async def search_via_tineye(
        self, image_path: str
    ) -> list[ReverseSearchResult]:
        """
        Search TinEye for exact image copies / reposts.
        Requires TINEYE_API_KEY.
        Free tier: 100 searches/month at tineye.com/api
        """
        if not TINEYE_AVAILABLE:
            return []

        results = []
        try:
            with open(image_path, "rb") as f:
                img_bytes = f.read()

            async with aiohttp.ClientSession() as session:
                form = aiohttp.FormData()
                form.add_field("image",
                               img_bytes,
                               filename=Path(image_path).name,
                               content_type="image/jpeg")

                async with session.post(
                    f"https://api.tineye.com/rest/search/?api_key={TINEYE_API_KEY}",
                    data=form,
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as resp:
                    data = await resp.json()
                    for match in data.get("results", {}).get("matches", []):
                        for img in match.get("image_url", []):
                            results.append(ReverseSearchResult(
                                source="TinEye",
                                url=match.get("backlinks", [{}])[0].get("url", ""),
                                title=match.get("domain", ""),
                                image_url=img,
                                domain=match.get("domain", ""),
                                score=match.get("score", None),
                                width=match.get("width"),
                                height=match.get("height"),
                            ))

        except Exception as exc:
            logger.error("TinEye API error: %s", exc)

        return results

    # ── Main Search Entry Point ───────────────────────────────────

    async def search(
        self,
        image_path: str,
        content: bytes,
        filename: str,
        public_base_url: str = "",
    ) -> ReverseSearchSession:
        """
        Main method: extract metadata, build search links, and optionally
        call APIs if keys are configured.

        Args:
            image_path:      Server-side path to the saved image file
            content:         Raw image bytes (for hashing / API upload)
            filename:        Original upload filename
            public_base_url: If set (e.g. "http://myserver.com"), builds
                             direct search links instead of upload-only links

        Returns:
            ReverseSearchSession with search links and any API results
        """
        t0 = time.time()
        file_hash = hashlib.sha256(content).hexdigest()
        file_size = len(content)

        # Build the public URL for this image (used in search links)
        public_url = ""
        if public_base_url:
            img_filename = Path(image_path).name
            public_url = f"{public_base_url.rstrip('/')}/uploads/images/{img_filename}"

        # Get image dimensions + EXIF
        info = self.get_image_info(image_path)

        # Build search deep-links (always available, no API key needed)
        search_links = self.build_search_links(image_path, public_url)

        # Optionally call real APIs for structured results
        api_results = []
        engines = ["links_generated"]

        if SERPAPI_AVAILABLE:
            logger.info("Searching via SerpAPI Google Lens...")
            serpapi_results = await self.search_via_serpapi(image_path, public_url)
            api_results.extend(serpapi_results)
            engines.append("Google Lens (SerpAPI)")

        if TINEYE_AVAILABLE:
            logger.info("Searching via TinEye API...")
            tineye_results = await self.search_via_tineye(image_path)
            api_results.extend(tineye_results)
            engines.append("TinEye")

        duration_ms = int((time.time() - t0) * 1000)

        return ReverseSearchSession(
            filename=filename,
            file_hash=file_hash,
            file_size=file_size,
            image_width=info.get("width"),
            image_height=info.get("height"),
            exif_data=info.get("exif", {}),
            search_links=search_links,
            results=api_results,
            total_found=len(api_results),
            search_duration_ms=duration_ms,
            engines_searched=engines,
        )


# Module-level singleton
reverse_image_service = ReverseImageSearchService()
