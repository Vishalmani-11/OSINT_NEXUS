"""
OSINT Nexus - Sherlock Username Investigation Service
Integrates with sherlock-project for username enumeration across social platforms.
Falls back to demo mode if sherlock is not installed.
"""
import asyncio
import json
import logging
import time
from typing import List, Dict, Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# Check if sherlock is available
SHERLOCK_AVAILABLE = False
try:
    import sherlock_project
    SHERLOCK_AVAILABLE = True
    logger.info("✓ Sherlock-project package found")
except ImportError:
    logger.warning("⚠ Sherlock not installed – using demo mode. "
                   "Install with: pip install sherlock-project")


@dataclass
class PlatformResult:
    """Result for a single platform check."""
    platform: str
    url: str
    username: str
    is_found: bool
    http_status: Optional[int]
    response_time_ms: Optional[int]
    error: Optional[str] = None


# ── Demo dataset for educational demonstration ────────────────────────────────
DEMO_PLATFORMS = [
    {"name": "GitHub",      "url": "https://github.com/{username}"},
    {"name": "Twitter",     "url": "https://twitter.com/{username}"},
    {"name": "Reddit",      "url": "https://reddit.com/u/{username}"},
    {"name": "Instagram",   "url": "https://instagram.com/{username}"},
    {"name": "LinkedIn",    "url": "https://linkedin.com/in/{username}"},
    {"name": "TikTok",      "url": "https://tiktok.com/@{username}"},
    {"name": "YouTube",     "url": "https://youtube.com/@{username}"},
    {"name": "Twitch",      "url": "https://twitch.tv/{username}"},
    {"name": "Pinterest",   "url": "https://pinterest.com/{username}"},
    {"name": "Telegram",    "url": "https://t.me/{username}"},
    {"name": "Steam",       "url": "https://steamcommunity.com/id/{username}"},
    {"name": "HackerNews",  "url": "https://news.ycombinator.com/user?id={username}"},
    {"name": "DeviantArt",  "url": "https://deviantart.com/{username}"},
    {"name": "Medium",      "url": "https://medium.com/@{username}"},
    {"name": "Keybase",     "url": "https://keybase.io/{username}"},
    {"name": "GitLab",      "url": "https://gitlab.com/{username}"},
    {"name": "Bitbucket",   "url": "https://bitbucket.org/{username}"},
    {"name": "Pastebin",    "url": "https://pastebin.com/u/{username}"},
    {"name": "Spotify",     "url": "https://open.spotify.com/user/{username}"},
    {"name": "SoundCloud",  "url": "https://soundcloud.com/{username}"},
]


class SherlockService:
    """
    Username investigation service using the Sherlock framework.

    In production, this runs actual HTTP checks against social platforms.
    In demo mode, it returns synthetic results for educational purposes.
    """

    async def search(
        self,
        username: str,
        progress_callback=None,
    ) -> List[PlatformResult]:
        """
        Run a full username search across all platforms.

        Args:
            username: The username to search for
            progress_callback: Optional async callable(checked, total, result)

        Returns:
            List of PlatformResult objects
        """
        logger.info(f"Starting username search for: @{username}")
        start_time = time.time()

        if SHERLOCK_AVAILABLE:
            results = await self._search_via_sherlock_subprocess(username, progress_callback)
        else:
            results = await self._search_demo(username, progress_callback)

        elapsed = time.time() - start_time
        found_count = sum(1 for r in results if r.is_found)
        logger.info(
            f"Search complete for @{username}: "
            f"{found_count}/{len(results)} found in {elapsed:.1f}s"
        )
        return results

    async def _search_via_sherlock_subprocess(
        self, username: str, progress_callback=None
    ) -> List[PlatformResult]:
        """
        Run sherlock as a subprocess and parse output.
        Sherlock outputs JSON when called with --json flag.
        """
        results = []
        try:
            proc = await asyncio.create_subprocess_exec(
                "python", "-m", "sherlock_project.sherlock",
                username,
                "--json",
                "--timeout", "10",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(), timeout=120
                )
            except asyncio.TimeoutError:
                proc.kill()
                logger.warning(f"Sherlock timed out for @{username}")
                return await self._search_demo(username, progress_callback)

            if stdout:
                try:
                    data = json.loads(stdout.decode("utf-8", errors="replace"))
                    results = self._parse_sherlock_json(data, username)
                except json.JSONDecodeError:
                    # Parse line-by-line output format
                    results = self._parse_sherlock_text(
                        stdout.decode("utf-8", errors="replace"), username
                    )

        except (FileNotFoundError, OSError) as e:
            logger.warning(f"Sherlock subprocess failed: {e}. Falling back to demo.")
            return await self._search_demo(username, progress_callback)

        return results if results else await self._search_demo(username, progress_callback)

    def _parse_sherlock_json(self, data: dict, username: str) -> List[PlatformResult]:
        """Parse the JSON output from sherlock --json."""
        results = []
        for platform_name, info in data.items():
            if not isinstance(info, dict):
                continue
            is_found = info.get("status", "").lower() in ("found", "claimed")
            results.append(PlatformResult(
                platform=platform_name,
                url=info.get("url", f"https://unknown.com/{username}"),
                username=username,
                is_found=is_found,
                http_status=info.get("http_status"),
                response_time_ms=int(info.get("response_time", 0) * 1000)
                    if info.get("response_time") else None,
            ))
        return results

    def _parse_sherlock_text(self, text: str, username: str) -> List[PlatformResult]:
        """Parse the text output from sherlock (fallback)."""
        results = []
        for line in text.splitlines():
            line = line.strip()
            if "[+]" in line:  # Found
                parts = line.split(":", 1)
                platform = parts[0].replace("[+]", "").strip()
                url = parts[1].strip() if len(parts) > 1 else f"https://{platform.lower()}.com/{username}"
                results.append(PlatformResult(
                    platform=platform, url=url, username=username,
                    is_found=True, http_status=200, response_time_ms=None,
                ))
            elif "[-]" in line:  # Not found
                parts = line.split(":", 1)
                platform = parts[0].replace("[-]", "").strip()
                url = parts[1].strip() if len(parts) > 1 else ""
                results.append(PlatformResult(
                    platform=platform, url=url, username=username,
                    is_found=False, http_status=404, response_time_ms=None,
                ))
        return results

    async def _search_demo(
        self, username: str, progress_callback=None
    ) -> List[PlatformResult]:
        """
        DEMO MODE – returns synthetic results for educational demonstration.
        Used when Sherlock is not installed or unavailable.

        Results are plausible but NOT real network requests.
        """
        import hashlib
        import random

        # Use username hash to deterministically generate "found" platforms
        seed = int(hashlib.md5(username.encode()).hexdigest(), 16)
        rng = random.Random(seed)

        results = []
        total = len(DEMO_PLATFORMS)

        for i, platform in enumerate(DEMO_PLATFORMS):
            # Simulate processing time
            await asyncio.sleep(0.05)

            # ~40% chance platform is "found" for demo purposes
            is_found = rng.random() < 0.4
            url = platform["url"].format(username=username)
            response_ms = rng.randint(150, 2000) if is_found else rng.randint(100, 500)

            result = PlatformResult(
                platform=platform["name"],
                url=url,
                username=username,
                is_found=is_found,
                http_status=200 if is_found else 404,
                response_time_ms=response_ms,
            )
            results.append(result)

            if progress_callback:
                await progress_callback(i + 1, total, result)

        return results


# Module-level singleton
sherlock_service = SherlockService()
