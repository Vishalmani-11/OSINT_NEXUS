#!/usr/bin/env python3
"""
OSINT Nexus — Seed Script
Populates the database with demo data for development / demonstration.

Run inside the backend container:
  docker compose exec backend python scripts/seed.py

Or via make:
  make seed
"""
import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy import select

from app.config import settings
from app.models import (
    User, UserRole, Case, CaseStatus, CasePriority,
    Subject, Evidence, EvidenceType, Note,
    UsernameSearch, UsernameStatus, Profile,
)
from app.services.auth import hash_password


engine = create_async_engine(settings.DATABASE_URL, echo=False)
Session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def seed():
    print("🌱 Seeding OSINT Nexus demo data...")

    async with Session() as db:
        # ── Check if already seeded ───────────────────────────
        existing = await db.scalar(select(User).where(User.username == "admin"))
        if existing:
            print("✓ Data already exists — skipping seed")
            return

        # ── Users ─────────────────────────────────────────────
        admin = User(
            username="admin",
            email="admin@osintnexus.com",
            hashed_password=hash_password("Admin1234!"),
            full_name="Platform Administrator",
            role=UserRole.ADMIN,
            is_active=True,
            is_verified=True,
        )
        analyst = User(
            username="analyst",
            email="analyst@osintnexus.com",
            hashed_password=hash_password("Analyst1234!"),
            full_name="Senior OSINT Analyst",
            role=UserRole.ANALYST,
            is_active=True,
            is_verified=True,
        )
        db.add_all([admin, analyst])
        await db.flush()
        print(f"  ✓ Users created: admin / analyst (password: <role>1234!)")

        # ── Cases ─────────────────────────────────────────────
        case1 = Case(
            title="Social Media Fraud Investigation",
            description="Investigating suspected fraudulent activity across multiple social platforms. Subject appears to be using multiple aliases.",
            case_number="CASE-2024-0001",
            status=CaseStatus.ACTIVE,
            priority=CasePriority.HIGH,
            tags=["fraud", "social-media", "multi-platform"],
            created_by_id=admin.id,
            assigned_to_id=analyst.id,
        )
        case2 = Case(
            title="Impersonation Account Review",
            description="Multiple accounts impersonating a public figure detected. Coordinated inauthentic behaviour suspected.",
            case_number="CASE-2024-0002",
            status=CaseStatus.OPEN,
            priority=CasePriority.MEDIUM,
            tags=["impersonation", "coordinated"],
            created_by_id=analyst.id,
            assigned_to_id=analyst.id,
        )
        db.add_all([case1, case2])
        await db.flush()
        print(f"  ✓ Cases created: {case1.case_number}, {case2.case_number}")

        # ── Subjects ──────────────────────────────────────────
        subj1 = Subject(
            name="John Sample Doe",
            aliases=["johnny_d", "jdoe_99", "j.doe"],
            emails=["jdoe@protonmail.com", "johndoe99@gmail.com"],
            websites=["https://johndoe-portfolio.example.com"],
            phone_numbers=["+1-555-0100"],
            locations=["New York, USA"],
            description="Primary subject. Uses multiple usernames across platforms.",
            case_id=case1.id,
        )
        subj2 = Subject(
            name="Jane Sample Smith",
            aliases=["jsmith_official", "real_jsmith"],
            emails=["jsmith@example.org"],
            locations=["London, UK"],
            description="Secondary subject connected to case 1.",
            case_id=case1.id,
        )
        db.add_all([subj1, subj2])
        await db.flush()
        print(f"  ✓ Subjects created: {subj1.name}, {subj2.name}")

        # ── Username searches (demo results) ──────────────────
        search1 = UsernameSearch(
            username="johndoe99",
            status=UsernameStatus.FOUND,
            total_checked=20,
            total_found=7,
            platforms_found=["GitHub", "Twitter", "Reddit", "Instagram", "LinkedIn", "TikTok", "Steam"],
            case_id=case1.id,
            subject_id=subj1.id,
        )
        db.add(search1)
        await db.flush()

        demo_profiles = [
            ("GitHub",    f"https://github.com/johndoe99",           True,  200),
            ("Twitter",   f"https://twitter.com/johndoe99",          True,  200),
            ("Reddit",    f"https://reddit.com/u/johndoe99",          True,  200),
            ("Instagram", f"https://instagram.com/johndoe99",         True,  200),
            ("LinkedIn",  f"https://linkedin.com/in/johndoe99",       True,  200),
            ("TikTok",    f"https://tiktok.com/@johndoe99",           True,  200),
            ("Steam",     f"https://steamcommunity.com/id/johndoe99", True,  200),
            ("Pinterest", f"https://pinterest.com/johndoe99",         False, 404),
            ("Twitch",    f"https://twitch.tv/johndoe99",             False, 404),
            ("Discord",   f"https://discord.com/users/johndoe99",     False, 404),
        ]
        for plat, url, found, status in demo_profiles:
            db.add(Profile(
                username_search_id=search1.id,
                platform=plat, url=url, username="johndoe99",
                is_found=found, http_status=status,
                response_time_ms=142 if found else 89,
            ))
        print(f"  ✓ Username search: @johndoe99 ({search1.total_found} platforms found)")

        # ── Evidence ──────────────────────────────────────────
        evidence_items = [
            Evidence(
                title="GitHub Profile — johndoe99",
                description="Active account with 47 repositories. Last commit 3 days ago.",
                evidence_type=EvidenceType.URL,
                url="https://github.com/johndoe99",
                source="Sherlock / OSINT",
                tags=["github", "developer", "active"],
                case_id=case1.id,
                subject_id=subj1.id,
                uploaded_by_id=analyst.id,
            ),
            Evidence(
                title="Twitter Profile Screenshot",
                description="Profile shows 2,400 followers. Bio mentions 'fintech' and 'crypto'. Account created 2019.",
                evidence_type=EvidenceType.SCREENSHOT,
                source="Twitter",
                tags=["twitter", "social", "crypto"],
                case_id=case1.id,
                subject_id=subj1.id,
                uploaded_by_id=analyst.id,
            ),
            Evidence(
                title="Cross-platform Username Consistency Note",
                description="Same profile photo used across GitHub, Twitter, and LinkedIn. Confirms single individual.",
                evidence_type=EvidenceType.NOTE,
                source="Analysis",
                tags=["analysis", "profile-photo", "identity"],
                case_id=case1.id,
                uploaded_by_id=analyst.id,
            ),
        ]
        db.add_all(evidence_items)
        print(f"  ✓ {len(evidence_items)} evidence items created")

        # ── Notes ─────────────────────────────────────────────
        notes = [
            Note(
                content="⚠ PRIORITY: Cross-reference johndoe99 GitHub repos with case CASE-2024-0002 impersonation accounts. Check commit emails.",
                is_pinned=True,
                case_id=case1.id,
                author_id=analyst.id,
            ),
            Note(
                content="LinkedIn profile lists employment at 'TechCorp Inc' 2019–2023. HR contact obtained. Awaiting response.",
                case_id=case1.id,
                author_id=analyst.id,
            ),
            Note(
                content="Reddit account u/johndoe99 posts frequently in r/wallstreetbets and r/cryptocurrency. Account age 4 years, karma 12k. Appears legitimate.",
                case_id=case1.id,
                author_id=admin.id,
            ),
        ]
        db.add_all(notes)
        print(f"  ✓ {len(notes)} analyst notes created")

        await db.commit()

    print("")
    print("✅ Seed complete!")
    print("")
    print("  Login credentials:")
    print("  ┌─────────────┬──────────────────────┬───────────────┐")
    print("  │ Username    │ Email                │ Password      │")
    print("  ├─────────────┼──────────────────────┼───────────────┤")
    print("  │ admin       │ admin@osintnexus.com    │ Admin1234!    │")
    print("  │ analyst     │ analyst@osintnexus.com  │ Analyst1234!  │")
    print("  └─────────────┴──────────────────────┴───────────────┘")
    print("")
    print("  Open http://localhost:3000 and log in!")


if __name__ == "__main__":
    asyncio.run(seed())
