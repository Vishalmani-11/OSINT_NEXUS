"""
OSINT Nexus - Pytest Configuration & Fixtures
Provides reusable fixtures for all tests: DB, HTTP client, user factories, case factories.

Celery note: routers dispatch background jobs via `some_task.delay(...)` inline
inside the request (e.g. starting a username scan, queuing a report). In the
real Docker Compose stack this reaches a live Redis broker, and the worker
process opens its own PostgreSQL connection via SYNC_DATABASE_URL — by design,
since Celery workers are separate OS processes and can't share the API
process's async SQLAlchemy session. Neither Redis nor a second Postgres
connection exists in this unit-test environment, so `stub_celery_delay` below
replaces `.delay()` with a no-op stub for the duration of the test session.
This keeps these tests focused on verifying the HTTP/DB-write layer (what the
endpoint itself does) rather than requiring live infrastructure; the task
*bodies* (Sherlock scanning, face embedding, report rendering, graph updates)
are exercised independently through the service-layer fallbacks in
app/services/*.py (demo mode, OpenCV fallback, mock graph), which don't
require external infrastructure either.
"""
import asyncio
from dataclasses import dataclass
from typing import AsyncGenerator
from unittest.mock import patch

import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import (
    create_async_engine, AsyncSession, async_sessionmaker
)
from sqlalchemy.pool import StaticPool

# ── In-memory test DB (SQLite via aiosqlite) ──────────────────────
TEST_DB_URL = "sqlite+aiosqlite:///:memory:"


@dataclass
class _FakeAsyncResult:
    """Minimal stand-in for a Celery AsyncResult — routers only read `.id`."""
    id: str = "stub-task-id"


def _fake_delay(*args, **kwargs):
    return _FakeAsyncResult()


@pytest.fixture(autouse=True, scope="session")
def stub_celery_delay():
    """
    Session-wide autouse fixture: replace `.delay()` on every Celery task that
    a router calls inline, so tests never block on (or fail because of) a
    missing Redis broker / worker-side Postgres connection.
    """
    targets = [
        "app.celery_app.run_username_scan",
        "app.celery_app.generate_report",
        "app.celery_app.update_graph_for_subject",
        "app.celery_app.update_graph_for_username",
    ]
    patchers = [patch(f"{t}.delay", side_effect=_fake_delay) for t in targets]
    for p in patchers:
        p.start()
    yield
    for p in patchers:
        p.stop()


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="session")
async def test_engine():
    engine = create_async_engine(
        TEST_DB_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        echo=False,
    )
    # Import all models so they are registered with Base.metadata
    import app.models  # noqa – side-effect: registers all ORM models
    from app.database import Base

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def db(test_engine) -> AsyncGenerator[AsyncSession, None]:
    """Transactional session rolled back after each test."""
    factory = async_sessionmaker(test_engine, class_=AsyncSession, expire_on_commit=False)
    async with factory() as session:
        yield session
        await session.rollback()


@pytest_asyncio.fixture
async def client(db: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """AsyncClient wired to the test DB via FastAPI dependency override."""
    from app.main import app
    from app.database import get_db

    async def override_db():
        yield db

    app.dependency_overrides[get_db] = override_db

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://testserver",
        timeout=30.0,
    ) as ac:
        yield ac

    app.dependency_overrides.clear()


# ── User factory ──────────────────────────────────────────────────

async def _register_and_login(client: AsyncClient, username: str, email: str, password: str):
    reg = await client.post("/api/v1/auth/register", json={
        "username": username, "email": email, "password": password, "full_name": f"Test {username}",
    })
    # 201 = new user, 409 = already exists (from a previous test run sharing state)
    assert reg.status_code in (201, 409), f"Register failed: {reg.text}"

    login = await client.post("/api/v1/auth/login", json={"username": username, "password": password})
    assert login.status_code == 200, f"Login failed: {login.text}"
    data = login.json()
    return {
        "user":    data["user"],
        "token":   data["access_token"],
        "headers": {"Authorization": f"Bearer {data['access_token']}"},
    }


@pytest_asyncio.fixture
async def admin(client: AsyncClient):
    """First registered user — automatically receives Admin role."""
    return await _register_and_login(client, "testadmin", "admin@osintnexus.com", "AdminPass123!")


@pytest_asyncio.fixture
async def analyst(client: AsyncClient, admin):
    """Second user — receives Analyst role."""
    return await _register_and_login(client, "testanalyst", "analyst@osintnexus.com", "AnalystPass123!")


# ── Case factory ──────────────────────────────────────────────────

@pytest_asyncio.fixture
async def sample_case(client: AsyncClient, admin):
    resp = await client.post("/api/v1/cases", headers=admin["headers"], json={
        "title":       "Pytest Sample Case",
        "description": "Created by conftest fixture",
        "priority":    "medium",
        "tags":        ["pytest", "auto"],
    })
    assert resp.status_code == 201
    return resp.json()


@pytest_asyncio.fixture
async def sample_subject(client: AsyncClient, admin, sample_case):
    resp = await client.post(
        f"/api/v1/cases/{sample_case['id']}/subjects",
        headers=admin["headers"],
        json={
            "name":        "Jane Pytest Doe",
            "aliases":     ["jane", "jpd"],
            "emails":      ["jane@example.com"],
            "case_id":     sample_case["id"],
        },
    )
    assert resp.status_code == 201
    return resp.json()


# ── API helper shortcuts ──────────────────────────────────────────

class API:
    """Thin wrapper so tests can call api.get(…) without repeating headers."""
    def __init__(self, client: AsyncClient, headers: dict):
        self._c = client
        self._h = headers

    async def get(self, url, **kw):     return await self._c.get(url,    headers=self._h, **kw)
    async def post(self, url, **kw):    return await self._c.post(url,   headers=self._h, **kw)
    async def patch(self, url, **kw):   return await self._c.patch(url,  headers=self._h, **kw)
    async def delete(self, url, **kw):  return await self._c.delete(url, headers=self._h, **kw)


@pytest_asyncio.fixture
async def admin_api(client: AsyncClient, admin):
    return API(client, admin["headers"])


@pytest_asyncio.fixture
async def analyst_api(client: AsyncClient, analyst):
    return API(client, analyst["headers"])
