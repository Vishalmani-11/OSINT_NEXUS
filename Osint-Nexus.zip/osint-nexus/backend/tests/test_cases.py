"""
OSINT Nexus - Case Management Test Suite
Full coverage of cases, subjects, evidence, notes, and timeline.
"""
import pytest
from httpx import AsyncClient


# ════════════════════════════════════════════════════════════════════
# CASE CRUD
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_create_case_minimal(admin_api):
    resp = await admin_api.post("/api/v1/cases", json={
        "title": "Minimal Case", "priority": "low",
    })
    assert resp.status_code == 201
    body = resp.json()
    assert body["title"] == "Minimal Case"
    assert body["priority"] == "low"
    assert body["status"] == "open"
    assert body["case_number"].startswith("CASE-")


@pytest.mark.asyncio
async def test_create_case_full(admin_api):
    resp = await admin_api.post("/api/v1/cases", json={
        "title":       "Full Featured Case",
        "description": "Testing all fields",
        "priority":    "critical",
        "tags":        ["fraud", "social-media", "priority-target"],
    })
    assert resp.status_code == 201
    body = resp.json()
    assert body["priority"] == "critical"
    assert "fraud" in body["tags"]
    assert "social-media" in body["tags"]


@pytest.mark.asyncio
async def test_create_case_requires_auth(client: AsyncClient):
    resp = await client.post("/api/v1/cases", json={"title": "No Auth", "priority": "low"})
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_create_case_title_too_short(admin_api):
    resp = await admin_api.post("/api/v1/cases", json={"title": "AB", "priority": "low"})
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_list_cases(admin_api, sample_case):
    resp = await admin_api.get("/api/v1/cases")
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)
    ids = [c["id"] for c in resp.json()]
    assert sample_case["id"] in ids


@pytest.mark.asyncio
async def test_list_cases_filter_status(admin_api, sample_case):
    resp = await admin_api.get("/api/v1/cases", params={"status": "open"})
    assert resp.status_code == 200
    for c in resp.json():
        assert c["status"] == "open"


@pytest.mark.asyncio
async def test_list_cases_filter_priority(admin_api, sample_case):
    resp = await admin_api.get("/api/v1/cases", params={"priority": "medium"})
    assert resp.status_code == 200
    for c in resp.json():
        assert c["priority"] == "medium"


@pytest.mark.asyncio
async def test_get_case_by_id(admin_api, sample_case):
    resp = await admin_api.get(f"/api/v1/cases/{sample_case['id']}")
    assert resp.status_code == 200
    assert resp.json()["id"] == sample_case["id"]
    assert resp.json()["title"] == sample_case["title"]


@pytest.mark.asyncio
async def test_get_nonexistent_case(admin_api):
    resp = await admin_api.get("/api/v1/cases/999999")
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_update_case_title(admin_api, sample_case):
    resp = await admin_api.patch(f"/api/v1/cases/{sample_case['id']}", json={
        "title": "Updated Title"
    })
    assert resp.status_code == 200
    assert resp.json()["title"] == "Updated Title"


@pytest.mark.asyncio
async def test_update_case_status_to_active(admin_api, sample_case):
    resp = await admin_api.patch(f"/api/v1/cases/{sample_case['id']}", json={"status": "active"})
    assert resp.status_code == 200
    assert resp.json()["status"] == "active"


@pytest.mark.asyncio
async def test_update_case_tags(admin_api, sample_case):
    resp = await admin_api.patch(f"/api/v1/cases/{sample_case['id']}", json={
        "tags": ["updated", "tags", "list"]
    })
    assert resp.status_code == 200
    assert "updated" in resp.json()["tags"]


@pytest.mark.asyncio
async def test_delete_case(admin_api):
    create = await admin_api.post("/api/v1/cases", json={"title": "Delete Me", "priority": "low"})
    case_id = create.json()["id"]

    resp = await admin_api.delete(f"/api/v1/cases/{case_id}")
    assert resp.status_code == 204


@pytest.mark.asyncio
async def test_delete_nonexistent_case(admin_api):
    resp = await admin_api.delete("/api/v1/cases/999999")
    assert resp.status_code == 404


# ════════════════════════════════════════════════════════════════════
# SUBJECTS
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_create_subject_minimal(admin_api, sample_case):
    resp = await admin_api.post(f"/api/v1/cases/{sample_case['id']}/subjects", json={
        "name": "Jane Smith", "case_id": sample_case["id"],
    })
    assert resp.status_code == 201
    body = resp.json()
    assert body["name"] == "Jane Smith"
    assert body["case_id"] == sample_case["id"]


@pytest.mark.asyncio
async def test_create_subject_full(admin_api, sample_case):
    resp = await admin_api.post(f"/api/v1/cases/{sample_case['id']}/subjects", json={
        "name":         "John Full Doe",
        "case_id":      sample_case["id"],
        "aliases":      ["johnny", "jfd123"],
        "emails":       ["john@example.com", "jdoe@work.com"],
        "phone_numbers":["555-0100"],
        "websites":     ["https://johndoe.example.com"],
        "description":  "Primary subject under investigation",
    })
    assert resp.status_code == 201
    body = resp.json()
    assert "johnny" in body["aliases"]
    assert "john@example.com" in body["emails"]


@pytest.mark.asyncio
async def test_create_subject_wrong_case(admin_api):
    resp = await admin_api.post("/api/v1/cases/999999/subjects", json={
        "name": "Ghost Subject", "case_id": 999999,
    })
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_list_subjects(admin_api, sample_case, sample_subject):
    resp = await admin_api.get(f"/api/v1/cases/{sample_case['id']}/subjects")
    assert resp.status_code == 200
    names = [s["name"] for s in resp.json()]
    assert sample_subject["name"] in names


@pytest.mark.asyncio
async def test_update_subject(admin_api, sample_case, sample_subject):
    resp = await admin_api.patch(
        f"/api/v1/cases/{sample_case['id']}/subjects/{sample_subject['id']}",
        json={"description": "Updated description"},
    )
    assert resp.status_code == 200
    assert resp.json()["description"] == "Updated description"


@pytest.mark.asyncio
async def test_delete_subject(admin_api, sample_case):
    create = await admin_api.post(f"/api/v1/cases/{sample_case['id']}/subjects", json={
        "name": "Subject To Delete", "case_id": sample_case["id"],
    })
    subj_id = create.json()["id"]
    resp = await admin_api.delete(f"/api/v1/cases/{sample_case['id']}/subjects/{subj_id}")
    assert resp.status_code == 204


# ════════════════════════════════════════════════════════════════════
# EVIDENCE
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_create_url_evidence(admin_api, sample_case):
    resp = await admin_api.post(f"/api/v1/cases/{sample_case['id']}/evidence", json={
        "title":         "Twitter Profile",
        "description":   "Subject's public Twitter profile",
        "evidence_type": "url",
        "url":           "https://twitter.com/example_subject",
        "source":        "Twitter",
        "tags":          ["social-media", "profile"],
        "case_id":       sample_case["id"],
    })
    assert resp.status_code == 201
    body = resp.json()
    assert body["evidence_type"] == "url"
    assert "social-media" in body["tags"]


@pytest.mark.asyncio
async def test_create_screenshot_evidence(admin_api, sample_case):
    resp = await admin_api.post(f"/api/v1/cases/{sample_case['id']}/evidence", json={
        "title": "Homepage Screenshot",
        "evidence_type": "screenshot",
        "case_id": sample_case["id"],
    })
    assert resp.status_code == 201
    assert resp.json()["evidence_type"] == "screenshot"


@pytest.mark.asyncio
async def test_list_evidence(admin_api, sample_case):
    # Add some evidence
    await admin_api.post(f"/api/v1/cases/{sample_case['id']}/evidence", json={
        "title": "Evidence A", "evidence_type": "note", "case_id": sample_case["id"],
    })
    resp = await admin_api.get(f"/api/v1/cases/{sample_case['id']}/evidence")
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)
    assert len(resp.json()) >= 1


@pytest.mark.asyncio
async def test_delete_evidence(admin_api, sample_case):
    create = await admin_api.post(f"/api/v1/cases/{sample_case['id']}/evidence", json={
        "title": "Delete This Evidence", "evidence_type": "other", "case_id": sample_case["id"],
    })
    ev_id = create.json()["id"]
    resp = await admin_api.delete(f"/api/v1/cases/{sample_case['id']}/evidence/{ev_id}")
    assert resp.status_code == 204


# ════════════════════════════════════════════════════════════════════
# NOTES
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_create_note(admin_api, sample_case):
    resp = await admin_api.post(f"/api/v1/cases/{sample_case['id']}/notes", json={
        "content": "Subject appears active on Instagram and TikTok.",
        "case_id": sample_case["id"],
    })
    assert resp.status_code == 201
    assert "Subject appears active" in resp.json()["content"]


@pytest.mark.asyncio
async def test_create_pinned_note(admin_api, sample_case):
    resp = await admin_api.post(f"/api/v1/cases/{sample_case['id']}/notes", json={
        "content": "⚠ IMPORTANT: Cross-reference with case CASE-2024-0002",
        "case_id": sample_case["id"],
        "is_pinned": True,
    })
    assert resp.status_code == 201
    assert resp.json()["is_pinned"] is True


@pytest.mark.asyncio
async def test_list_notes(admin_api, sample_case):
    await admin_api.post(f"/api/v1/cases/{sample_case['id']}/notes", json={
        "content": "Note for listing test", "case_id": sample_case["id"],
    })
    resp = await admin_api.get(f"/api/v1/cases/{sample_case['id']}/notes")
    assert resp.status_code == 200
    assert len(resp.json()) >= 1


@pytest.mark.asyncio
async def test_delete_note(admin_api, sample_case):
    create = await admin_api.post(f"/api/v1/cases/{sample_case['id']}/notes", json={
        "content": "Note to be deleted", "case_id": sample_case["id"],
    })
    note_id = create.json()["id"]
    resp = await admin_api.delete(f"/api/v1/cases/{sample_case['id']}/notes/{note_id}")
    assert resp.status_code == 204


# ════════════════════════════════════════════════════════════════════
# TIMELINE
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_case_timeline_has_creation_event(admin_api, sample_case):
    resp = await admin_api.get(f"/api/v1/cases/{sample_case['id']}/timeline")
    assert resp.status_code == 200
    body = resp.json()
    assert "events" in body
    # Case creation event should always be first
    assert len(body["events"]) >= 1
    event_types = [e["type"] for e in body["events"]]
    assert "case_created" in event_types


@pytest.mark.asyncio
async def test_case_timeline_includes_subject(admin_api, sample_case, sample_subject):
    resp = await admin_api.get(f"/api/v1/cases/{sample_case['id']}/timeline")
    assert resp.status_code == 200
    types = [e["type"] for e in resp.json()["events"]]
    assert "subject_added" in types


@pytest.mark.asyncio
async def test_timeline_nonexistent_case(admin_api):
    resp = await admin_api.get("/api/v1/cases/999999/timeline")
    assert resp.status_code == 404
