"""
OSINT Nexus - Celery Task Body Tests
The HTTP-layer tests (test_features.py) stub out `.delay()` so endpoint
tests don't need a live Redis broker or a second worker-side PostgreSQL
connection (see conftest.py's `stub_celery_delay` for why). That leaves the
actual task *bodies* — the real scan/embedding/report/graph logic — only
reachable by calling them directly, which is what these tests do.

Celery task objects are still plain callables outside of `.delay()`/worker
context: calling `my_task(args)` runs the function body synchronously with
`self.request` populated with Context() defaults (e.g. `self.request.id`
is None rather than a broker-assigned ID, which is fine — the column it's
stored in is nullable).

`get_sync_session()` normally opens a real PostgreSQL connection via
SYNC_DATABASE_URL (correct for the live Docker stack, where Celery workers
are separate processes from the API). Here it's monkeypatched to a SQLite
engine sharing the same Base.metadata, so these tests stay hermetic.
"""
import io
from pathlib import Path

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool


# ── Sync DB fixtures (separate from the async ones in conftest.py) ───────

@pytest.fixture
def sync_engine():
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    from app.database import Base
    import app.models  # noqa: ensure all models are registered
    Base.metadata.create_all(engine)
    yield engine
    engine.dispose()


@pytest.fixture
def sync_session_factory(sync_engine, monkeypatch):
    """Patch app.celery_app.get_sync_session so task bodies write to our
    isolated SQLite engine instead of trying to reach a real PostgreSQL
    server that doesn't exist in this test environment."""
    factory = sessionmaker(bind=sync_engine)
    monkeypatch.setattr("app.celery_app.get_sync_session", factory)
    return factory


@pytest.fixture
def seeded(sync_session_factory):
    """Seed a minimal User -> Case graph that every task test can build on."""
    from app.models import User, UserRole, Case, CaseStatus, CasePriority

    db = sync_session_factory()
    user = User(
        username="taskuser", email="taskuser@nexusdemo.com",
        hashed_password="x", role=UserRole.ADMIN, is_active=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    case = Case(
        title="Celery Task Test Case", case_number="CASE-TEST-0001",
        status=CaseStatus.OPEN, priority=CasePriority.MEDIUM,
        created_by_id=user.id,
    )
    db.add(case)
    db.commit()
    db.refresh(case)

    ids = {"user_id": user.id, "case_id": case.id}
    db.close()
    return ids


# ════════════════════════════════════════════════════════════════════
# run_username_scan
# ════════════════════════════════════════════════════════════════════

def test_run_username_scan_task_populates_profiles(sync_session_factory, seeded):
    from app.celery_app import run_username_scan
    from app.models import UsernameSearch, UsernameStatus, Profile

    db = sync_session_factory()
    search = UsernameSearch(
        username="taskbody_demo_user",
        case_id=seeded["case_id"],
        status=UsernameStatus.PENDING,
    )
    db.add(search)
    db.commit()
    db.refresh(search)
    search_id = search.id
    db.close()

    result = run_username_scan(search_id=search_id, username="taskbody_demo_user",
                                case_id=seeded["case_id"])

    assert result["search_id"] == search_id
    assert result["total_checked"] > 0
    assert "platforms_found" in result

    db = sync_session_factory()
    refreshed = db.query(UsernameSearch).filter(UsernameSearch.id == search_id).first()
    assert refreshed.status in (UsernameStatus.FOUND, UsernameStatus.NOT_FOUND)
    assert refreshed.completed_at is not None
    assert refreshed.total_checked == result["total_checked"]

    profiles = db.query(Profile).filter(Profile.username_search_id == search_id).all()
    assert len(profiles) == result["total_checked"]
    db.close()


def test_run_username_scan_task_missing_search_returns_error(sync_session_factory, seeded):
    from app.celery_app import run_username_scan

    result = run_username_scan(search_id=999999, username="ghost", case_id=seeded["case_id"])
    assert "error" in result


# ════════════════════════════════════════════════════════════════════
# generate_report
# ════════════════════════════════════════════════════════════════════

def test_generate_report_task_json(sync_session_factory, seeded, tmp_path, monkeypatch):
    from app.celery_app import generate_report
    from app.models import Report, ReportFormat, ReportStatus
    from app.services.reporting import reporting_service

    # Keep generated files in a temp dir rather than the real uploads/ path
    monkeypatch.setattr(reporting_service, "REPORTS_DIR", tmp_path)

    db = sync_session_factory()
    report = Report(
        title="Task Body Test Report", format=ReportFormat.JSON,
        status=ReportStatus.PENDING, case_id=seeded["case_id"],
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    report_id = report.id
    db.close()

    result = generate_report(report_id=report_id)

    assert result["report_id"] == report_id
    assert result["status"] == "completed"
    assert Path(result["path"]).exists()

    db = sync_session_factory()
    refreshed = db.query(Report).filter(Report.id == report_id).first()
    assert refreshed.status == ReportStatus.COMPLETED
    assert refreshed.file_size and refreshed.file_size > 0
    db.close()


def test_generate_report_task_missing_report(sync_session_factory, seeded):
    from app.celery_app import generate_report

    result = generate_report(report_id=999999)
    assert "error" in result


# ════════════════════════════════════════════════════════════════════
# graph update tasks (mock fallback — no live Neo4j)
# ════════════════════════════════════════════════════════════════════

def test_update_graph_for_subject_task_runs_without_error(sync_session_factory, seeded):
    from app.celery_app import update_graph_for_subject
    from app.models import Subject

    db = sync_session_factory()
    subject = Subject(
        name="Graph Task Subject", case_id=seeded["case_id"],
        emails=["graphtask@nexusdemo.com"], websites=["https://example-demo.com"],
    )
    db.add(subject)
    db.commit()
    db.refresh(subject)
    subject_id = subject.id
    db.close()

    # Should complete cleanly even with no live Neo4j (link_* calls no-op
    # internally when get_driver() returns None).
    update_graph_for_subject(subject_id=subject_id, case_id=seeded["case_id"])


def test_update_graph_for_username_task_runs_without_error(sync_session_factory, seeded):
    from app.celery_app import update_graph_for_username, run_username_scan
    from app.models import UsernameSearch, UsernameStatus, Subject

    db = sync_session_factory()
    subject = Subject(name="Username Graph Subject", case_id=seeded["case_id"])
    db.add(subject)
    db.commit()
    db.refresh(subject)

    search = UsernameSearch(
        username="graphtask_user", case_id=seeded["case_id"],
        subject_id=subject.id, status=UsernameStatus.PENDING,
    )
    db.add(search)
    db.commit()
    db.refresh(search)
    search_id = search.id
    db.close()

    # Populate real profile rows first via the scan task, then run the
    # graph-update task against them.
    run_username_scan(search_id=search_id, username="graphtask_user", case_id=seeded["case_id"])
    update_graph_for_username(search_id=search_id)


# ════════════════════════════════════════════════════════════════════
# cleanup_old_logs
# ════════════════════════════════════════════════════════════════════

def test_cleanup_old_logs_deletes_old_entries(sync_session_factory, seeded):
    from datetime import datetime, timedelta
    from app.celery_app import cleanup_old_logs
    from app.models import ActivityLog, ActivityAction

    db = sync_session_factory()
    old_log = ActivityLog(
        action=ActivityAction.LOGIN, user_id=seeded["user_id"],
        created_at=datetime.utcnow() - timedelta(days=120),
    )
    recent_log = ActivityLog(
        action=ActivityAction.LOGIN, user_id=seeded["user_id"],
        created_at=datetime.utcnow(),
    )
    db.add_all([old_log, recent_log])
    db.commit()
    db.close()

    result = cleanup_old_logs()
    assert result["deleted"] >= 1

    db = sync_session_factory()
    remaining = db.query(ActivityLog).count()
    assert remaining == 1  # only the recent one survives
    db.close()
