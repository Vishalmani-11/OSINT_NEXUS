"""
OSINT Nexus - Edge Case & Success-Path Tests
Targets branches not covered by the main suites:
reverse image search with optional API keys configured, graph subject
query, and full-field case/subject updates.
"""
import io
import pytest


# ════════════════════════════════════════════════════════════════════
# REVERSE IMAGE SEARCH — detailed link verification
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_image_search_with_public_url_builds_direct_links(client, admin, sample_case):
    """When public_base_url is provided, links point directly to the
    image URL rather than only the engine's upload page."""
    jpeg_bytes = b'\xff\xd8\xff\xd9'
    resp = await client.post(
        "/api/v1/images/search",
        headers=admin["headers"],
        data={
            "case_id": str(sample_case["id"]),
            "public_base_url": "https://my-osint-server.example.com",
        },
        files={"file": ("photo.jpg", io.BytesIO(jpeg_bytes), "image/jpeg")},
    )
    assert resp.status_code == 201
    links = resp.json()["search_links"]
    # With a public URL, Google/Yandex/TinEye links embed the image URL directly
    # (rather than just pointing at upload pages)
    google_link = links.get("Google Images") or links.get("Google Images (Upload)")
    assert google_link is not None


@pytest.mark.asyncio
async def test_image_search_stores_file_hash(client, admin, sample_case):
    """The SHA-256 hash of the image must be stored for deduplication."""
    import hashlib
    jpeg_bytes = b'\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00\xff\xd9'
    expected_hash = hashlib.sha256(jpeg_bytes).hexdigest()

    resp = await client.post(
        "/api/v1/images/search",
        headers=admin["headers"],
        data={"case_id": str(sample_case["id"])},
        files={"file": ("hashtest.jpg", io.BytesIO(jpeg_bytes), "image/jpeg")},
    )
    assert resp.status_code == 201
    body = resp.json()
    assert body["file_hash"] == expected_hash[:16]  # we store first 16 chars of hex


@pytest.mark.asyncio
async def test_image_search_subject_association(client, admin, sample_case, sample_subject):
    """Image search can be associated with a specific subject."""
    jpeg_bytes = b'\xff\xd8\xff\xd9'
    resp = await client.post(
        "/api/v1/images/search",
        headers=admin["headers"],
        data={
            "case_id": str(sample_case["id"]),
            "subject_id": str(sample_subject["id"]),
        },
        files={"file": ("subj.jpg", io.BytesIO(jpeg_bytes), "image/jpeg")},
    )
    assert resp.status_code == 201
    assert resp.json()["subject_id"] == sample_subject["id"]


@pytest.mark.asyncio
async def test_image_search_get_and_list(client, admin, sample_case):
    """Create a search, then verify both GET-by-id and list-by-case work."""
    jpeg_bytes = b'\xff\xd8\xff\xd9'
    create = await client.post(
        "/api/v1/images/search",
        headers=admin["headers"],
        data={"case_id": str(sample_case["id"])},
        files={"file": ("getlist.jpg", io.BytesIO(jpeg_bytes), "image/jpeg")},
    )
    search_id = create.json()["id"]

    # GET by id
    get_resp = await client.get(f"/api/v1/images/{search_id}", headers=admin["headers"])
    assert get_resp.status_code == 200
    assert get_resp.json()["id"] == search_id

    # List for case
    list_resp = await client.get(
        f"/api/v1/images/case/{sample_case['id']}", headers=admin["headers"]
    )
    assert list_resp.status_code == 200
    ids = [s["id"] for s in list_resp.json()]
    assert search_id in ids


# ════════════════════════════════════════════════════════════════════
# GRAPH QUERY — subject_id branch
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_graph_query_by_subject_id(admin_api, sample_subject):
    resp = await admin_api.post("/api/v1/graph/query", json={
        "subject_id": sample_subject["id"], "max_depth": 2,
    })
    assert resp.status_code == 200
    body = resp.json()
    assert "nodes" in body and "edges" in body


@pytest.mark.asyncio
async def test_graph_query_no_filters_returns_empty(admin_api):
    resp = await admin_api.post("/api/v1/graph/query", json={"max_depth": 1})
    assert resp.status_code == 200
    body = resp.json()
    assert body["node_count"] == 0
    assert body["edge_count"] == 0


# ════════════════════════════════════════════════════════════════════
# CASE / SUBJECT — full-field update paths
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_update_case_all_fields_at_once(admin_api, sample_case, analyst):
    resp = await admin_api.patch(f"/api/v1/cases/{sample_case['id']}", json={
        "title": "Fully Updated Title",
        "description": "Fully updated description",
        "status": "closed",
        "priority": "critical",
        "tags": ["a", "b", "c"],
        "assigned_to_id": analyst["user"]["id"],
    })
    assert resp.status_code == 200
    body = resp.json()
    assert body["title"] == "Fully Updated Title"
    assert body["status"] == "closed"
    assert body["priority"] == "critical"
    assert body["assigned_to"]["id"] == analyst["user"]["id"]


@pytest.mark.asyncio
async def test_update_subject_all_fields_at_once(admin_api, sample_case, sample_subject):
    resp = await admin_api.patch(
        f"/api/v1/cases/{sample_case['id']}/subjects/{sample_subject['id']}",
        json={
            "name": "Fully Updated Name",
            "aliases": ["alias1", "alias2"],
            "emails": ["new@nexusdemo.com"],
            "phone_numbers": ["555-0199"],
            "locations": ["Berlin, DE"],
            "websites": ["https://updated-demo.com"],
        },
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["name"] == "Fully Updated Name"
    assert "alias1" in body["aliases"]
    assert "Berlin, DE" in body["locations"]


@pytest.mark.asyncio
async def test_list_cases_combined_filters(admin_api, sample_case):
    resp = await admin_api.get("/api/v1/cases", params={
        "status": "open", "priority": "medium", "search": "Pytest",
    })
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)
