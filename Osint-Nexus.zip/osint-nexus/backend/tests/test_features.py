"""
OSINT Nexus - Feature Test Suite
Covers username search, face analysis, reports, graph, and dashboard.
"""
import pytest
import io
from unittest.mock import patch, AsyncMock
from httpx import AsyncClient


# ════════════════════════════════════════════════════════════════════
# USERNAME SEARCH
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_start_username_search(admin_api, sample_case):
    resp = await admin_api.post("/api/v1/usernames/search", json={
        "username": "testosintuser",
        "case_id":  sample_case["id"],
    })
    assert resp.status_code == 201
    body = resp.json()
    assert body["username"] == "testosintuser"
    assert body["status"] in ("pending", "running", "found", "not_found", "demo", "error")
    assert body["case_id"] == sample_case["id"]


@pytest.mark.asyncio
async def test_username_search_returns_search_id(admin_api, sample_case):
    resp = await admin_api.post("/api/v1/usernames/search", json={
        "username": "searchidtest",
        "case_id":  sample_case["id"],
    })
    assert resp.status_code == 201
    assert "id" in resp.json()
    assert "uuid" in resp.json()


@pytest.mark.asyncio
async def test_get_username_search_by_id(admin_api, sample_case):
    create = await admin_api.post("/api/v1/usernames/search", json={
        "username": "getbyid_user",
        "case_id":  sample_case["id"],
    })
    search_id = create.json()["id"]

    resp = await admin_api.get(f"/api/v1/usernames/search/{search_id}")
    assert resp.status_code == 200
    assert resp.json()["id"] == search_id


@pytest.mark.asyncio
async def test_get_nonexistent_search(admin_api):
    resp = await admin_api.get("/api/v1/usernames/search/999999")
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_list_searches_for_case(admin_api, sample_case):
    await admin_api.post("/api/v1/usernames/search", json={
        "username": "listcaseuser1", "case_id": sample_case["id"],
    })
    await admin_api.post("/api/v1/usernames/search", json={
        "username": "listcaseuser2", "case_id": sample_case["id"],
    })
    resp = await admin_api.get(f"/api/v1/usernames/case/{sample_case['id']}")
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)
    usernames = [s["username"] for s in resp.json()]
    assert "listcaseuser1" in usernames
    assert "listcaseuser2" in usernames


@pytest.mark.asyncio
async def test_username_search_invalid_chars(admin_api, sample_case):
    """Usernames with spaces or special chars should be rejected."""
    resp = await admin_api.post("/api/v1/usernames/search", json={
        "username": "bad user name!",
        "case_id":  sample_case["id"],
    })
    assert resp.status_code == 422


@pytest.mark.asyncio
async def test_delete_username_search(admin_api, sample_case):
    create = await admin_api.post("/api/v1/usernames/search", json={
        "username": "deleteuser",
        "case_id":  sample_case["id"],
    })
    search_id = create.json()["id"]
    resp = await admin_api.delete(f"/api/v1/usernames/{search_id}")
    assert resp.status_code == 204

    # Verify deleted
    get_resp = await admin_api.get(f"/api/v1/usernames/search/{search_id}")
    assert get_resp.status_code == 404


@pytest.mark.asyncio
async def test_username_search_wrong_case(admin_api):
    resp = await admin_api.post("/api/v1/usernames/search", json={
        "username": "userx", "case_id": 999999,
    })
    assert resp.status_code == 404


# ════════════════════════════════════════════════════════════════════
# REVERSE IMAGE SEARCH
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_reverse_image_search_upload(client: AsyncClient, admin, sample_case):
    """Upload an image and get back reverse search links — no API key needed."""
    # Minimal valid JPEG (SOI + EOI markers only)
    jpeg_bytes = b'\xff\xd8\xff\xd9'

    resp = await client.post(
        "/api/v1/images/search",
        headers=admin["headers"],
        data={"case_id": str(sample_case["id"])},
        files={"file": ("subject_photo.jpg", io.BytesIO(jpeg_bytes), "image/jpeg")},
    )
    assert resp.status_code == 201
    body = resp.json()
    assert body["filename"] == "subject_photo.jpg"
    assert body["status"] == "completed"
    assert isinstance(body["search_links"], dict)
    assert len(body["search_links"]) > 0     # at minimum the upload-mode links
    assert body["case_id"] == sample_case["id"]


@pytest.mark.asyncio
async def test_reverse_image_search_contains_engine_links(client: AsyncClient, admin, sample_case):
    """Search links must include the major OSINT-relevant engines."""
    jpeg_bytes = b'\xff\xd8\xff\xd9'
    resp = await client.post(
        "/api/v1/images/search",
        headers=admin["headers"],
        data={"case_id": str(sample_case["id"])},
        files={"file": ("check.jpg", io.BytesIO(jpeg_bytes), "image/jpeg")},
    )
    assert resp.status_code == 201
    links = resp.json()["search_links"]
    link_names = list(links.keys())
    # These should always be present regardless of API key availability
    assert any("Google" in k for k in link_names)
    assert any("Yandex" in k for k in link_names)
    assert any("TinEye" in k for k in link_names)


@pytest.mark.asyncio
async def test_reverse_image_search_wrong_case(client: AsyncClient, admin):
    jpeg_bytes = b'\xff\xd8\xff\xd9'
    resp = await client.post(
        "/api/v1/images/search",
        headers=admin["headers"],
        data={"case_id": "999999"},
        files={"file": ("test.jpg", io.BytesIO(jpeg_bytes), "image/jpeg")},
    )
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_reverse_image_search_invalid_type(client: AsyncClient, admin, sample_case):
    resp = await client.post(
        "/api/v1/images/search",
        headers=admin["headers"],
        data={"case_id": str(sample_case["id"])},
        files={"file": ("doc.txt", io.BytesIO(b"not an image"), "text/plain")},
    )
    assert resp.status_code == 400


@pytest.mark.asyncio
async def test_list_image_searches(admin_api, sample_case):
    resp = await admin_api.get(f"/api/v1/images/case/{sample_case['id']}")
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)


@pytest.mark.asyncio
async def test_get_image_search_not_found(admin_api):
    resp = await admin_api.get("/api/v1/images/999999")
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_delete_image_search(client: AsyncClient, admin, sample_case):
    jpeg_bytes = b'\xff\xd8\xff\xd9'
    create = await client.post(
        "/api/v1/images/search",
        headers=admin["headers"],
        data={"case_id": str(sample_case["id"])},
        files={"file": ("delete_me.jpg", io.BytesIO(jpeg_bytes), "image/jpeg")},
    )
    assert create.status_code == 201
    search_id = create.json()["id"]

    resp = await client.delete(f"/api/v1/images/{search_id}", headers=admin["headers"])
    assert resp.status_code == 204

    get_resp = await client.get(f"/api/v1/images/{search_id}", headers=admin["headers"])
    assert get_resp.status_code == 404


# ════════════════════════════════════════════════════════════════════
# REPORTS
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_generate_json_report(admin_api, sample_case):
    resp = await admin_api.post("/api/v1/reports/generate", json={
        "title":   "Pytest JSON Report",
        "case_id": sample_case["id"],
        "format":  "json",
    })
    assert resp.status_code == 201
    body = resp.json()
    assert body["format"] == "json"
    assert body["status"] in ("pending", "generating", "completed", "failed")
    assert body["case_id"] == sample_case["id"]


@pytest.mark.asyncio
async def test_generate_html_report(admin_api, sample_case):
    resp = await admin_api.post("/api/v1/reports/generate", json={
        "title": "Pytest HTML Report", "case_id": sample_case["id"], "format": "html",
    })
    assert resp.status_code == 201
    assert resp.json()["format"] == "html"


@pytest.mark.asyncio
async def test_generate_report_wrong_case(admin_api):
    resp = await admin_api.post("/api/v1/reports/generate", json={
        "title": "Ghost Report", "case_id": 999999, "format": "json",
    })
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_list_reports(admin_api, sample_case):
    await admin_api.post("/api/v1/reports/generate", json={
        "title": "List Test Report", "case_id": sample_case["id"], "format": "json",
    })
    resp = await admin_api.get("/api/v1/reports")
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)


@pytest.mark.asyncio
async def test_get_report_by_id(admin_api, sample_case):
    create = await admin_api.post("/api/v1/reports/generate", json={
        "title": "Get By ID Report", "case_id": sample_case["id"], "format": "json",
    })
    report_id = create.json()["id"]
    resp = await admin_api.get(f"/api/v1/reports/{report_id}")
    assert resp.status_code == 200
    assert resp.json()["id"] == report_id


@pytest.mark.asyncio
async def test_download_pending_report_fails(admin_api, sample_case):
    """Downloading a report that isn't completed yet should fail."""
    create = await admin_api.post("/api/v1/reports/generate", json={
        "title": "Download Pending", "case_id": sample_case["id"], "format": "json",
    })
    report_id = create.json()["id"]

    # If still pending (Celery not running in tests), download must reject
    report = await admin_api.get(f"/api/v1/reports/{report_id}")
    if report.json()["status"] != "completed":
        resp = await admin_api.get(f"/api/v1/reports/{report_id}/download")
        assert resp.status_code == 422


# ════════════════════════════════════════════════════════════════════
# GRAPH
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_get_case_graph(admin_api, sample_case):
    resp = await admin_api.get(f"/api/v1/graph/case/{sample_case['id']}")
    assert resp.status_code == 200
    body = resp.json()
    assert "nodes" in body
    assert "edges" in body
    assert "node_count" in body
    assert "edge_count" in body
    assert isinstance(body["nodes"], list)
    assert isinstance(body["edges"], list)


@pytest.mark.asyncio
async def test_graph_query(admin_api, sample_case):
    resp = await admin_api.post("/api/v1/graph/query", json={
        "case_id":   sample_case["id"],
        "max_depth": 2,
    })
    assert resp.status_code == 200
    assert "nodes" in resp.json()


# ════════════════════════════════════════════════════════════════════
# DASHBOARD
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_dashboard_stats_structure(admin_api):
    resp = await admin_api.get("/api/v1/dashboard/stats")
    assert resp.status_code == 200
    body = resp.json()
    required = [
        "total_cases", "active_cases", "total_subjects",
        "username_searches", "username_matches",
        "image_searches", "image_results",
        "evidence_items", "reports_generated",
        "recent_activity_count",
    ]
    for field in required:
        assert field in body, f"Missing: {field}"
        assert isinstance(body[field], int), f"{field} should be int"


@pytest.mark.asyncio
async def test_dashboard_stats_counts_increment(admin_api, sample_case):
    """Creating a case should increment total_cases."""
    before = (await admin_api.get("/api/v1/dashboard/stats")).json()["total_cases"]
    await admin_api.post("/api/v1/cases", json={"title": "Increment Test", "priority": "low"})
    after  = (await admin_api.get("/api/v1/dashboard/stats")).json()["total_cases"]
    assert after == before + 1


@pytest.mark.asyncio
async def test_dashboard_activity_feed(admin_api):
    resp = await admin_api.get("/api/v1/dashboard/activity", params={"limit": 5})
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)
    assert len(resp.json()) <= 5


@pytest.mark.asyncio
async def test_platform_distribution(admin_api):
    resp = await admin_api.get("/api/v1/dashboard/platform-distribution")
    assert resp.status_code == 200
    data = resp.json()
    assert isinstance(data, list)
    for item in data:
        assert "platform" in item
        assert "count" in item
        assert "percentage" in item


@pytest.mark.asyncio
async def test_unauthenticated_dashboard_blocked(client: AsyncClient):
    resp = await client.get("/api/v1/dashboard/stats")
    assert resp.status_code == 401
