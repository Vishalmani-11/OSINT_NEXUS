"""
OSINT Nexus - Service Layer Unit Tests
Direct tests of business logic in app/services/*.py — independent of the
HTTP layer and of any live infrastructure (Redis, Neo4j, real Sherlock
network calls, InsightFace models). These exercise the same demo-mode /
fallback code paths the app actually uses when that infrastructure isn't
present, which is exactly what's relevant to verify.
"""
import asyncio
import json
import os
import tempfile
from pathlib import Path

import numpy as np
import pytest


# ════════════════════════════════════════════════════════════════════
# SHERLOCK SERVICE (demo mode — no real network calls)
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_sherlock_demo_search_returns_results():
    from app.services.sherlock import sherlock_service, DEMO_PLATFORMS

    results = await sherlock_service.search("testuser_abc123")
    assert len(results) == len(DEMO_PLATFORMS)
    for r in results:
        assert r.platform
        assert r.url.startswith("https://")
        assert isinstance(r.is_found, bool)
        assert r.http_status in (200, 404)


@pytest.mark.asyncio
async def test_sherlock_demo_search_is_deterministic():
    """Same username should always produce the same found/not-found pattern
    (seeded by username hash) — important so re-running a search is stable."""
    from app.services.sherlock import sherlock_service

    results_a = await sherlock_service.search("deterministic_user")
    results_b = await sherlock_service.search("deterministic_user")

    found_a = {r.platform for r in results_a if r.is_found}
    found_b = {r.platform for r in results_b if r.is_found}
    assert found_a == found_b


@pytest.mark.asyncio
async def test_sherlock_demo_different_usernames_differ():
    from app.services.sherlock import sherlock_service

    results_a = await sherlock_service.search("alice_osint_test")
    results_b = await sherlock_service.search("bob_osint_test")

    found_a = {r.platform for r in results_a if r.is_found}
    found_b = {r.platform for r in results_b if r.is_found}
    # Extremely unlikely to be identical for two different usernames
    assert found_a != found_b


@pytest.mark.asyncio
async def test_sherlock_progress_callback_invoked():
    from app.services.sherlock import sherlock_service, DEMO_PLATFORMS

    calls = []

    async def on_progress(checked, total, result):
        calls.append((checked, total))

    await sherlock_service.search("progress_test_user", progress_callback=on_progress)
    assert len(calls) == len(DEMO_PLATFORMS)
    assert calls[-1][0] == len(DEMO_PLATFORMS)  # last call reports full count


def test_sherlock_parse_json_output():
    from app.services.sherlock import sherlock_service

    fake_output = {
        "GitHub": {"status": "Claimed", "url": "https://github.com/x", "http_status": 200},
        "Twitter": {"status": "Available", "url": "https://twitter.com/x", "http_status": 404},
    }
    results = sherlock_service._parse_sherlock_json(fake_output, "x")
    assert len(results) == 2
    github = next(r for r in results if r.platform == "GitHub")
    assert github.is_found is True
    twitter = next(r for r in results if r.platform == "Twitter")
    assert twitter.is_found is False


# ════════════════════════════════════════════════════════════════════
# REPORTING SERVICE (PDF/HTML/JSON generation)
# ════════════════════════════════════════════════════════════════════

SAMPLE_REPORT_DATA = {
    "report": {"id": 1, "title": "Test Report", "format": "json"},
    "case": {
        "id": 1, "title": "Test Case", "case_number": "CASE-2024-0001",
        "description": "A test case", "status": "open", "priority": "medium",
        "created_at": "2024-01-01T00:00:00",
    },
    "stats": {
        "subjects": 2, "username_searches": 1, "profiles_found": 5,
        "face_embeddings": 1, "evidence_items": 3, "notes": 2,
    },
    "subjects": [{"name": "Jane Doe", "aliases": ["jd"], "emails": ["jd@x.com"]}],
    "username_searches": [{
        "username": "jdoe", "total_checked": 20, "total_found": 5,
        "profiles": [{"platform": "GitHub", "url": "https://github.com/jdoe",
                      "is_found": True, "http_status": 200}],
    }],
    "evidence": [{"title": "Screenshot", "description": "Profile pic",
                  "evidence_type": "screenshot", "url": None, "tags": ["social"]}],
    "notes": [{"content": "Subject is active online", "created_at": "2024-01-02T00:00:00"}],
    "include_summary": True, "include_evidence": True, "include_timeline": True,
}


@pytest.mark.asyncio
async def test_reporting_generate_json(tmp_path):
    from app.services.reporting import reporting_service

    out = str(tmp_path / "report.json")
    ok = await reporting_service.generate_json(SAMPLE_REPORT_DATA, out)
    assert ok is True
    assert Path(out).exists()

    data = json.loads(Path(out).read_text())
    assert data["case"]["title"] == "Test Case"
    assert data["stats"]["subjects"] == 2


@pytest.mark.asyncio
async def test_reporting_generate_html(tmp_path):
    from app.services.reporting import reporting_service

    out = str(tmp_path / "report.html")
    ok = await reporting_service.generate_html(SAMPLE_REPORT_DATA, out)
    assert ok is True

    html = Path(out).read_text()
    assert "Test Case" in html
    assert "CASE-2024-0001" in html
    assert "<html" in html.lower()


@pytest.mark.asyncio
async def test_reporting_generate_pdf(tmp_path):
    from app.services.reporting import reporting_service

    out = str(tmp_path / "report.pdf")
    ok = await reporting_service.generate_pdf(SAMPLE_REPORT_DATA, out)
    assert ok is True
    assert Path(out).exists()
    assert Path(out).stat().st_size > 0
    # PDF files start with the %PDF magic bytes
    assert Path(out).read_bytes()[:4] == b"%PDF"


def test_reporting_output_path_extension():
    from app.services.reporting import reporting_service

    assert reporting_service.get_output_path("abc-123", "pdf").endswith(".pdf")
    assert reporting_service.get_output_path("abc-123", "html").endswith(".html")
    assert reporting_service.get_output_path("abc-123", "json").endswith(".json")


# ════════════════════════════════════════════════════════════════════
# GRAPH SERVICE (mock fallback — no live Neo4j required)
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_graph_service_mock_graph_structure():
    from app.services.graph import graph_service

    # With no Neo4j running, get_driver() returns None and callers fall
    # back to the demo/mock graph — verify that fallback's shape directly.
    data = graph_service._mock_graph(case_id=42)
    assert "nodes" in data and "edges" in data
    assert data["node_count"] == len(data["nodes"])
    assert data["edge_count"] == len(data["edges"])
    assert all("id" in n and "type" in n for n in data["nodes"])
    assert all("source" in e and "target" in e for e in data["edges"])


@pytest.mark.asyncio
async def test_graph_service_get_case_graph_no_neo4j_falls_back():
    from app.services.graph import graph_service

    # In this test environment there's no Neo4j reachable, so this should
    # gracefully fall back to mock data rather than raising.
    result = await graph_service.get_case_graph(case_id=1, max_depth=2)
    assert "nodes" in result
    assert "edges" in result


def test_graph_service_mock_node_helper():
    from app.services.graph import graph_service

    node = graph_service._mock_node("Person", 7, "John Doe")
    assert node["id"] == "person:7"
    assert node["type"] == "person"
    assert node["name"] == "John Doe"


# ════════════════════════════════════════════════════════════════════
# PORTABLE TYPES (GUID / PortableJSON column types)
# ════════════════════════════════════════════════════════════════════

def test_guid_type_roundtrip_on_sqlite():
    """The GUID TypeDecorator must store/retrieve uuid.UUID objects
    correctly on a non-PostgreSQL dialect (this is exactly what made the
    test suite able to run against SQLite in the first place)."""
    import uuid
    from app.models.types import GUID
    from sqlalchemy.dialects import sqlite

    guid = GUID()
    dialect = sqlite.dialect()
    test_uuid = uuid.uuid4()

    bound = guid.process_bind_param(test_uuid, dialect)
    assert isinstance(bound, str)
    assert len(bound) == 32  # hex, no dashes

    restored = guid.process_result_value(bound, dialect)
    assert restored == test_uuid


def test_guid_type_handles_none():
    from app.models.types import GUID
    from sqlalchemy.dialects import sqlite

    guid = GUID()
    dialect = sqlite.dialect()
    assert guid.process_bind_param(None, dialect) is None
    assert guid.process_result_value(None, dialect) is None


# ════════════════════════════════════════════════════════════════════
# REVERSE IMAGE SEARCH SERVICE
# ════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_reverse_search_build_links_with_public_url():
    """With a public URL, all major engines get direct-link URLs."""
    from app.services.reverse_image_search import reverse_image_service

    links = reverse_image_service.build_search_links(
        image_path="/tmp/test.jpg",
        public_url="https://myserver.example.com/uploads/images/test.jpg",
    )
    assert any("Google Images" == k for k in links)
    assert any("Yandex" in k for k in links)
    assert any("TinEye" in k for k in links)
    assert any("Bing" in k for k in links)
    # Direct links must embed the image URL
    google = links.get("Google Images", "")
    assert "myserver.example.com" in google or "googleurl" in google.lower() or "google.com" in google


@pytest.mark.asyncio
async def test_reverse_search_build_links_without_public_url():
    """Without a public URL, only upload-page fallback links are returned."""
    from app.services.reverse_image_search import reverse_image_service

    links = reverse_image_service.build_search_links("/tmp/test.jpg", "")
    assert len(links) > 0
    # All links should be upload-page fallbacks
    assert all("(Upload)" in k or k in ("Google Images (Upload)", "Yandex (Upload)") 
               for k in links)


@pytest.mark.asyncio
async def test_reverse_search_get_image_info_graceful_on_bad_file(tmp_path):
    """get_image_info must not raise on corrupt/non-image file."""
    from app.services.reverse_image_search import reverse_image_service

    bad = tmp_path / "bad.jpg"
    bad.write_bytes(b"not an image")
    info = reverse_image_service.get_image_info(str(bad))
    assert isinstance(info, dict)
    # Should return None dimensions without raising
    assert "width" in info
    assert "height" in info


@pytest.mark.asyncio
async def test_reverse_search_save_upload_deduplicates(tmp_path, monkeypatch):
    """Same image bytes always land at the same path (content-hash naming)."""
    from app.services.reverse_image_search import reverse_image_service
    monkeypatch.setattr(reverse_image_service, "UPLOAD_DIR", tmp_path)

    content = b'\xff\xd8\xff\xd9'  # tiny JPEG
    path1, hash1 = await reverse_image_service.save_upload("a.jpg", content)
    path2, hash2 = await reverse_image_service.save_upload("b.jpg", content)
    assert path1 == path2
    assert hash1 == hash2


@pytest.mark.asyncio
async def test_reverse_search_full_session_no_api_keys(tmp_path, monkeypatch):
    """Full search() call without API keys returns links but no api_results."""
    from app.services.reverse_image_search import reverse_image_service, SERPAPI_AVAILABLE, TINEYE_AVAILABLE
    monkeypatch.setattr(reverse_image_service, "UPLOAD_DIR", tmp_path)

    content = b'\xff\xd8\xff\xd9'
    image_path, _ = await reverse_image_service.save_upload("test.jpg", content)

    session = await reverse_image_service.search(
        image_path=image_path,
        content=content,
        filename="test.jpg",
        public_base_url="",
    )
    assert session.filename == "test.jpg"
    assert isinstance(session.search_links, dict)
    assert len(session.search_links) > 0
    assert isinstance(session.results, list)
    # Without API keys, no API results are expected
    if not SERPAPI_AVAILABLE and not TINEYE_AVAILABLE:
        assert session.total_found == 0
