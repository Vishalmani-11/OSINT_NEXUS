# OSINT Nexus — Architecture Guide

## System Overview

```
┌─────────────────────────────────────────────────────────┐
│                   Docker Network: osint_net              │
│                                                          │
│  ┌──────────┐     ┌──────────┐     ┌─────────────────┐  │
│  │  Nginx   │────▶│ Frontend │     │    Backend      │  │
│  │  :80     │     │ Vite:3000│────▶│  FastAPI :8000  │  │
│  └──────────┘     └──────────┘     └────────┬────────┘  │
│       │                                     │           │
│       └─────────────────────────────────────┘           │
│                         │                               │
│         ┌───────────────┼───────────────┐               │
│         ▼               ▼               ▼               │
│   ┌──────────┐   ┌──────────┐   ┌──────────┐           │
│   │PostgreSQL│   │  Redis   │   │  Neo4j   │           │
│   │  :5432   │   │  :6379   │   │  :7687   │           │
│   └──────────┘   └──────────┘   └──────────┘           │
│                        │                                │
│              ┌──────────┴──────────┐                    │
│              ▼                     ▼                    │
│       ┌────────────┐      ┌─────────────────┐          │
│       │   Celery   │      │  Celery Beat    │          │
│       │   Worker   │      │  (Scheduler)    │          │
│       └────────────┘      └─────────────────┘          │
└─────────────────────────────────────────────────────────┘
```

## Service Responsibilities

| Service | Image | Responsibility |
|---------|-------|----------------|
| `nginx` | nginx:1.25-alpine | Reverse proxy, rate limiting, static file serving |
| `frontend` | node:20-alpine | Vite React dev server |
| `backend` | python:3.12-slim | FastAPI REST API, Alembic migrations |
| `celery_worker` | python:3.12-slim | Background tasks (scans, face processing, reports) |
| `celery_beat` | python:3.12-slim | Scheduled maintenance tasks |
| `postgres` | postgres:16-alpine | Primary relational data store |
| `redis` | redis:7-alpine | Celery broker + result backend, caching |
| `neo4j` | neo4j:5-community | Entity relationship graph |

## Data Flow

### Username Search
```
Browser → POST /api/v1/usernames/search
  → FastAPI creates UsernameSearch record (status=pending)
  → Celery task dispatched to Redis queue
  → Celery worker runs Sherlock (or demo)
  → Results saved as Profile records
  → UsernameSearch status → found/not_found
  → Graph updated (Person → Username → SocialProfile)
Browser polls GET /api/v1/usernames/search/{id} every 3s
```

### Face Analysis
```
Browser → POST /api/v1/faces/upload (multipart)
  → File saved to /app/uploads/faces/
  → FaceEmbedding record created
  → Celery task: InsightFace detects faces, generates 512-dim embedding
  → Embedding stored in PostgreSQL (JSONB column)

Browser → POST /api/v1/faces/search
  → Load query embedding from DB
  → Load all stored embeddings
  → Cosine similarity computed locally (no external API)
  → Matches above threshold returned
```

### Report Generation
```
Browser → POST /api/v1/reports/generate
  → Report record created (status=pending)
  → Celery task dispatched
  → Task queries all case data (subjects, searches, evidence, notes)
  → ReportLab (PDF) or Jinja2 (HTML) renders the report
  → File saved to /app/uploads/reports/
  → Report status → completed
Browser → GET /api/v1/reports/{id}/download (FileResponse)
```

## Database Schema

### PostgreSQL Tables

```
users              ← Platform users with roles
cases              ← Investigation cases
subjects           ← Persons/entities under investigation
username_searches  ← Sherlock scan sessions
profiles           ← Individual platform results per scan
face_embeddings    ← Uploaded images + face vectors
face_matches       ← Search result records
evidence           ← Attached evidence items
notes              ← Analyst notes per case
reports            ← Generated report records
activity_logs      ← Full audit trail
```

### Neo4j Node Types

```
(:Person)          → subject_id, name, case_id
(:Username)        → value, platform
(:SocialProfile)   → url, platform
(:Email)           → address
(:Website)         → url
(:Image)           → id, path
```

### Neo4j Relationships
```
(:Person)-[:HAS_USERNAME]→(:Username)
(:Username)-[:HAS_PROFILE]→(:SocialProfile)
(:Person)-[:HAS_EMAIL]→(:Email)
(:Person)-[:HAS_WEBSITE]→(:Website)
(:Person)-[:HAS_IMAGE]→(:Image)
(:Person)-[:RELATED_TO]→(:Person)
```

## Security Architecture

```
Request
  → Nginx (rate limit: 60/min API, 10/min auth)
  → FastAPI RequestIDMiddleware    (X-Request-ID header)
  → FastAPI SecurityHeadersMiddleware (X-Frame-Options etc.)
  → FastAPI AuditLoggingMiddleware  (logs all mutations)
  → slowapi rate limiter
  → JWT HTTPBearer dependency       (token validation)
  → RequireRole dependency          (RBAC check)
  → Handler
  → ActivityLog written to PostgreSQL
```

### JWT Token Lifecycle
```
POST /auth/login
  → access_token  (HS256, 30 min)  — sent in Authorization header
  → refresh_token (HS256, 7 days)  — sent to /auth/refresh for rotation

On 401: axios interceptor auto-calls /auth/refresh
  → new access_token issued
  → queued requests replayed with new token
  → on refresh failure: localStorage cleared, redirect to /login
```

## Volume Mounts (Docker)

| Volume | Mount point | Contents |
|--------|-------------|---------|
| `postgres_data` | `/var/lib/postgresql/data` | All relational data |
| `redis_data`    | `/data` | Celery queue persistence |
| `neo4j_data`    | `/data` | Graph data |
| `uploads_data`  | `/app/uploads` | Faces, evidence, reports |

> The `uploads_data` volume is shared between `backend` and `celery_worker`
> so that background tasks can read uploaded files and write reports.

## Environment Variables

All services share the `x-backend-env` anchor in `docker-compose.yml`.
See `.env.example` for the full list. Key variables:

| Variable | Used by | Purpose |
|----------|---------|---------|
| `SECRET_KEY` | backend | JWT signing (min 32 chars) |
| `DATABASE_URL` | backend | asyncpg connection string |
| `SYNC_DATABASE_URL` | backend | psycopg2 for Alembic |
| `REDIS_URL` | backend, workers | Broker + result backend |
| `NEO4J_URL/USER/PASSWORD` | backend, workers | Graph DB |
| `UPLOAD_DIR` | backend, workers | File storage path |
| `CORS_ORIGINS` | backend | Allowed frontend origins (JSON array) |
