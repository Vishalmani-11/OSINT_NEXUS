# OSINT Nexus — Docker Deployment Guide

## Prerequisites

| Tool | Minimum Version |
|------|----------------|
| Docker | 24.0 |
| Docker Compose | v2.20 |
| RAM | 4 GB (8 GB recommended) |
| Disk | 10 GB |

---

## Quick Start (3 commands)

```bash
git clone https://github.com/your-org/osint-nexus.git
cd osint-nexus
make setup
```

`make setup` will:
1. Copy `.env.example` → `.env`
2. Build all Docker images
3. Start all 7 services
4. Run Alembic migrations
5. Print access URLs

---

## Manual Setup

### 1. Configure environment

```bash
cp .env.example .env
```

Edit `.env` — **change every value that says `CHANGE_ME`**:

```bash
# Generate a secure SECRET_KEY:
python3 -c "import secrets; print(secrets.token_hex(32))"

# Paste the output into .env as SECRET_KEY=...
```

### 2. Build images

```bash
docker compose build
```

### 3. Start all services

```bash
docker compose up -d
```

### 4. Run migrations

```bash
docker compose exec backend alembic upgrade head
```

### 5. Verify health

```bash
curl http://localhost:8000/api/v1/health
# → {"status":"healthy","version":"1.0.0","database":true,...}
```

---

## Accessing Services

| Service | URL | Notes |
|---------|-----|-------|
| Frontend | http://localhost:3000 | React app (via Vite dev server) |
| Nginx gateway | http://localhost | Routes to frontend + backend |
| API docs | http://localhost:8000/api/v1/docs | Swagger UI |
| ReDoc | http://localhost:8000/api/v1/redoc | Alternative docs |
| Neo4j browser | http://localhost:7474 | Graph visualization |
| PostgreSQL | localhost:5432 | Direct DB access |
| Redis | localhost:6379 | Cache / broker |

**Register your first account** at http://localhost:3000/register.
The first registered user automatically receives the **Admin** role.

---

## Common Make Commands

```bash
make up               # Start all containers
make down             # Stop all containers
make restart          # Restart all containers
make logs             # Tail all logs
make logs-backend     # Tail backend logs only
make logs-celery      # Tail Celery worker logs

make migrate          # Run pending migrations
make shell            # Open bash in backend container
make shell-db         # Open psql in postgres container

make test             # Run full test suite
make test-cov         # Run tests with coverage report
make lint             # Check code style (black + flake8)
make format           # Auto-format code

make health           # Check API health endpoint
make ps               # Show running containers

make clean            # Remove pyc files and caches
make clean-all        # Also remove Docker volumes (DESTRUCTIVE)
```

---

## Troubleshooting

### Backend won't start
```bash
docker compose logs backend
# Common causes:
# - DATABASE_URL wrong (check POSTGRES_USER/PASSWORD match)
# - Port 8000 already in use: lsof -i :8000
```

### Migrations fail
```bash
docker compose exec backend alembic downgrade base
docker compose exec backend alembic upgrade head
```

### Celery tasks not running
```bash
docker compose logs celery_worker
# Common causes:
# - REDIS_URL wrong (check REDIS_PASSWORD)
# - Worker not connected to correct queue
docker compose exec backend celery -A app.celery_app inspect active
```

### Neo4j graph empty
```bash
# Neo4j takes ~30 seconds to start. Check:
docker compose logs neo4j | tail -20
# Then trigger a graph rebuild:
docker compose exec backend python3 -c "
import asyncio
from app.services.graph import graph_service
asyncio.run(graph_service.setup_schema())
print('Schema OK')
"
```

### Face analysis falls back to OpenCV
InsightFace is **not** installed by default (it's large).
To enable it, add to `backend/requirements.txt`:
```
insightface==0.7.3
onnxruntime==1.16.3
```
Then rebuild: `make rebuild`

### Sherlock not found → demo mode
Sherlock is installed as an optional step in the Dockerfile.
If the pip install failed silently, demo mode is used automatically.
To force real Sherlock:
```bash
docker compose exec backend pip install sherlock-project
```

---

## Environment Variables Reference

| Variable | Default | Required | Description |
|----------|---------|----------|-------------|
| `SECRET_KEY` | — | ✅ | JWT signing key (min 32 chars) |
| `POSTGRES_USER` | osint | | DB username |
| `POSTGRES_PASSWORD` | osint_pass | ✅ | DB password |
| `POSTGRES_DB` | osint_nexus | | Database name |
| `REDIS_PASSWORD` | redis_pass | ✅ | Redis auth password |
| `NEO4J_USER` | neo4j | | Neo4j username |
| `NEO4J_PASSWORD` | neo4j_pass | ✅ | Neo4j password (min 8 chars) |
| `ENVIRONMENT` | development | | `development` or `production` |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | 30 | | JWT access token TTL |
| `REFRESH_TOKEN_EXPIRE_DAYS` | 7 | | JWT refresh token TTL |
| `MAX_UPLOAD_SIZE_MB` | 10 | | Max file upload size |
| `RATE_LIMIT_PER_MINUTE` | 60 | | API rate limit per IP |
| `FACE_SIMILARITY_THRESHOLD` | 0.6 | | Min score for face match |

---

## Production Hardening

Before deploying to a real server, additionally:

1. **Set `ENVIRONMENT=production`** in `.env`
2. **Use HTTPS** — add an SSL certificate to Nginx (Let's Encrypt / Certbot)
3. **Restrict port exposure** — remove direct `postgres`, `redis`, `neo4j` port mappings
4. **Enable Neo4j authentication** — already enforced via `NEO4J_AUTH`
5. **Set `CORS_ORIGINS`** to your real domain only
6. **Configure log aggregation** (Loki / ELK)
7. **Set up automated backups** for the `postgres_data` volume

---

## Updating

```bash
git pull
docker compose build
docker compose up -d
docker compose exec backend alembic upgrade head
```
