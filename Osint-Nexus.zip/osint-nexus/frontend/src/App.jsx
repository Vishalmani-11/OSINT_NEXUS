/**
 * OSINT Nexus - Root Application Component
 * Wires together routing, auth guards, React Query, and toast notifications.
 */
import React, { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Toaster } from 'react-hot-toast'

import useAuthStore from './store/authStore'
import Layout from './components/Layout/Layout'

// Pages
import LoginPage from './pages/Login'
import RegisterPage from './pages/Register'
import DashboardPage from './pages/Dashboard'
import CasesPage from './pages/Cases'
import CaseDetailPage from './pages/CaseDetail'
import UsernameSearchPage from './pages/UsernameSearch'
import ReverseImageSearchPage from './pages/ReverseImageSearch'
import GraphViewPage from './pages/GraphView'
import ReportsPage from './pages/Reports'
import ProfilePage from './pages/Profile'

// ── React Query Client ────────────────────────────────────────────────────────
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,      // 30 seconds
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
})

// ── Auth Guard ────────────────────────────────────────────────────────────────
function PrivateRoute({ children }) {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)
  const location = useLocation()

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />
  }
  return children
}

function PublicRoute({ children }) {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)
  if (isAuthenticated) return <Navigate to="/" replace />
  return children
}

// ── Session Restore ───────────────────────────────────────────────────────────
function SessionRestorer() {
  const fetchMe = useAuthStore((s) => s.fetchMe)
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)

  useEffect(() => {
    if (isAuthenticated) fetchMe()
  }, [])

  return null
}

// ── Root App ──────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <SessionRestorer />
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#0d1b2a',
              color: '#e2e8f0',
              border: '1px solid #1e3a5c',
              fontFamily: '"JetBrains Mono", monospace',
              fontSize: '13px',
            },
            success: { iconTheme: { primary: '#00ff88', secondary: '#0d1b2a' } },
            error: { iconTheme: { primary: '#ef4444', secondary: '#0d1b2a' } },
          }}
        />
        <Routes>
          {/* Public Routes */}
          <Route path="/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
          <Route path="/register" element={<PublicRoute><RegisterPage /></PublicRoute>} />

          {/* Protected Routes wrapped in Layout */}
          <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
            <Route index element={<DashboardPage />} />
            <Route path="cases" element={<CasesPage />} />
            <Route path="cases/:id" element={<CaseDetailPage />} />
            <Route path="username-search" element={<UsernameSearchPage />} />
            <Route path="image-search" element={<ReverseImageSearchPage />} />
            <Route path="graph" element={<GraphViewPage />} />
            <Route path="reports" element={<ReportsPage />} />
            <Route path="profile" element={<ProfilePage />} />
          </Route>

          {/* 404 fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  )
}
