/**
 * OSINT Nexus - Main Layout
 * Shell that wraps all protected pages with sidebar + top bar.
 */
import React from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import { Wifi } from 'lucide-react'
import Sidebar from './Sidebar'
import useAuthStore from '../../store/authStore'

const PAGE_TITLES = {
  '/':                'Dashboard',
  '/cases':           'Investigation Cases',
  '/username-search': 'Username OSINT',
  '/image-search':    'Image Search',
  '/graph':           'Graph Intelligence',
  '/reports':         'Reports',
  '/profile':         'Profile',
}

export default function Layout() {
  const location = useLocation()
  const user = useAuthStore((s) => s.user)

  // Match dynamic routes like /cases/123
  const getTitle = () => {
    if (location.pathname.startsWith('/cases/')) return 'Case Detail'
    return PAGE_TITLES[location.pathname] || 'OSINT Nexus'
  }

  return (
    <div className="flex h-screen overflow-hidden bg-surface-900">
      <Sidebar />

      {/* Main content area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="h-12 bg-surface-800 border-b border-surface-600 flex items-center
                           justify-between px-5 flex-shrink-0">
          <div className="flex items-center gap-3">
            {/* Breadcrumb path */}
            <span className="text-xs font-mono text-slate-600">~/osint-nexus</span>
            <span className="text-xs font-mono text-slate-700">/</span>
            <span className="text-xs font-mono text-brand">{getTitle()}</span>
          </div>

          <div className="flex items-center gap-3">
            {/* Connection indicator */}
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-600">
              <Wifi size={10} className="text-brand" />
              SECURE
            </div>

            {/* User badge */}
            <div className="flex items-center gap-2 pl-3 border-l border-surface-600">
              <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">
                {user?.role}
              </div>
              <div className="w-6 h-6 rounded bg-brand/10 border border-brand/20
                              flex items-center justify-center text-[10px] font-mono
                              font-bold text-brand">
                {user?.username?.[0]?.toUpperCase() || 'U'}
              </div>
            </div>
          </div>
        </header>

        {/* Scrollable page content */}
        <main className="flex-1 overflow-y-auto p-5">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
