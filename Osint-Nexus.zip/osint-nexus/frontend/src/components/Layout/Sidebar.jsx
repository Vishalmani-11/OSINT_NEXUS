/**
 * OSINT Nexus - Sidebar Navigation
 * Persistent left sidebar with section links and user info.
 */
import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard, FolderSearch, AtSign, Globe,
  Share2, FileText, User, LogOut, Shield, Activity
} from 'lucide-react'
import useAuthStore from '../../store/authStore'
import toast from 'react-hot-toast'

const NAV_ITEMS = [
  { to: '/',                label: 'Dashboard',       icon: LayoutDashboard,  exact: true },
  { to: '/cases',           label: 'Cases',           icon: FolderSearch },
  { to: '/username-search', label: 'Username OSINT',  icon: AtSign },
  { to: '/image-search',    label: 'Image Search',    icon: Globe },
  { to: '/graph',           label: 'Graph Intel',     icon: Share2 },
  { to: '/reports',         label: 'Reports',         icon: FileText },
]

function NavItem({ to, label, icon: Icon, exact }) {
  return (
    <NavLink
      to={to}
      end={exact}
      className={({ isActive }) =>
        `flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-all duration-150
         ${isActive
          ? 'bg-brand/10 text-brand border border-brand/20 shadow-[0_0_8px_rgba(0,255,136,0.1)]'
          : 'text-slate-500 hover:text-slate-200 hover:bg-surface-600'
        }`
      }
    >
      <Icon size={16} strokeWidth={1.5} />
      <span className="font-mono tracking-wide">{label}</span>
    </NavLink>
  )
}

export default function Sidebar() {
  const { user, logout } = useAuthStore()
  const navigate = useNavigate()

  const handleLogout = async () => {
    await logout()
    toast.success('Logged out')
    navigate('/login')
  }

  return (
    <aside className="w-60 flex-shrink-0 bg-surface-800 border-r border-surface-600
                      flex flex-col h-screen sticky top-0">
      {/* Logo */}
      <div className="px-4 pt-5 pb-4 border-b border-surface-600">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded flex items-center justify-center
                          bg-brand/10 border border-brand/30">
            <Shield size={14} className="text-brand" />
          </div>
          <div>
            <div className="font-mono font-bold text-brand text-sm tracking-widest">OSINT</div>
            <div className="font-mono font-bold text-slate-400 text-xs tracking-widest -mt-0.5">NEXUS</div>
          </div>
        </div>
        <div className="mt-2 text-[10px] font-mono text-slate-600 tracking-widest">
          v1.0 // EDUCATIONAL PLATFORM
        </div>
      </div>

      {/* System status */}
      <div className="px-4 py-2 border-b border-surface-600">
        <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-600">
          <Activity size={10} className="text-brand animate-pulse" />
          SYSTEM OPERATIONAL
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        <div className="text-[10px] font-mono text-slate-600 uppercase tracking-widest px-2 mb-2">
          Navigation
        </div>
        {NAV_ITEMS.map((item) => (
          <NavItem key={item.to} {...item} />
        ))}
      </nav>

      {/* User section */}
      <div className="border-t border-surface-600 p-3">
        <NavLink
          to="/profile"
          className="flex items-center gap-2.5 px-2 py-2 rounded-md hover:bg-surface-600
                     text-slate-400 hover:text-slate-200 transition-colors mb-1"
        >
          <div className="w-7 h-7 rounded-md bg-surface-500 flex items-center justify-center
                          border border-surface-500 flex-shrink-0">
            <User size={13} className="text-slate-400" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-mono text-slate-300 truncate">
              {user?.username || 'Analyst'}
            </div>
            <div className="text-[10px] font-mono text-slate-600 uppercase tracking-wider">
              {user?.role || 'user'}
            </div>
          </div>
        </NavLink>
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-xs
                     font-mono text-slate-600 hover:text-red-400 hover:bg-red-900/20
                     transition-colors"
        >
          <LogOut size={12} />
          DISCONNECT
        </button>
      </div>
    </aside>
  )
}
