/**
 * OSINT Nexus - Shared UI Components
 * StatusBadge, Modal, ConfirmDialog, EmptyState, Spinner, ErrorBoundary
 */
import React, { Component, useState, useEffect } from 'react'
import { AlertTriangle, X, Loader, RefreshCw } from 'lucide-react'
import { STATUS_COLOR, PRIORITY_COLOR, copyToClipboard } from '../../utils/helpers'

// ── Status Badge ──────────────────────────────────────────────────
export function StatusBadge({ value, type = 'status', className = '' }) {
  const map = type === 'priority' ? PRIORITY_COLOR : STATUS_COLOR
  const colorClass = map[value?.toLowerCase()] || 'text-slate-500 bg-slate-800 border-slate-700'
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono
                      font-semibold uppercase tracking-wider border ${colorClass} ${className}`}>
      {value?.replace('_', ' ')}
    </span>
  )
}

// ── Loading Spinner ───────────────────────────────────────────────
export function Spinner({ size = 20, className = '' }) {
  return (
    <Loader
      size={size}
      className={`text-brand animate-spin ${className}`}
    />
  )
}

export function PageSpinner({ message = 'Loading…' }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-3">
      <Spinner size={28} />
      <p className="text-xs font-mono text-slate-600">{message}</p>
    </div>
  )
}

// ── Skeleton Loader ───────────────────────────────────────────────
export function Skeleton({ className = 'h-8 w-full' }) {
  return <div className={`skeleton rounded ${className}`} />
}

export function CardSkeleton() {
  return (
    <div className="card p-4 space-y-3 animate-pulse">
      <Skeleton className="h-4 w-1/3" />
      <Skeleton className="h-6 w-2/3" />
      <Skeleton className="h-4 w-full" />
    </div>
  )
}

// ── Empty State ───────────────────────────────────────────────────
export function EmptyState({ icon: Icon, title, description, action }) {
  return (
    <div className="py-16 flex flex-col items-center text-center gap-3">
      {Icon && <Icon size={36} className="text-slate-700" />}
      <div>
        <p className="text-sm font-mono text-slate-500">{title}</p>
        {description && (
          <p className="text-xs font-mono text-slate-700 mt-1 max-w-xs">{description}</p>
        )}
      </div>
      {action}
    </div>
  )
}

// ── Modal ─────────────────────────────────────────────────────────
export function Modal({ title, onClose, children, maxWidth = 'max-w-md', icon: Icon }) {
  // Close on Escape
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape') onClose?.() }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [onClose])

  return (
    <div
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={(e) => { if (e.target === e.currentTarget) onClose?.() }}
    >
      <div className={`card-elevated w-full ${maxWidth} animate-fade-in`}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-4 pb-3 border-b border-surface-600">
          <div className="flex items-center gap-2">
            {Icon && <Icon size={14} className="text-brand" />}
            <h3 className="text-sm font-mono font-semibold text-slate-200 tracking-wide">{title}</h3>
          </div>
          <button onClick={onClose} className="btn-icon text-slate-600 hover:text-slate-300">
            <X size={14} />
          </button>
        </div>
        {/* Body */}
        <div className="px-5 py-4">{children}</div>
      </div>
    </div>
  )
}

// ── Confirm Dialog ────────────────────────────────────────────────
export function ConfirmDialog({ title, message, confirmLabel = 'Confirm', danger = false, onConfirm, onCancel }) {
  return (
    <Modal title={title} onClose={onCancel} icon={AlertTriangle} maxWidth="max-w-sm">
      <p className="text-sm text-slate-400 mb-5">{message}</p>
      <div className="flex gap-2 justify-end">
        <button onClick={onCancel} className="btn-secondary px-4">Cancel</button>
        <button
          onClick={onConfirm}
          className={danger ? 'btn-danger' : 'btn-primary'}
        >
          {confirmLabel}
        </button>
      </div>
    </Modal>
  )
}

// ── Alert Banner ──────────────────────────────────────────────────
export function Alert({ type = 'info', children }) {
  const styles = {
    info:    'bg-blue-900/20 border-blue-900/50 text-blue-400',
    success: 'bg-emerald-900/20 border-emerald-900/50 text-emerald-400',
    warning: 'bg-amber-900/20 border-amber-900/50 text-amber-400',
    error:   'bg-red-900/20 border-red-900/50 text-red-400',
  }
  return (
    <div className={`border rounded-md p-3 text-xs font-mono ${styles[type] || styles.info}`}>
      {children}
    </div>
  )
}

// ── Copy Button ───────────────────────────────────────────────────
export function CopyButton({ text, className = '' }) {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    const ok = await copyToClipboard(text)
    if (ok) {
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    }
  }

  return (
    <button
      onClick={handleCopy}
      className={`text-[10px] font-mono px-1.5 py-0.5 rounded
                  ${copied ? 'text-brand' : 'text-slate-600 hover:text-slate-400'}
                  transition-colors ${className}`}
    >
      {copied ? '✓ copied' : 'copy'}
    </button>
  )
}

// ── Progress Bar ──────────────────────────────────────────────────
export function ProgressBar({ value, max, label }) {
  const pct = max > 0 ? Math.min((value / max) * 100, 100) : 0
  return (
    <div>
      {label && (
        <div className="flex justify-between text-[10px] font-mono text-slate-600 mb-1">
          <span>{label}</span>
          <span>{value}/{max}</span>
        </div>
      )}
      <div className="h-1.5 bg-surface-600 rounded-full overflow-hidden">
        <div
          className="h-full bg-brand rounded-full transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  )
}

// ── Error Boundary ────────────────────────────────────────────────
export class ErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false, error: null }
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error }
  }

  componentDidCatch(error, info) {
    console.error('ErrorBoundary caught:', error, info)
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="card p-8 text-center">
          <AlertTriangle size={32} className="text-red-400 mx-auto mb-3" />
          <h3 className="text-sm font-mono font-semibold text-red-400 mb-2">
            Component Error
          </h3>
          <p className="text-xs font-mono text-slate-600 mb-4">
            {this.state.error?.message || 'Something went wrong'}
          </p>
          <button
            onClick={() => this.setState({ hasError: false, error: null })}
            className="btn-secondary text-xs"
          >
            <RefreshCw size={12} /> Try Again
          </button>
        </div>
      )
    }
    return this.props.children
  }
}

// ── Stat Diff indicator ───────────────────────────────────────────
export function StatDiff({ value, positive = true }) {
  if (value === null || value === undefined) return null
  const isUp = value > 0
  const color = positive ? (isUp ? 'text-brand' : 'text-red-400') : (isUp ? 'text-red-400' : 'text-brand')
  return (
    <span className={`text-[10px] font-mono ${color}`}>
      {isUp ? '▲' : '▼'} {Math.abs(value)}
    </span>
  )
}

// ── Tag list ──────────────────────────────────────────────────────
export function TagList({ tags = [], onRemove, color = 'text-slate-400 bg-surface-600' }) {
  if (!tags.length) return null
  return (
    <div className="flex flex-wrap gap-1">
      {tags.map((tag) => (
        <span
          key={tag}
          className={`inline-flex items-center gap-1 text-[10px] font-mono px-1.5 py-0.5 rounded ${color}`}
        >
          #{tag}
          {onRemove && (
            <button onClick={() => onRemove(tag)} className="hover:text-red-400 transition-colors">
              <X size={8} />
            </button>
          )}
        </span>
      ))}
    </div>
  )
}

// ── Divider with label ────────────────────────────────────────────
export function Divider({ label }) {
  return (
    <div className="flex items-center gap-3 my-4">
      <div className="flex-1 h-px bg-surface-600" />
      {label && <span className="text-[10px] font-mono text-slate-700 uppercase tracking-widest">{label}</span>}
      <div className="flex-1 h-px bg-surface-600" />
    </div>
  )
}

export default {
  StatusBadge, Spinner, PageSpinner, Skeleton, CardSkeleton,
  EmptyState, Modal, ConfirmDialog, Alert, CopyButton,
  ProgressBar, ErrorBoundary, StatDiff, TagList, Divider,
}
