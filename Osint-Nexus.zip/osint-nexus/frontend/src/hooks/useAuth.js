/**
 * OSINT Nexus - useAuth hook
 * Convenience wrapper around the Zustand auth store.
 */
import useAuthStore from '../store/authStore'

export function useAuth() {
  const {
    user,
    isAuthenticated,
    isLoading,
    login,
    register,
    logout,
    fetchMe,
    isAdmin,
    isAnalyst,
  } = useAuthStore()

  return {
    user,
    isAuthenticated,
    isLoading,
    login,
    register,
    logout,
    fetchMe,
    isAdmin: isAdmin(),
    isAnalyst: isAnalyst(),
    isViewer: !isAnalyst(),
    canWrite: isAnalyst(),
    canAdmin: isAdmin(),
  }
}

export default useAuth
