/**
 * OSINT Nexus - usePolling hook
 * Poll an async function at an interval until a condition is met.
 */
import { useEffect, useRef, useCallback } from 'react'

/**
 * @param {Function}  fetchFn     Async function that returns the current state
 * @param {Function}  shouldStop  (data) => boolean — return true to stop polling
 * @param {number}    interval    Milliseconds between polls (default 3000)
 * @param {boolean}   enabled     Set false to pause polling
 */
export function usePolling(fetchFn, shouldStop, interval = 3000, enabled = true) {
  const timerRef = useRef(null)
  const mountedRef = useRef(true)

  const poll = useCallback(async () => {
    if (!mountedRef.current) return
    try {
      const data = await fetchFn()
      if (shouldStop(data)) {
        clearInterval(timerRef.current)
      }
    } catch (_) {
      // Silently swallow poll errors — caller handles state
    }
  }, [fetchFn, shouldStop])

  useEffect(() => {
    mountedRef.current = true
    if (!enabled) return

    poll() // immediate first call
    timerRef.current = setInterval(poll, interval)

    return () => {
      mountedRef.current = false
      clearInterval(timerRef.current)
    }
  }, [poll, interval, enabled])
}

export default usePolling
