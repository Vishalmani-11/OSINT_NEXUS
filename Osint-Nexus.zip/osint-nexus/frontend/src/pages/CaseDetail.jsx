/**
 * OSINT Nexus - Case Detail Page
 * Full case workspace with tabbed navigation: Overview, Subjects, Evidence, Notes, Timeline.
 */
import React, { useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  ChevronLeft, Users, Shield, FileText, Clock, AtSign,
  Plus, Trash2, Pin, ExternalLink, ScanFace, Edit3
} from 'lucide-react'
import { casesAPI } from '../services/api'
import { formatDistanceToNow, format } from 'date-fns'
import toast from 'react-hot-toast'

const TABS = [
  { id: 'overview',  label: 'Overview',  icon: Shield },
  { id: 'subjects',  label: 'Subjects',  icon: Users },
  { id: 'evidence',  label: 'Evidence',  icon: FileText },
  { id: 'notes',     label: 'Notes',     icon: Pin },
  { id: 'timeline',  label: 'Timeline',  icon: Clock },
]

// ── Add Subject Modal ─────────────────────────────────────────────
function AddSubjectModal({ caseId, onClose }) {
  const [form, setForm] = useState({
    name: '', aliases: '', emails: '', websites: '', description: ''
  })
  const qc = useQueryClient()
  const mutation = useMutation({
    mutationFn: (data) => casesAPI.createSubject(caseId, data).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['subjects', caseId] })
      toast.success('Subject added')
      onClose()
    },
    onError: (e) => toast.error(e.response?.data?.detail || 'Failed'),
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    mutation.mutate({
      ...form,
      case_id: caseId,
      aliases: form.aliases ? form.aliases.split(',').map(s => s.trim()).filter(Boolean) : [],
      emails: form.emails ? form.emails.split(',').map(s => s.trim()).filter(Boolean) : [],
      websites: form.websites ? form.websites.split(',').map(s => s.trim()).filter(Boolean) : [],
    })
  }

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="card-elevated w-full max-w-md p-5 animate-fade-in">
        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-surface-600">
          <Users size={14} className="text-brand" />
          <h3 className="text-sm font-mono font-semibold text-slate-200">Add Subject</h3>
        </div>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="input-label">Name *</label>
            <input className="input" placeholder="John Doe" value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })} required />
          </div>
          <div>
            <label className="input-label">Known Aliases (comma separated)</label>
            <input className="input" placeholder="johnny, jd1990" value={form.aliases}
              onChange={e => setForm({ ...form, aliases: e.target.value })} />
          </div>
          <div>
            <label className="input-label">Email Addresses (comma separated)</label>
            <input className="input" placeholder="john@example.com" value={form.emails}
              onChange={e => setForm({ ...form, emails: e.target.value })} />
          </div>
          <div>
            <label className="input-label">Websites (comma separated)</label>
            <input className="input" placeholder="https://john.example.com" value={form.websites}
              onChange={e => setForm({ ...form, websites: e.target.value })} />
          </div>
          <div>
            <label className="input-label">Description</label>
            <textarea className="input resize-none" rows={2} placeholder="Notes about this subject..."
              value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
          </div>
          <div className="flex gap-2 pt-1">
            <button type="submit" disabled={mutation.isPending} className="btn-primary flex-1 justify-center">
              {mutation.isPending ? 'ADDING...' : 'ADD SUBJECT'}
            </button>
            <button type="button" onClick={onClose} className="btn-secondary px-4">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  )
}

// ── Add Evidence Modal ────────────────────────────────────────────
function AddEvidenceModal({ caseId, onClose }) {
  const [form, setForm] = useState({ title: '', description: '', evidence_type: 'url', url: '', source: '', tags: '' })
  const qc = useQueryClient()
  const mutation = useMutation({
    mutationFn: (data) => casesAPI.createEvidence(caseId, data).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['evidence', caseId] }); toast.success('Evidence added'); onClose() },
    onError: (e) => toast.error(e.response?.data?.detail || 'Failed'),
  })
  const handleSubmit = (e) => {
    e.preventDefault()
    mutation.mutate({
      ...form,
      case_id: caseId,
      tags: form.tags ? form.tags.split(',').map(s => s.trim()).filter(Boolean) : [],
    })
  }
  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="card-elevated w-full max-w-md p-5 animate-fade-in">
        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-surface-600">
          <FileText size={14} className="text-brand" /><h3 className="text-sm font-mono font-semibold text-slate-200">Add Evidence</h3>
        </div>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="input-label">Title *</label>
            <input className="input" placeholder="Twitter Profile Screenshot" value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })} required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="input-label">Type</label>
              <select className="input" value={form.evidence_type}
                onChange={e => setForm({ ...form, evidence_type: e.target.value })}>
                {['url','screenshot','document','image','note','other'].map(t => (
                  <option key={t} value={t}>{t.toUpperCase()}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="input-label">Source</label>
              <input className="input" placeholder="Twitter" value={form.source}
                onChange={e => setForm({ ...form, source: e.target.value })} />
            </div>
          </div>
          <div>
            <label className="input-label">URL</label>
            <input className="input" placeholder="https://..." value={form.url}
              onChange={e => setForm({ ...form, url: e.target.value })} />
          </div>
          <div>
            <label className="input-label">Description</label>
            <textarea className="input resize-none" rows={2} value={form.description}
              onChange={e => setForm({ ...form, description: e.target.value })} />
          </div>
          <div>
            <label className="input-label">Tags</label>
            <input className="input" placeholder="social, profile" value={form.tags}
              onChange={e => setForm({ ...form, tags: e.target.value })} />
          </div>
          <div className="flex gap-2 pt-1">
            <button type="submit" disabled={mutation.isPending} className="btn-primary flex-1 justify-center">
              {mutation.isPending ? 'ADDING...' : 'ADD EVIDENCE'}
            </button>
            <button type="button" onClick={onClose} className="btn-secondary px-4">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default function CaseDetailPage() {
  const { id } = useParams()
  const [activeTab, setActiveTab] = useState('overview')
  const [showAddSubject, setShowAddSubject] = useState(false)
  const [showAddEvidence, setShowAddEvidence] = useState(false)
  const [noteText, setNoteText] = useState('')
  const qc = useQueryClient()

  const { data: caseData, isLoading } = useQuery({
    queryKey: ['case', id],
    queryFn: () => casesAPI.get(id).then(r => r.data),
  })
  const { data: subjects } = useQuery({
    queryKey: ['subjects', id],
    queryFn: () => casesAPI.listSubjects(id).then(r => r.data),
    enabled: activeTab === 'subjects' || activeTab === 'overview',
  })
  const { data: evidence } = useQuery({
    queryKey: ['evidence', id],
    queryFn: () => casesAPI.listEvidence(id).then(r => r.data),
    enabled: activeTab === 'evidence' || activeTab === 'overview',
  })
  const { data: notes } = useQuery({
    queryKey: ['notes', id],
    queryFn: () => casesAPI.listNotes(id).then(r => r.data),
    enabled: activeTab === 'notes',
  })
  const { data: timeline } = useQuery({
    queryKey: ['timeline', id],
    queryFn: () => casesAPI.getTimeline(id).then(r => r.data),
    enabled: activeTab === 'timeline',
  })

  const addNote = useMutation({
    mutationFn: () => casesAPI.createNote(id, { content: noteText, case_id: parseInt(id) }).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['notes', id] }); setNoteText(''); toast.success('Note added') },
  })
  const deleteSubject = useMutation({
    mutationFn: (sid) => casesAPI.deleteSubject(id, sid),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['subjects', id] }); toast.success('Subject removed') },
  })
  const deleteEvidence = useMutation({
    mutationFn: (eid) => casesAPI.deleteEvidence(id, eid),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['evidence', id] }); toast.success('Evidence removed') },
  })

  if (isLoading) return (
    <div className="space-y-4 animate-fade-in">
      <div className="skeleton h-8 w-48 rounded" />
      <div className="skeleton h-40 rounded" />
    </div>
  )
  if (!caseData) return <div className="text-center text-slate-600 font-mono py-20">Case not found</div>

  const c = caseData

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Back + Header */}
      <div>
        <Link to="/cases" className="inline-flex items-center gap-1.5 text-xs font-mono text-slate-600
                                     hover:text-slate-400 transition-colors mb-3">
          <ChevronLeft size={13} /> All Cases
        </Link>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono text-slate-600">{c.case_number}</span>
              <span className={`badge badge-${c.status}`}>{c.status}</span>
              <span className={`badge badge-${c.priority}`}>{c.priority}</span>
            </div>
            <h1 className="text-xl font-mono font-bold text-slate-200">{c.title}</h1>
            {c.description && <p className="text-xs text-slate-600 mt-1">{c.description}</p>}
          </div>
          <div className="flex gap-2 flex-shrink-0">
            <Link to={`/username-search?case_id=${c.id}`} className="btn-secondary text-xs">
              <AtSign size={12} /> Search Username
            </Link>
            <Link to={`/face-analysis?case_id=${c.id}`} className="btn-secondary text-xs">
              <ScanFace size={12} /> Face Analysis
            </Link>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-surface-600 pb-0">
        {TABS.map(({ id: tid, label, icon: Icon }) => (
          <button
            key={tid}
            onClick={() => setActiveTab(tid)}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-mono transition-colors
                        border-b-2 -mb-px ${activeTab === tid
              ? 'text-brand border-brand'
              : 'text-slate-500 border-transparent hover:text-slate-300'}`}
          >
            <Icon size={12} />{label}
          </button>
        ))}
      </div>

      {/* ── OVERVIEW TAB ── */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="card p-4">
            <div className="section-header"><Users size={11} />Subjects ({subjects?.length ?? 0})</div>
            {subjects?.slice(0, 5).map(s => (
              <div key={s.id} className="flex items-center gap-2 py-1.5 border-b border-surface-600/40 last:border-0">
                <div className="w-6 h-6 rounded bg-surface-600 flex items-center justify-center
                                text-[10px] font-mono text-slate-400 flex-shrink-0">
                  {s.name[0]?.toUpperCase()}
                </div>
                <span className="text-xs font-mono text-slate-400 truncate">{s.name}</span>
              </div>
            ))}
            {!subjects?.length && <p className="text-xs text-slate-700 font-mono">No subjects added</p>}
          </div>
          <div className="card p-4">
            <div className="section-header"><FileText size={11} />Evidence ({evidence?.length ?? 0})</div>
            {evidence?.slice(0, 5).map(e => (
              <div key={e.id} className="py-1.5 border-b border-surface-600/40 last:border-0">
                <div className="text-xs font-mono text-slate-400 truncate">{e.title}</div>
                <div className="text-[10px] font-mono text-slate-600">{e.evidence_type}</div>
              </div>
            ))}
            {!evidence?.length && <p className="text-xs text-slate-700 font-mono">No evidence yet</p>}
          </div>
          <div className="card p-4">
            <div className="section-header"><Clock size={11} />Case Info</div>
            <div className="space-y-2 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-slate-600">Created</span>
                <span className="text-slate-400">{c.created_at && format(new Date(c.created_at), 'MMM d, yyyy')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Analyst</span>
                <span className="text-slate-400">{c.created_by?.username || '—'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Assigned</span>
                <span className="text-slate-400">{c.assigned_to?.username || '—'}</span>
              </div>
              {c.tags?.length > 0 && (
                <div className="pt-2">
                  {c.tags.map(t => (
                    <span key={t} className="text-[10px] bg-surface-600 text-slate-500 px-1.5 py-0.5 rounded mr-1">#{t}</span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── SUBJECTS TAB ── */}
      {activeTab === 'subjects' && (
        <div className="space-y-3">
          <div className="flex justify-end">
            <button onClick={() => setShowAddSubject(true)} className="btn-primary">
              <Plus size={13} />Add Subject
            </button>
          </div>
          {subjects?.length === 0 && (
            <div className="card p-10 text-center">
              <Users size={28} className="text-slate-700 mx-auto mb-2" />
              <p className="text-xs font-mono text-slate-600">No subjects added yet</p>
            </div>
          )}
          {subjects?.map(s => (
            <div key={s.id} className="card p-4 flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-surface-600 flex items-center justify-center
                              text-lg font-mono font-bold text-slate-400 flex-shrink-0">
                {s.name[0]?.toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-mono font-semibold text-slate-200">{s.name}</h3>
                {s.aliases?.length > 0 && (
                  <p className="text-xs font-mono text-slate-600 mt-0.5">Aliases: {s.aliases.join(', ')}</p>
                )}
                {s.emails?.length > 0 && (
                  <p className="text-xs font-mono text-blue-400 mt-0.5">✉ {s.emails.join(', ')}</p>
                )}
                {s.websites?.length > 0 && (
                  <div className="flex gap-2 mt-1">
                    {s.websites.map(w => (
                      <a key={w} href={w} target="_blank" rel="noreferrer"
                         className="text-xs font-mono text-brand hover:underline flex items-center gap-1">
                        <ExternalLink size={10} />{w.replace(/^https?:\/\//, '')}
                      </a>
                    ))}
                  </div>
                )}
                {s.description && <p className="text-xs text-slate-600 mt-1">{s.description}</p>}
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <Link to={`/username-search?case_id=${id}&subject_id=${s.id}`}
                      className="btn-icon text-purple-400 hover:text-purple-300" title="Search usernames">
                  <AtSign size={14} />
                </Link>
                <button onClick={() => deleteSubject.mutate(s.id)}
                        className="btn-icon text-red-500 hover:text-red-400" title="Remove">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── EVIDENCE TAB ── */}
      {activeTab === 'evidence' && (
        <div className="space-y-3">
          <div className="flex justify-end">
            <button onClick={() => setShowAddEvidence(true)} className="btn-primary">
              <Plus size={13} />Add Evidence
            </button>
          </div>
          {evidence?.length === 0 && (
            <div className="card p-10 text-center">
              <FileText size={28} className="text-slate-700 mx-auto mb-2" />
              <p className="text-xs font-mono text-slate-600">No evidence collected yet</p>
            </div>
          )}
          {evidence?.map(e => (
            <div key={e.id} className="card p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`badge badge-medium`}>{e.evidence_type}</span>
                    {e.is_sensitive && <span className="badge badge-high">SENSITIVE</span>}
                  </div>
                  <h3 className="text-sm font-mono text-slate-200">{e.title}</h3>
                  {e.description && <p className="text-xs text-slate-600 mt-1">{e.description}</p>}
                  {e.url && (
                    <a href={e.url} target="_blank" rel="noreferrer"
                       className="text-xs font-mono text-brand hover:underline flex items-center gap-1 mt-1">
                      <ExternalLink size={10} />{e.url}
                    </a>
                  )}
                  {e.tags?.length > 0 && (
                    <div className="flex gap-1 mt-2">
                      {e.tags.map(t => (
                        <span key={t} className="text-[10px] bg-surface-600 text-slate-500 px-1.5 py-0.5 rounded">#{t}</span>
                      ))}
                    </div>
                  )}
                </div>
                <button onClick={() => deleteEvidence.mutate(e.id)} className="btn-icon text-red-500">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── NOTES TAB ── */}
      {activeTab === 'notes' && (
        <div className="space-y-3">
          <div className="card p-3">
            <textarea
              className="input w-full resize-none mb-2"
              rows={3}
              placeholder="Add analyst note..."
              value={noteText}
              onChange={e => setNoteText(e.target.value)}
            />
            <button
              onClick={() => addNote.mutate()}
              disabled={!noteText.trim() || addNote.isPending}
              className="btn-primary"
            >
              <Edit3 size={13} />
              {addNote.isPending ? 'ADDING...' : 'Add Note'}
            </button>
          </div>
          {notes?.map(n => (
            <div key={n.id} className="card p-4">
              <p className="text-sm text-slate-300 whitespace-pre-wrap">{n.content}</p>
              <p className="text-[10px] font-mono text-slate-600 mt-2">
                {n.created_at && formatDistanceToNow(new Date(n.created_at), { addSuffix: true })}
              </p>
            </div>
          ))}
        </div>
      )}

      {/* ── TIMELINE TAB ── */}
      {activeTab === 'timeline' && (
        <div className="card p-4">
          <div className="section-header"><Clock size={11} />Investigation Timeline</div>
          {timeline?.events?.length === 0 && (
            <p className="text-xs font-mono text-slate-600 py-8 text-center">No timeline events</p>
          )}
          <div className="relative pl-6">
            <div className="absolute left-2 top-0 bottom-0 w-px bg-surface-600" />
            {timeline?.events?.map((event, i) => (
              <div key={i} className="relative mb-5 last:mb-0">
                <div className="absolute -left-4 top-1 w-2 h-2 rounded-full bg-brand/60
                                border border-brand/30" />
                <div className="text-xs font-mono text-brand">{event.icon} {event.title}</div>
                <div className="text-[10px] font-mono text-slate-600 mt-0.5">
                  {event.timestamp && format(new Date(event.timestamp), 'MMM d, yyyy HH:mm')}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {showAddSubject && <AddSubjectModal caseId={id} onClose={() => setShowAddSubject(false)} />}
      {showAddEvidence && <AddEvidenceModal caseId={id} onClose={() => setShowAddEvidence(false)} />}
    </div>
  )
}
