/**
 * OSINT Nexus - Cases List Page
 */
import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  FolderSearch, Plus, Search, Filter, ChevronRight,
  Clock, Shield, AlertTriangle
} from 'lucide-react'
import { casesAPI } from '../services/api'
import { formatDistanceToNow } from 'date-fns'
import toast from 'react-hot-toast'

const STATUS_OPTS = ['', 'open', 'active', 'on_hold', 'closed']
const PRIORITY_OPTS = ['', 'low', 'medium', 'high', 'critical']

const PRIORITY_ICONS = {
  critical: <AlertTriangle size={11} className="text-red-400" />,
  high:     <AlertTriangle size={11} className="text-amber-400" />,
  medium:   <Shield size={11} className="text-blue-400" />,
  low:      <Shield size={11} className="text-slate-500" />,
}

function CaseCard({ case: c }) {
  return (
    <Link
      to={`/cases/${c.id}`}
      className="card block p-4 hover:border-brand/30 hover:bg-surface-600/30
                 transition-all duration-150 group"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-mono text-slate-600">{c.case_number}</span>
            <span className={`badge badge-${c.status}`}>{c.status}</span>
            <span className={`badge badge-${c.priority}`}>
              <span className="flex items-center gap-1">
                {PRIORITY_ICONS[c.priority]}
                {c.priority}
              </span>
            </span>
          </div>
          <h3 className="font-mono font-semibold text-slate-200 text-sm group-hover:text-brand
                         transition-colors truncate">{c.title}</h3>
          {c.description && (
            <p className="text-xs text-slate-600 mt-1 line-clamp-1">{c.description}</p>
          )}
        </div>
        <ChevronRight size={14} className="text-slate-700 group-hover:text-brand mt-1 flex-shrink-0
                                           transition-colors" />
      </div>

      <div className="flex items-center gap-4 mt-3 pt-3 border-t border-surface-600/50">
        <div className="text-[10px] font-mono text-slate-600 flex items-center gap-1">
          <FolderSearch size={10} />
          {c.subjects_count ?? 0} subjects
        </div>
        <div className="text-[10px] font-mono text-slate-600">
          {c.username_searches_count ?? 0} searches
        </div>
        <div className="text-[10px] font-mono text-slate-600 ml-auto flex items-center gap-1">
          <Clock size={10} />
          {c.created_at && formatDistanceToNow(new Date(c.created_at), { addSuffix: true })}
        </div>
      </div>

      {c.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {c.tags.map((tag) => (
            <span key={tag} className="text-[10px] font-mono bg-surface-600 text-slate-500
                                       px-1.5 py-0.5 rounded">
              #{tag}
            </span>
          ))}
        </div>
      )}
    </Link>
  )
}

function CreateCaseModal({ onClose, onCreated }) {
  const [form, setForm] = useState({
    title: '', description: '', priority: 'medium', tags: ''
  })
  const qc = useQueryClient()

  const mutation = useMutation({
    mutationFn: (data) => casesAPI.create(data).then(r => r.data),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['cases'] })
      toast.success(`Case ${data.case_number} created`)
      onCreated(data)
    },
    onError: (e) => toast.error(e.response?.data?.detail || 'Failed to create case'),
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    mutation.mutate({
      ...form,
      tags: form.tags ? form.tags.split(',').map(t => t.trim()).filter(Boolean) : [],
    })
  }

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="card-elevated w-full max-w-md p-5 animate-fade-in">
        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-surface-600">
          <Plus size={14} className="text-brand" />
          <h2 className="text-sm font-mono font-semibold text-slate-200 tracking-wider">
            New Investigation Case
          </h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="input-label">Case Title *</label>
            <input
              type="text"
              className="input"
              placeholder="Social Media Fraud Investigation"
              value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })}
              required
              minLength={3}
              autoFocus
            />
          </div>
          <div>
            <label className="input-label">Description</label>
            <textarea
              className="input resize-none"
              rows={3}
              placeholder="Brief summary of the investigation..."
              value={form.description}
              onChange={e => setForm({ ...form, description: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="input-label">Priority</label>
              <select
                className="input"
                value={form.priority}
                onChange={e => setForm({ ...form, priority: e.target.value })}
              >
                {['low', 'medium', 'high', 'critical'].map(p => (
                  <option key={p} value={p}>{p.toUpperCase()}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="input-label">Tags (comma separated)</label>
              <input
                type="text"
                className="input"
                placeholder="fraud, social, account"
                value={form.tags}
                onChange={e => setForm({ ...form, tags: e.target.value })}
              />
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <button type="submit" disabled={mutation.isPending} className="btn-primary flex-1 justify-center">
              {mutation.isPending ? 'CREATING...' : 'CREATE CASE'}
            </button>
            <button type="button" onClick={onClose} className="btn-secondary px-4">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default function CasesPage() {
  const [showModal, setShowModal] = useState(false)
  const [filters, setFilters] = useState({ status: '', priority: '', search: '' })

  const { data: cases, isLoading } = useQuery({
    queryKey: ['cases', filters],
    queryFn: () => casesAPI.list(filters).then(r => r.data),
  })

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-mono font-bold text-slate-200 tracking-wider">
            Investigation Cases
          </h1>
          <p className="text-xs font-mono text-slate-600 mt-0.5">
            {cases?.length ?? 0} case{cases?.length !== 1 ? 's' : ''} on record
          </p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn-primary">
          <Plus size={14} />
          New Case
        </button>
      </div>

      {/* Filters */}
      <div className="card p-3 flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-48">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-600" />
          <input
            type="text"
            className="input pl-8 h-8 text-xs"
            placeholder="Search cases..."
            value={filters.search}
            onChange={e => setFilters({ ...filters, search: e.target.value })}
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter size={12} className="text-slate-600" />
          <select
            className="input h-8 text-xs w-28"
            value={filters.status}
            onChange={e => setFilters({ ...filters, status: e.target.value })}
          >
            {STATUS_OPTS.map(s => (
              <option key={s} value={s}>{s ? s.toUpperCase() : 'All Status'}</option>
            ))}
          </select>
          <select
            className="input h-8 text-xs w-32"
            value={filters.priority}
            onChange={e => setFilters({ ...filters, priority: e.target.value })}
          >
            {PRIORITY_OPTS.map(p => (
              <option key={p} value={p}>{p ? p.toUpperCase() : 'All Priority'}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Cases list */}
      {isLoading ? (
        <div className="space-y-3">
          {Array(4).fill(0).map((_, i) => (
            <div key={i} className="card p-4"><div className="skeleton h-16 rounded" /></div>
          ))}
        </div>
      ) : cases?.length === 0 ? (
        <div className="card p-12 text-center">
          <FolderSearch size={32} className="text-slate-700 mx-auto mb-3" />
          <p className="text-sm font-mono text-slate-600">No cases found</p>
          <p className="text-xs font-mono text-slate-700 mt-1">
            Create your first investigation case to get started
          </p>
          <button onClick={() => setShowModal(true)} className="btn-primary mt-4 mx-auto">
            <Plus size={14} /> Create First Case
          </button>
        </div>
      ) : (
        <div className="grid gap-3">
          {cases?.map(c => <CaseCard key={c.id} case={c} />)}
        </div>
      )}

      {showModal && (
        <CreateCaseModal
          onClose={() => setShowModal(false)}
          onCreated={(c) => {
            setShowModal(false)
            window.location.href = `/cases/${c.id}`
          }}
        />
      )}
    </div>
  )
}
