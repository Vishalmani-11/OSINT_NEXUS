/**
 * OSINT Nexus - Dashboard Page
 * Real-time stats widgets, investigation timeline chart, platform distribution, and activity feed.
 */
import React from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer
} from 'recharts'
import {
  FolderSearch, AtSign, ScanFace, Shield, FileText,
  Users, Activity, Clock, TrendingUp
} from 'lucide-react'
import { dashboardAPI } from '../services/api'
import { formatDistanceToNow } from 'date-fns'

// ── Chart colours ─────────────────────────────────────────────────
const CHART_COLORS = ['#00ff88', '#60a5fa', '#a78bfa', '#f59e0b', '#f87171', '#34d399']

// ── Custom Tooltip ────────────────────────────────────────────────
const ChartTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-surface-800 border border-surface-500 rounded p-2 text-xs font-mono">
      <p className="text-slate-400 mb-1">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }}>{p.name}: {p.value}</p>
      ))}
    </div>
  )
}

// ── Stat Card ─────────────────────────────────────────────────────
function StatCard({ label, value, icon: Icon, color = 'text-brand', sub }) {
  return (
    <div className="stat-card group hover:border-brand/30 transition-colors">
      <div className="flex items-start justify-between">
        <div className={`stat-value ${color}`}>{value ?? '—'}</div>
        <div className="p-1.5 bg-surface-800 rounded border border-surface-600
                        group-hover:border-brand/20 transition-colors">
          <Icon size={15} className={color} />
        </div>
      </div>
      <div className="stat-label">{label}</div>
      {sub && <div className="stat-sub">{sub}</div>}
    </div>
  )
}

// ── Activity Row ──────────────────────────────────────────────────
function ActivityRow({ item }) {
  const actionColors = {
    login: 'text-blue-400', create: 'text-brand', search: 'text-purple-400',
    upload: 'text-amber-400', generate: 'text-orange-400', delete: 'text-red-400',
  }
  return (
    <div className="flex items-start gap-3 py-2 border-b border-surface-600/50 last:border-0">
      <div className={`text-xs font-mono mt-0.5 w-16 flex-shrink-0 ${actionColors[item.action] || 'text-slate-500'}`}>
        [{item.action?.toUpperCase()}]
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-xs font-mono text-slate-400 truncate">
          {item.resource_type && <span className="text-slate-600">{item.resource_type} › </span>}
          {item.details?.title || item.details?.type || item.action}
        </div>
        <div className="text-[10px] font-mono text-slate-600 mt-0.5">
          {item.user_username && <span>{item.user_username} · </span>}
          {item.created_at && formatDistanceToNow(new Date(item.created_at), { addSuffix: true })}
        </div>
      </div>
    </div>
  )
}

export default function DashboardPage() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: () => dashboardAPI.getStats().then(r => r.data),
    refetchInterval: 30_000,
  })

  const { data: activity } = useQuery({
    queryKey: ['dashboard-activity'],
    queryFn: () => dashboardAPI.getActivity(20).then(r => r.data),
    refetchInterval: 15_000,
  })

  const { data: platforms } = useQuery({
    queryKey: ['platform-distribution'],
    queryFn: () => dashboardAPI.getPlatformDistribution().then(r => r.data),
  })

  const { data: timeline } = useQuery({
    queryKey: ['investigation-timeline'],
    queryFn: () => dashboardAPI.getTimeline(14).then(r => r.data),
  })

  const Sk = ({ w = 'w-full', h = 'h-8' }) => (
    <div className={`skeleton ${w} ${h} rounded`} />
  )

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-mono font-bold text-slate-200 tracking-wider">
            Intelligence Overview
          </h1>
          <p className="text-xs font-mono text-slate-600 mt-0.5">
            Real-time summary of all OSINT operations
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono text-slate-600">
          <Activity size={11} className="text-brand animate-pulse" />
          LIVE FEED
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3">
        {statsLoading ? (
          Array(5).fill(0).map((_, i) => <div key={i} className="stat-card"><Sk h="h-20" /></div>)
        ) : (
          <>
            <StatCard label="Total Cases"       value={stats?.total_cases}       icon={FolderSearch} />
            <StatCard label="Active Cases"      value={stats?.active_cases}      icon={Shield}       color="text-blue-400" />
            <StatCard label="Username Searches" value={stats?.username_searches}  icon={AtSign}       color="text-purple-400" />
            <StatCard label="Face Analyses"     value={stats?.image_searches}    icon={ScanFace}     color="text-amber-400" />
            <StatCard label="Reports"           value={stats?.reports_generated}  icon={FileText}     color="text-orange-400" />
          </>
        )}
      </div>

      {/* Second row stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {statsLoading ? (
          Array(4).fill(0).map((_, i) => <div key={i} className="stat-card"><Sk h="h-16" /></div>)
        ) : (
          <>
            <StatCard label="Subjects"        value={stats?.total_subjects}     icon={Users}       color="text-cyan-400" sub="investigated" />
            <StatCard label="Username Hits"   value={stats?.username_matches}   icon={TrendingUp}  color="text-brand"  sub="profiles found" />
            <StatCard label="Face Matches"    value={stats?.image_results}       icon={ScanFace}    color="text-green-400" sub="similarity hits" />
            <StatCard label="Evidence Items"  value={stats?.evidence_items}     icon={Clock}       color="text-indigo-400" sub="collected" />
          </>
        )}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Timeline chart */}
        <div className="card p-4 lg:col-span-2">
          <div className="section-header">
            <TrendingUp size={12} />
            Investigation Activity (14 days)
          </div>
          {timeline?.length > 0 ? (
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={timeline} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorInv" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00ff88" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#00ff88" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorSearch" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#60a5fa" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#60a5fa" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" tick={{ fill: '#475569', fontSize: 10, fontFamily: 'monospace' }} />
                <YAxis tick={{ fill: '#475569', fontSize: 10, fontFamily: 'monospace' }} />
                <Tooltip content={<ChartTooltip />} />
                <Area type="monotone" dataKey="investigations" name="Cases" stroke="#00ff88" fill="url(#colorInv)" strokeWidth={2} />
                <Area type="monotone" dataKey="username_searches" name="Searches" stroke="#60a5fa" fill="url(#colorSearch)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-44 flex items-center justify-center text-xs font-mono text-slate-600">
              No activity data yet — start an investigation
            </div>
          )}
        </div>

        {/* Platform distribution */}
        <div className="card p-4">
          <div className="section-header">
            <AtSign size={12} />
            Platform Distribution
          </div>
          {platforms?.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={140}>
                <PieChart>
                  <Pie
                    data={platforms.slice(0, 6)}
                    cx="50%" cy="50%"
                    innerRadius={35} outerRadius={60}
                    dataKey="count"
                    nameKey="platform"
                  >
                    {platforms.slice(0, 6).map((_, i) => (
                      <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip content={<ChartTooltip />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1 mt-2">
                {platforms.slice(0, 5).map((p, i) => (
                  <div key={p.platform} className="flex items-center justify-between text-xs font-mono">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-sm flex-shrink-0"
                           style={{ background: CHART_COLORS[i % CHART_COLORS.length] }} />
                      <span className="text-slate-400">{p.platform}</span>
                    </div>
                    <span className="text-slate-600">{p.count}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="h-44 flex items-center justify-center text-xs font-mono text-slate-600">
              Run username searches to see platform data
            </div>
          )}
        </div>
      </div>

      {/* Activity Feed */}
      <div className="card p-4">
        <div className="section-header">
          <Activity size={12} />
          Recent Activity
        </div>
        {activity?.length > 0 ? (
          <div className="max-h-64 overflow-y-auto">
            {activity.map((item) => (
              <ActivityRow key={item.id} item={item} />
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-xs font-mono text-slate-600">
            No recent activity — create a case to get started
          </div>
        )}
      </div>
    </div>
  )
}
