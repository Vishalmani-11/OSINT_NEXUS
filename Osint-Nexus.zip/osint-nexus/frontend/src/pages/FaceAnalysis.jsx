/**
 * OSINT Nexus - Face Analysis Page
 * Local face detection, embedding generation, and similarity search.
 * All processing is server-side only — no external APIs.
 */
import React, { useState, useCallback } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useDropzone } from 'react-dropzone'
import {
  Globe, Upload, CheckCircle, AlertCircle,
  Loader, Image, Target, Sliders, Info
} from 'lucide-react'
import { facesAPI, casesAPI } from '../services/api'
import { formatDistanceToNow } from 'date-fns'
import toast from 'react-hot-toast'

// ── Face embedding card ───────────────────────────────────────────
function EmbeddingCard({ embed, onSearch }) {
  const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'
  return (
    <div className="card p-3 flex items-start gap-3">
      <div className="w-14 h-14 rounded-md bg-surface-800 border border-surface-600
                      flex items-center justify-center flex-shrink-0 overflow-hidden">
        {embed.thumbnail_path ? (
          <img
            src={`${API}/uploads/faces/thumbnails/${embed.thumbnail_path?.split('/').pop()}`}
            alt="face"
            className="w-full h-full object-cover"
            onError={e => { e.target.style.display = 'none' }}
          />
        ) : (
          <ScanFace size={20} className="text-slate-600" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-xs font-mono text-slate-400 truncate">{embed.image_filename}</div>
        <div className="flex flex-wrap gap-2 mt-1">
          {embed.face_count > 0 ? (
            <span className="badge badge-found">{embed.face_count} face{embed.face_count > 1 ? 's' : ''}</span>
          ) : (
            <span className="badge badge-error">no face</span>
          )}
          {embed.confidence && (
            <span className="text-[10px] font-mono text-slate-600">
              conf: {(embed.confidence * 100).toFixed(0)}%
            </span>
          )}
          {embed.estimated_age && (
            <span className="text-[10px] font-mono text-slate-600">age≈{embed.estimated_age}</span>
          )}
          {embed.estimated_gender && (
            <span className="text-[10px] font-mono text-slate-600">{embed.estimated_gender}</span>
          )}
        </div>
        <div className="text-[10px] font-mono text-slate-700 mt-1">
          {embed.created_at && formatDistanceToNow(new Date(embed.created_at), { addSuffix: true })}
        </div>
      </div>
      <button
        onClick={() => onSearch(embed.id)}
        disabled={!embed.face_count}
        className="btn-secondary text-xs flex-shrink-0"
        title="Search for similar faces"
      >
        <Target size={12} /> Search
      </button>
    </div>
  )
}

// ── Match result ──────────────────────────────────────────────────
function MatchCard({ match }) {
  const score = Math.round(match.similarity_score * 100)
  const color = score >= 80 ? 'text-brand' : score >= 65 ? 'text-amber-400' : 'text-slate-500'
  return (
    <div className="card p-3 flex items-center gap-3">
      <div className="relative flex-shrink-0">
        <div className="w-12 h-12 rounded-md bg-surface-800 border border-surface-600
                        flex items-center justify-center">
          <ScanFace size={18} className="text-slate-600" />
        </div>
        <div className={`absolute -bottom-1 -right-1 text-xs font-mono font-bold
                         bg-surface-800 border border-surface-600 rounded px-1 ${color}`}>
          {score}%
        </div>
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-xs font-mono text-slate-300 truncate">{match.image_filename}</div>
        {match.subject_name && (
          <div className="text-[10px] font-mono text-blue-400">Subject: {match.subject_name}</div>
        )}
        <div className={`text-xs font-mono font-semibold ${color} mt-0.5`}>
          {score >= 80 ? '● HIGH confidence match' :
           score >= 65 ? '◐ MEDIUM confidence match' :
           '○ LOW confidence match'}
        </div>
      </div>
      <div className="text-right flex-shrink-0">
        <div className={`text-2xl font-mono font-bold ${color}`}>{score}%</div>
        <div className="text-[10px] font-mono text-slate-700">similarity</div>
      </div>
    </div>
  )
}

// ── Upload dropzone ───────────────────────────────────────────────
function UploadZone({ onUpload, isLoading }) {
  const onDrop = useCallback((accepted) => {
    if (accepted[0]) onUpload(accepted[0])
  }, [onUpload])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': ['.jpg', '.jpeg', '.png', '.webp', '.bmp'] },
    maxFiles: 1,
    disabled: isLoading,
  })

  return (
    <div
      {...getRootProps()}
      className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer
                  transition-all duration-200
                  ${isDragActive
                    ? 'border-brand bg-brand/5 shadow-[0_0_20px_rgba(0,255,136,0.1)]'
                    : 'border-surface-500 hover:border-brand/50 hover:bg-surface-800/50'}`}
    >
      <input {...getInputProps()} />
      {isLoading ? (
        <div className="flex flex-col items-center gap-3">
          <Loader size={28} className="text-brand animate-spin" />
          <p className="text-xs font-mono text-slate-500">Processing image...</p>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3">
          <Upload size={28} className={isDragActive ? 'text-brand' : 'text-slate-600'} />
          <div>
            <p className="text-sm font-mono text-slate-400">
              {isDragActive ? 'Drop the image here' : 'Drag & drop an image, or click to select'}
            </p>
            <p className="text-xs font-mono text-slate-700 mt-1">
              JPG, PNG, WEBP, BMP — max 10MB
            </p>
          </div>
        </div>
      )}
    </div>
  )
}

// ── Main Page ─────────────────────────────────────────────────────
export default function FaceAnalysisPage() {
  const [searchParams] = useSearchParams()
  const [caseId, setCaseId]       = useState(searchParams.get('case_id') || '')
  const [subjectId, setSubjectId] = useState('')
  const [threshold, setThreshold] = useState(0.6)
  const [searchResults, setSearchResults] = useState(null)
  const [lastUpload, setLastUpload] = useState(null)
  const qc = useQueryClient()

  const { data: cases } = useQuery({
    queryKey: ['cases-list-simple'],
    queryFn: () => casesAPI.list({}).then(r => r.data),
  })
  const { data: subjects } = useQuery({
    queryKey: ['subjects-for-case', caseId],
    queryFn: () => casesAPI.listSubjects(caseId).then(r => r.data),
    enabled: !!caseId,
  })
  const { data: embeddings, isLoading: embedsLoading } = useQuery({
    queryKey: ['face-embeddings', caseId],
    queryFn: () => facesAPI.listCase(caseId).then(r => r.data),
    enabled: !!caseId,
    refetchInterval: 5000,
  })

  const uploadMutation = useMutation({
    mutationFn: async (file) => {
      if (!caseId) throw new Error('Select a case first')
      const form = new FormData()
      form.append('file', file)
      form.append('case_id', caseId)
      if (subjectId) form.append('subject_id', subjectId)
      return facesAPI.upload(form).then(r => r.data)
    },
    onSuccess: (data) => {
      setLastUpload(data)
      qc.invalidateQueries({ queryKey: ['face-embeddings', caseId] })
      toast.success(`Image uploaded — face analysis running (${data.message})`)
    },
    onError: (e) => toast.error(e.response?.data?.detail || e.message || 'Upload failed'),
  })

  const searchMutation = useMutation({
    mutationFn: (embId) => facesAPI.search({
      embedding_id: embId,
      case_id: caseId ? parseInt(caseId) : null,
      threshold,
    }).then(r => r.data),
    onSuccess: (data) => {
      setSearchResults(data)
      toast.success(`Found ${data.matches_found} match${data.matches_found !== 1 ? 'es' : ''}`)
    },
    onError: (e) => toast.error(e.response?.data?.detail || 'Search failed'),
  })

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-lg font-mono font-bold text-slate-200 tracking-wider">Face Analysis</h1>
        <p className="text-xs font-mono text-slate-600 mt-0.5">
          Local face detection and similarity search — no external databases used
        </p>
      </div>

      {/* Privacy notice */}
      <div className="bg-emerald-900/20 border border-emerald-900/40 rounded-md p-3 flex gap-2">
        <Info size={14} className="text-brand flex-shrink-0 mt-0.5" />
        <p className="text-xs font-mono text-brand/80">
          All face processing happens locally on this server using InsightFace / OpenCV.
          Face embeddings are stored only in the local PostgreSQL database and are never
          shared with external services or third-party APIs.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Upload panel */}
        <div className="space-y-4">
          <div className="card p-4">
            <div className="section-header"><Upload size={12} />Upload Image</div>

            <div className="space-y-3 mb-4">
              <div>
                <label className="input-label">Case *</label>
                <select className="input" value={caseId}
                  onChange={e => { setCaseId(e.target.value); setSubjectId('') }} required>
                  <option value="">Select a case...</option>
                  {cases?.map(c => (
                    <option key={c.id} value={c.id}>{c.case_number} — {c.title}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="input-label">Assign to Subject (optional)</label>
                <select className="input" value={subjectId} onChange={e => setSubjectId(e.target.value)}>
                  <option value="">None</option>
                  {subjects?.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
            </div>

            <UploadZone
              onUpload={(file) => uploadMutation.mutate(file)}
              isLoading={uploadMutation.isPending}
            />

            {/* Upload result */}
            {lastUpload && (
              <div className="mt-3 bg-surface-800 border border-surface-600 rounded-md p-3">
                <div className="flex items-start gap-2">
                  {lastUpload.face_count > 0
                    ? <CheckCircle size={14} className="text-brand mt-0.5 flex-shrink-0" />
                    : <AlertCircle size={14} className="text-amber-400 mt-0.5 flex-shrink-0" />
                  }
                  <div>
                    <p className="text-xs font-mono text-slate-300">{lastUpload.message}</p>
                    <p className="text-[10px] font-mono text-slate-600 mt-1">
                      ID: {lastUpload.embedding_id} · Faces detected: {lastUpload.face_count}
                    </p>
                    {lastUpload.face_count === 0 && (
                      <p className="text-[10px] font-mono text-amber-500 mt-1">
                        ⚠ No face detected — similarity search won&apos;t be available
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Search settings */}
          <div className="card p-4">
            <div className="section-header"><Sliders size={12} />Similarity Threshold</div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-slate-500">Threshold</span>
                <span className="text-sm font-mono font-bold text-brand">
                  {Math.round(threshold * 100)}%
                </span>
              </div>
              <input
                type="range" min="0.4" max="0.95" step="0.05"
                value={threshold}
                onChange={e => setThreshold(parseFloat(e.target.value))}
                className="w-full accent-brand"
              />
              <div className="flex justify-between text-[10px] font-mono text-slate-700">
                <span>Permissive (40%)</span>
                <span>Strict (95%)</span>
              </div>
              <p className="text-[10px] font-mono text-slate-600">
                Recommended: 60%+ for likely match, 80%+ for high confidence.
                Results above {Math.round(threshold * 100)}% will be shown.
              </p>
            </div>
          </div>
        </div>

        {/* Right panel: embeddings & results */}
        <div className="space-y-4">
          {/* Stored embeddings */}
          <div className="card p-4">
            <div className="section-header">
              <Image size={12} />
              Case Images ({embeddings?.length ?? 0})
            </div>
            {!caseId ? (
              <p className="text-xs font-mono text-slate-700 py-4 text-center">Select a case to view images</p>
            ) : embedsLoading ? (
              <div className="space-y-2">
                {[1,2,3].map(i => <div key={i} className="skeleton h-16 rounded" />)}
              </div>
            ) : embeddings?.length === 0 ? (
              <div className="py-8 text-center">
                <ScanFace size={24} className="text-slate-700 mx-auto mb-2" />
                <p className="text-xs font-mono text-slate-700">No images uploaded for this case</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {embeddings.map(e => (
                  <EmbeddingCard
                    key={e.id}
                    embed={e}
                    onSearch={(id) => searchMutation.mutate(id)}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Search results */}
          {(searchMutation.isPending || searchResults) && (
            <div className="card p-4">
              <div className="section-header"><Target size={12} />Search Results</div>

              {searchMutation.isPending ? (
                <div className="py-8 text-center">
                  <Loader size={20} className="text-brand animate-spin mx-auto mb-2" />
                  <p className="text-xs font-mono text-slate-600">Comparing face embeddings...</p>
                </div>
              ) : searchResults && (
                <>
                  <div className="flex items-center gap-4 mb-3 text-xs font-mono">
                    <span className="text-slate-600">
                      Searched: <span className="text-slate-400">{searchResults.total_searched}</span>
                    </span>
                    <span className="text-slate-600">
                      Matches: <span className="text-brand font-bold">{searchResults.matches_found}</span>
                    </span>
                    <span className="text-slate-600">
                      Time: <span className="text-slate-400">{searchResults.search_duration_ms}ms</span>
                    </span>
                  </div>

                  {searchResults.matches_found === 0 ? (
                    <div className="py-6 text-center">
                      <p className="text-xs font-mono text-slate-600">
                        No matches above {Math.round(threshold * 100)}% threshold
                      </p>
                      <p className="text-[10px] font-mono text-slate-700 mt-1">
                        Try lowering the threshold or uploading more reference images
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {searchResults.matches.map((m, i) => (
                        <MatchCard key={i} match={m} />
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
