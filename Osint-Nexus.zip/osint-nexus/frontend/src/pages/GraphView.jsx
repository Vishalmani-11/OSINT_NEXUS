/**
 * OSINT Nexus - Graph Intelligence View
 * Interactive Neo4j relationship graph using ReactFlow.
 * Nodes: Person, Username, SocialProfile, Email, Website, Image
 */
import React, { useState, useCallback, useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import ReactFlow, {
  MiniMap, Controls, Background, BackgroundVariant,
  useNodesState, useEdgesState, MarkerType,
  Panel
} from 'reactflow'
import 'reactflow/dist/style.css'
import { Share2, Download, RefreshCw, Info, Camera } from 'lucide-react'
import { graphAPI, casesAPI } from '../services/api'
import toast from 'react-hot-toast'

// ── Node colour map ───────────────────────────────────────────────
const NODE_STYLES = {
  person:        { bg: '#00ff88', border: '#00cc6a', text: '#0a0f1a' },
  username:      { bg: '#60a5fa', border: '#3b82f6', text: '#0a0f1a' },
  socialprofile: { bg: '#a78bfa', border: '#7c3aed', text: '#0a0f1a' },
  email:         { bg: '#f59e0b', border: '#d97706', text: '#0a0f1a' },
  website:       { bg: '#f87171', border: '#dc2626', text: '#0a0f1a' },
  image:         { bg: '#34d399', border: '#059669', text: '#0a0f1a' },
  default:       { bg: '#334155', border: '#475569', text: '#e2e8f0' },
}

const NODE_ICONS = {
  person:        '👤',
  username:      '@',
  socialprofile: '🔗',
  email:         '✉',
  website:       '🌐',
  image:         '📷',
  default:       '◆',
}

// ── Convert API graph data → ReactFlow format ─────────────────────
function toReactFlow(apiData) {
  const nodes = apiData.nodes.map((n, i) => {
    const style = NODE_STYLES[n.type?.toLowerCase()] || NODE_STYLES.default
    const cols  = Math.ceil(Math.sqrt(apiData.nodes.length))
    const row   = Math.floor(i / cols)
    const col   = i % cols

    return {
      id:       n.id,
      type:     'default',
      position: n.x != null
        ? { x: n.x, y: n.y }
        : { x: col * 220 + (row % 2 === 0 ? 0 : 110), y: row * 140 },
      data:     {
        label: (
          <div className="text-center">
            <div className="text-base mb-0.5">{NODE_ICONS[n.type?.toLowerCase()] || '◆'}</div>
            <div className="text-[11px] font-mono font-bold leading-tight max-w-[100px] break-words">
              {n.label?.slice(0, 30)}
            </div>
            <div className="text-[9px] font-mono opacity-60 mt-0.5 uppercase">{n.type}</div>
          </div>
        ),
      },
      style: {
        background: style.bg,
        border: `2px solid ${style.border}`,
        borderRadius: '10px',
        color: style.text,
        width: 120,
        padding: '8px 4px',
        boxShadow: `0 0 12px ${style.border}40`,
      },
    }
  })

  const edges = apiData.edges.map((e) => ({
    id:           e.id,
    source:       e.source,
    target:       e.target,
    label:        e.label,
    type:         'smoothstep',
    animated:     e.label?.includes('USERNAME') || e.label?.includes('PROFILE'),
    markerEnd:    { type: MarkerType.ArrowClosed, color: '#334155', width: 15, height: 15 },
    labelStyle:   { fill: '#64748b', fontSize: 9, fontFamily: 'monospace' },
    labelBgStyle: { fill: '#0d1b2a', fillOpacity: 0.9 },
    style:        { stroke: '#334155', strokeWidth: 1.5 },
  }))

  return { nodes, edges }
}

// ── Node legend item ──────────────────────────────────────────────
function LegendItem({ type }) {
  const style = NODE_STYLES[type] || NODE_STYLES.default
  return (
    <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-500">
      <div className="w-3 h-3 rounded-sm flex-shrink-0"
           style={{ background: style.bg, border: `1px solid ${style.border}` }} />
      <span className="capitalize">{type}</span>
    </div>
  )
}

// ── Main Page ─────────────────────────────────────────────────────
export default function GraphViewPage() {
  const [caseId, setCaseId] = useState('')
  const [maxDepth, setMaxDepth] = useState(3)
  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])

  const { data: cases } = useQuery({
    queryKey: ['cases-list-simple'],
    queryFn: () => casesAPI.list({}).then(r => r.data),
  })

  const { data: graphData, isLoading, refetch } = useQuery({
    queryKey: ['graph', caseId, maxDepth],
    queryFn: () => graphAPI.getCaseGraph(caseId, { max_depth: maxDepth }).then(r => r.data),
    enabled: !!caseId,
  })

  useEffect(() => {
    if (graphData) {
      const { nodes: n, edges: e } = toReactFlow(graphData)
      setNodes(n)
      setEdges(e)
    }
  }, [graphData])

  const exportPNG = useCallback(() => {
    toast('Screenshot: use your OS screenshot tool (Cmd+Shift+4 / Win+Shift+S)', { icon: '📷' })
  }, [])

  const exportJSON = useCallback(() => {
    if (!graphData) return
    const blob = new Blob([JSON.stringify(graphData, null, 2)], { type: 'application/json' })
    const url  = URL.createObjectURL(blob)
    const a    = document.createElement('a'); a.href = url; a.download = `graph_case_${caseId}.json`; a.click()
    URL.revokeObjectURL(url)
  }, [graphData, caseId])

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-mono font-bold text-slate-200 tracking-wider">Graph Intelligence</h1>
          <p className="text-xs font-mono text-slate-600 mt-0.5">
            Neo4j relationship graph — persons, usernames, profiles, emails, websites
          </p>
        </div>
        <div className="flex gap-2">
          {graphData && (
            <>
              <button onClick={exportJSON} className="btn-secondary text-xs">
                <Download size={12} /> Export JSON
              </button>
              <button onClick={exportPNG} className="btn-ghost text-xs">
                <Camera size={12} /> Screenshot
              </button>
              <button onClick={() => refetch()} className="btn-ghost text-xs">
                <RefreshCw size={12} />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="card p-3 flex flex-wrap gap-3 items-end">
        <div className="flex-1 min-w-48">
          <label className="input-label">Case</label>
          <select className="input h-8 text-xs" value={caseId} onChange={e => setCaseId(e.target.value)}>
            <option value="">Select a case...</option>
            {cases?.map(c => <option key={c.id} value={c.id}>{c.case_number} — {c.title}</option>)}
          </select>
        </div>
        <div>
          <label className="input-label">Max Depth: {maxDepth}</label>
          <input type="range" min={1} max={5} value={maxDepth} className="accent-brand"
            onChange={e => setMaxDepth(parseInt(e.target.value))} />
        </div>
        {graphData && (
          <div className="text-xs font-mono text-slate-600">
            {graphData.node_count} nodes · {graphData.edge_count} edges
          </div>
        )}
      </div>

      {/* Graph Canvas */}
      <div className="card overflow-hidden" style={{ height: '65vh' }}>
        {!caseId ? (
          <div className="h-full flex items-center justify-center flex-col gap-3">
            <Share2 size={40} className="text-slate-700" />
            <p className="text-xs font-mono text-slate-600">Select a case to view its relationship graph</p>
          </div>
        ) : isLoading ? (
          <div className="h-full flex items-center justify-center flex-col gap-3">
            <div className="w-6 h-6 border-2 border-brand border-t-transparent rounded-full animate-spin" />
            <p className="text-xs font-mono text-slate-600">Loading graph from Neo4j...</p>
          </div>
        ) : nodes.length === 0 ? (
          <div className="h-full flex items-center justify-center flex-col gap-3">
            <Share2 size={40} className="text-slate-700" />
            <p className="text-xs font-mono text-slate-600">No graph data yet</p>
            <p className="text-[10px] font-mono text-slate-700">
              Add subjects and run searches to build the graph
            </p>
            <div className="bg-blue-900/20 border border-blue-900/40 rounded-md p-3 max-w-sm">
              <div className="flex gap-2">
                <Info size={13} className="text-blue-400 flex-shrink-0 mt-0.5" />
                <p className="text-[10px] font-mono text-blue-400/80">
                  If Neo4j is not running, a demo graph is shown. Start Neo4j via Docker Compose
                  for real graph capabilities.
                </p>
              </div>
            </div>
          </div>
        ) : (
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            fitView
            fitViewOptions={{ padding: 0.2 }}
            attributionPosition="bottom-right"
          >
            <Background variant={BackgroundVariant.Dots} color="#1e3a5c" gap={20} />
            <Controls />
            <MiniMap
              nodeColor={(n) => {
                const type = n.data?.label?.props?.children?.[1]?.props?.children?.toLowerCase()
                return NODE_STYLES[type]?.bg || '#334155'
              }}
              maskColor="rgba(10,15,26,0.8)"
            />
            <Panel position="top-left">
              <div className="card p-2 space-y-1">
                <div className="text-[10px] font-mono text-slate-600 uppercase tracking-wider mb-1">Legend</div>
                {Object.keys(NODE_STYLES).filter(k => k !== 'default').map(type => (
                  <LegendItem key={type} type={type} />
                ))}
              </div>
            </Panel>
          </ReactFlow>
        )}
      </div>
    </div>
  )
}
