/**
 * OSINT Nexus - Login Page
 */
import React, { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { Shield, Eye, EyeOff, Terminal } from 'lucide-react'
import useAuthStore from '../store/authStore'
import toast from 'react-hot-toast'

export default function LoginPage() {
  const [form, setForm] = useState({ username: '', password: '' })
  const [showPass, setShowPass] = useState(false)
  const { login, isLoading } = useAuthStore()
  const navigate = useNavigate()
  const location = useLocation()
  const from = location.state?.from?.pathname || '/'

  const handleSubmit = async (e) => {
    e.preventDefault()
    const result = await login(form)
    if (result.success) {
      toast.success('Access granted')
      navigate(from, { replace: true })
    } else {
      toast.error(result.error || 'Authentication failed')
    }
  }

  return (
    <div className="min-h-screen bg-surface-900 flex items-center justify-center p-4">
      {/* Background grid */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,136,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,136,0.02)_1px,transparent_1px)]
                      bg-[size:60px_60px] pointer-events-none" />

      <div className="w-full max-w-sm relative">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl
                          bg-brand/10 border border-brand/30 mb-4
                          shadow-[0_0_30px_rgba(0,255,136,0.15)]">
            <Shield size={28} className="text-brand" />
          </div>
          <h1 className="text-2xl font-mono font-bold text-brand tracking-widest">OSINT NEXUS</h1>
          <p className="text-xs font-mono text-slate-600 mt-1 tracking-widest">
            INTELLIGENCE PLATFORM // v1.0
          </p>
        </div>

        {/* Form Card */}
        <div className="card-elevated p-6">
          <div className="flex items-center gap-2 mb-5 pb-3 border-b border-surface-600">
            <Terminal size={13} className="text-brand" />
            <span className="text-xs font-mono text-slate-500 uppercase tracking-widest">
              Authentication Required
            </span>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="input-label">Username or Email</label>
              <input
                type="text"
                className="input"
                placeholder="analyst@osint.local"
                value={form.username}
                onChange={(e) => setForm({ ...form, username: e.target.value })}
                required
                autoFocus
              />
            </div>

            <div>
              <label className="input-label">Password</label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  className="input pr-10"
                  placeholder="••••••••••••"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-600
                             hover:text-slate-400 transition-colors"
                >
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary w-full justify-center mt-2"
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <span className="w-3 h-3 border-2 border-surface-900/40 border-t-surface-900
                                   rounded-full animate-spin" />
                  AUTHENTICATING...
                </span>
              ) : 'AUTHENTICATE'}
            </button>
          </form>

          <p className="text-center text-xs font-mono text-slate-600 mt-5">
            No account?{' '}
            <Link to="/register" className="text-brand hover:text-brand-dim transition-colors">
              Register access
            </Link>
          </p>
        </div>

        <p className="text-center text-[10px] font-mono text-slate-700 mt-5">
          FOR AUTHORIZED PERSONNEL ONLY — EDUCATIONAL USE
        </p>
      </div>
    </div>
  )
}
