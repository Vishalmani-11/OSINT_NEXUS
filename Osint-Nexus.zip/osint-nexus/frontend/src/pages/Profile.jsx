/**
 * OSINT Nexus - Profile Page
 */
import React, { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { User, Shield, Key, Save } from 'lucide-react'
import { authAPI } from '../services/api'
import useAuthStore from '../store/authStore'
import toast from 'react-hot-toast'
import { format } from 'date-fns'

export default function ProfilePage() {
  const { user, fetchMe } = useAuthStore()
  const [form, setForm] = useState({ full_name: user?.full_name || '', bio: user?.bio || '' })
  const [pwForm, setPwForm] = useState({ current_password: '', new_password: '' })

  const updateMutation = useMutation({
    mutationFn: (data) => authAPI.updateMe(data),
    onSuccess: () => { fetchMe(); toast.success('Profile updated') },
    onError:   () => toast.error('Update failed'),
  })

  const pwMutation = useMutation({
    mutationFn: (data) => authAPI.changePassword(data),
    onSuccess: () => { setPwForm({ current_password: '', new_password: '' }); toast.success('Password changed') },
    onError: (e) => toast.error(e.response?.data?.detail || 'Password change failed'),
  })

  const ROLE_COLORS = { admin: 'text-red-400', analyst: 'text-brand', viewer: 'text-blue-400' }

  return (
    <div className="space-y-5 animate-fade-in max-w-2xl">
      <div>
        <h1 className="text-lg font-mono font-bold text-slate-200 tracking-wider">Profile</h1>
        <p className="text-xs font-mono text-slate-600 mt-0.5">Manage your account settings</p>
      </div>

      {/* Identity card */}
      <div className="card p-5">
        <div className="flex items-center gap-4 mb-5 pb-4 border-b border-surface-600">
          <div className="w-14 h-14 rounded-xl bg-brand/10 border border-brand/30
                          flex items-center justify-center text-2xl font-mono font-bold text-brand">
            {user?.username?.[0]?.toUpperCase()}
          </div>
          <div>
            <div className="font-mono font-bold text-slate-200 text-sm">{user?.username}</div>
            <div className="text-xs text-slate-500 font-mono">{user?.email}</div>
            <div className={`text-xs font-mono font-semibold mt-0.5 ${ROLE_COLORS[user?.role] || 'text-slate-400'}`}>
              <Shield size={10} className="inline mr-1" />
              {user?.role?.toUpperCase()}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 text-xs font-mono">
          <div>
            <span className="text-slate-600">Account Created</span>
            <div className="text-slate-400 mt-0.5">
              {user?.created_at && format(new Date(user.created_at), 'MMM d, yyyy')}
            </div>
          </div>
          <div>
            <span className="text-slate-600">Last Login</span>
            <div className="text-slate-400 mt-0.5">
              {user?.last_login ? format(new Date(user.last_login), 'MMM d, yyyy HH:mm') : 'N/A'}
            </div>
          </div>
          <div>
            <span className="text-slate-600">Account Status</span>
            <div className="text-brand mt-0.5">● ACTIVE</div>
          </div>
          <div>
            <span className="text-slate-600">Verified</span>
            <div className={`mt-0.5 ${user?.is_verified ? 'text-brand' : 'text-amber-400'}`}>
              {user?.is_verified ? '✓ Verified' : '⚠ Not verified'}
            </div>
          </div>
        </div>
      </div>

      {/* Edit profile */}
      <div className="card p-4">
        <div className="section-header"><User size={12} />Edit Profile</div>
        <form onSubmit={e => { e.preventDefault(); updateMutation.mutate(form) }} className="space-y-3">
          <div>
            <label className="input-label">Full Name</label>
            <input className="input" placeholder="Jane Doe" value={form.full_name}
              onChange={e => setForm({ ...form, full_name: e.target.value })} />
          </div>
          <div>
            <label className="input-label">Bio</label>
            <textarea className="input resize-none" rows={2} placeholder="Senior OSINT analyst..."
              value={form.bio} onChange={e => setForm({ ...form, bio: e.target.value })} />
          </div>
          <button type="submit" disabled={updateMutation.isPending} className="btn-primary">
            <Save size={13} />
            {updateMutation.isPending ? 'SAVING...' : 'Save Changes'}
          </button>
        </form>
      </div>

      {/* Change password */}
      <div className="card p-4">
        <div className="section-header"><Key size={12} />Change Password</div>
        <form onSubmit={e => { e.preventDefault(); pwMutation.mutate(pwForm) }} className="space-y-3">
          <div>
            <label className="input-label">Current Password</label>
            <input type="password" className="input" placeholder="••••••••"
              value={pwForm.current_password}
              onChange={e => setPwForm({ ...pwForm, current_password: e.target.value })} required />
          </div>
          <div>
            <label className="input-label">New Password (min 8 chars)</label>
            <input type="password" className="input" placeholder="••••••••"
              value={pwForm.new_password} minLength={8}
              onChange={e => setPwForm({ ...pwForm, new_password: e.target.value })} required />
          </div>
          <button type="submit" disabled={pwMutation.isPending} className="btn-primary">
            <Key size={13} />
            {pwMutation.isPending ? 'CHANGING...' : 'Change Password'}
          </button>
        </form>
      </div>
    </div>
  )
}
