/**
 * OSINT Nexus - Register Page
 */
import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Shield, UserPlus } from 'lucide-react'
import useAuthStore from '../store/authStore'
import toast from 'react-hot-toast'

export default function RegisterPage() {
  const [form, setForm] = useState({
    username: '', email: '', password: '', full_name: ''
  })
  const { register, isLoading } = useAuthStore()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (form.password.length < 8) {
      toast.error('Password must be at least 8 characters')
      return
    }
    const result = await register(form)
    if (result.success) {
      toast.success('Account created — please log in')
      navigate('/login')
    } else {
      toast.error(result.error || 'Registration failed')
    }
  }

  const field = (key, label, type = 'text', placeholder = '') => (
    <div>
      <label className="input-label">{label}</label>
      <input
        type={type}
        className="input"
        placeholder={placeholder}
        value={form[key]}
        onChange={(e) => setForm({ ...form, [key]: e.target.value })}
        required={key !== 'full_name'}
      />
    </div>
  )

  return (
    <div className="min-h-screen bg-surface-900 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,136,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,136,0.02)_1px,transparent_1px)]
                      bg-[size:60px_60px] pointer-events-none" />
      <div className="w-full max-w-sm relative">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl
                          bg-brand/10 border border-brand/30 mb-4
                          shadow-[0_0_30px_rgba(0,255,136,0.15)]">
            <Shield size={28} className="text-brand" />
          </div>
          <h1 className="text-2xl font-mono font-bold text-brand tracking-widest">OSINT NEXUS</h1>
          <p className="text-xs font-mono text-slate-600 mt-1 tracking-widest">REQUEST ACCESS</p>
        </div>

        <div className="card-elevated p-6">
          <div className="flex items-center gap-2 mb-5 pb-3 border-b border-surface-600">
            <UserPlus size={13} className="text-brand" />
            <span className="text-xs font-mono text-slate-500 uppercase tracking-widest">
              Create Account
            </span>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {field('full_name', 'Full Name (optional)', 'text', 'Jane Doe')}
            {field('username', 'Username', 'text', 'analyst01')}
            {field('email', 'Email Address', 'email', 'analyst@osint.local')}
            {field('password', 'Password (min 8 chars)', 'password', '••••••••••••')}

            <div className="bg-amber-900/20 border border-amber-900/40 rounded-md p-3 mt-2">
              <p className="text-xs font-mono text-amber-500/80">
                ⚠ The first registered account receives admin privileges.
                Use this platform for authorized investigations only.
              </p>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary w-full justify-center"
            >
              {isLoading ? 'CREATING ACCOUNT...' : 'CREATE ACCOUNT'}
            </button>
          </form>

          <p className="text-center text-xs font-mono text-slate-600 mt-4">
            Already have access?{' '}
            <Link to="/login" className="text-brand hover:text-brand-dim transition-colors">
              Login
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
