/**
 * OSINT Nexus - Reports Page
 */
import React, { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  FileText, Plus, Download, Loader, CheckCircle,
  XCircle, Clock, RefreshCw
} from 'lucide-react'
import { reportsAPI, casesAPI } from '../services/api'
import { format } from 'date-fns'
import toast from 'react-hot-toast'

const FORMAT_META = {
  pdf:  { label: 'PDF',  color: 'text-red-400',   icon: '📄' },
  html: { label: 'HTML', color: 'text-orange-400', icon: '🌐' },
  json: { label: 'JSON', color: 'text-blue-400',   icon: '{ }' },
}

const STATUS_META = {
  pending:    { label: 'Pending',    color: 'text-amber-400', icon: Clock,         animate: false },
  generating: { label: 'Generating', color: 'text-blue-400',  icon: Loader,        animate: true  },
  completed:  { label: 'Ready',      color: 'text-brand',     icon: CheckCircle,   animate: false },
  failed:     { label: 'Failed',     color: 'text-red-400',   icon: XCircle,       animate: false },
}

function ReportRow({ report, onDownload }) {
  const sm   = STATUS_META[report.status] || STATUS_META.pending
  const fm   = FORMAT_META[report.format] || FORMAT_META.json
  const Icon = sm.icon

  return (
    <tr>
      <td>
        <div className="text-xs font-mono text-slate-300">{report.title}</div>
        <div className="text-[10px] font-mono text-slate-600">
          {report.created_at && format(new Date(report.created_at), 'MMM d, yyyy HH:mm')}
        </div>
      </td>
      <td>
        <span className={`text-xs font-mono font-bold ${fm.color}`}>
          {fm.icon} {fm.label}
        </span>
      </td>
      <td>
        <span className={`flex items-center gap-1 text-xs font-mono ${sm.color}`}>
          <Icon size={11} className={sm.animate ? 'animate-spin' : ''} />
          {sm.label}
        </span>
      </td>
      <td>
        {report.file_size && (
          <span className="text-xs font-mono text-slate-600">
            {(report.file_size / 1024).toFixed(1)} KB
          </span>
        )}
      </td>
      <td>
        {report.status === 'completed' && (
          <a
            href={onDownload(report.id)}
            target="_blank"
            rel="noreferrer"
            className="btn-secondary text-xs inline-flex items-center gap-1"
          >
            <Download size={11} /> Download
          </a>
        )}
        {report.status === 'failed' && report.error_message && (
          <span className="text-xs font-mono text-red-500/80 max-w-[200px] truncate" title={report.error_message}>
            {report.error_message.slice(0, 40)}…
          </span>
        )}
      </td>
    </tr>
  )
}

function GenerateModal({ onClose }) {
  const [form, setForm] = useState({
    title: '', case_id: '', format: 'pdf',
    include_summary: true, include_evidence: true,
    include_timeline: true, include_graph: false,
  })
  const qc = useQueryClient()
  const { data: cases } = useQuery({
    queryKey: ['cases-list-simple'],
    queryFn: () => casesAPI.list({}).then(r => r.data),
  })

  const mutation = useMutation({
    mutationFn: (data) => reportsAPI.generate({ ...data, case_id: parseInt(data.case_id) }).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['reports'] })
      toast.success('Report queued for generation')
      onClose()
    },
    onError: (e) => toast.error(e.response?.data?.detail || 'Failed to queue report'),
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!form.case_id) return toast.error('Select a case')
    mutation.mutate(form)
  }

  const toggle = (key) => setForm(f => ({ ...f, [key]: !f[key] }))

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="card-elevated w-full max-w-md p-5 animate-fade-in">
        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-surface-600">
          <FileText size={14} className="text-brand" />
          <h3 className="text-sm font-mono font-semibold text-slate-200">Generate Report</h3>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="input-label">Report Title *</label>
            <input className="input" placeholder="Q1 Investigation Report" value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })} required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="input-label">Case *</label>
              <select className="input" value={form.case_id}
                onChange={e => setForm({ ...form, case_id: e.target.value })} required>
                <option value="">Select...</option>
                {cases?.map(c => <option key={c.id} value={c.id}>{c.case_number}</option>)}
              </select>
            </div>
            <div>
              <label className="input-label">Format</label>
              <select className="input" value={form.format}
                onChange={e => setForm({ ...form, format: e.target.value })}>
                <option value="pdf">PDF</option>
                <option value="html">HTML</option>
                <option value="json">JSON</option>
              </select>
            </div>
          </div>

          <div>
            <label className="input-label">Include Sections</label>
            <div className="grid grid-cols-2 gap-2 mt-1">
              {[
                ['include_summary',  'Summary'],
                ['include_evidence', 'Evidence'],
                ['include_timeline', 'Timeline'],
                ['include_graph',    'Graph (beta)'],
              ].map(([key, label]) => (
                <label key={key} className="flex items-center gap-2 text-xs font-mono text-slate-400 cursor-pointer">
                  <input type="checkbox" checked={form[key]} onChange={() => toggle(key)}
                    className="accent-brand" />
                  {label}
                </label>
              ))}
            </div>
          </div>

          <div className="flex gap-2 pt-1">
            <button type="submit" disabled={mutation.isPending} className="btn-primary flex-1 justify-center">
              {mutation.isPending ? 'QUEUING...' : 'GENERATE REPORT'}
            </button>
            <button type="button" onClick={onClose} className="btn-secondary px-4">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  )
}

export function ReportsPage() {
  const [showModal, setShowModal] = useState(false)
  const qc = useQueryClient()

  const { data: reports, isLoading } = useQuery({
    queryKey: ['reports'],
    queryFn: () => reportsAPI.list({}).then(r => r.data),
    refetchInterval: 10_000,
  })

  const hasRunning = reports?.some(r => ['pending', 'generating'].includes(r.status))

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-mono font-bold text-slate-200 tracking-wider">Reports</h1>
          <p className="text-xs font-mono text-slate-600 mt-0.5">
            Generate PDF, HTML, and JSON investigation reports
          </p>
        </div>
        <div className="flex gap-2">
          {hasRunning && (
            <button onClick={() => qc.invalidateQueries({ queryKey: ['reports'] })}
              className="btn-ghost text-xs">
              <RefreshCw size={12} /> Refresh
            </button>
          )}
          <button onClick={() => setShowModal(true)} className="btn-primary">
            <Plus size={14} /> Generate Report
          </button>
        </div>
      </div>

      <div className="card overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center">
            <Loader size={20} className="text-brand animate-spin mx-auto" />
          </div>
        ) : reports?.length === 0 ? (
          <div className="p-12 text-center">
            <FileText size={32} className="text-slate-700 mx-auto mb-3" />
            <p className="text-sm font-mono text-slate-600">No reports generated yet</p>
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Format</th>
                <th>Status</th>
                <th>Size</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {reports.map(r => (
                <ReportRow key={r.id} report={r} onDownload={reportsAPI.download} />
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && <GenerateModal onClose={() => setShowModal(false)} />}
    </div>
  )
}

export default ReportsPage
