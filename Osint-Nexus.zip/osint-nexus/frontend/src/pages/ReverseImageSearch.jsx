/**
 * OSINT Nexus - Reverse Image Search Page
 * Upload an image → get Google Images, Google Lens, Yandex, TinEye,
 * and Bing Visual Search links instantly. If SERPAPI_KEY or TINEYE_API_KEY
 * are configured server-side, structured match results are also returned.
 */
import React, { useState, useCallback } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useDropzone } from 'react-dropzone'
import {
  Image, Upload, ExternalLink, Search, Loader, Info,
  Globe, Trash2, Clock, ChevronDown, ChevronUp
} from 'lucide-react'
import { casesAPI } from '../services/api'
import { formatDistanceToNow } from 'date-fns'
import { formatBytes } from '../utils/helpers'
import toast from 'react-hot-toast'
import api from '../services/api'

// Friendly labels + colours per engine
const ENGINE_META = {
  'Google Images':          { color: 'text-blue-400',   icon: '🔍' },
  'Google Lens':            { color: 'text-blue-300',   icon: '🔎' },
  'Google Images (Upload)': { color: 'text-blue-400',   icon: '🔍' },
  'Google Lens (Upload)':   { color: 'text-blue-300',   icon: '🔎' },
  'Yandex Images':          { color: 'text-red-400',    icon: '🅨' },
  'Yandex (Upload)':        { color: 'text-red-400',    icon: '🅨' },
  'TinEye':                 { color: 'text-amber-400',  icon: '👁' },
  'TinEye (Upload)':        { color: 'text-amber-400',  icon: '👁' },
  'Bing Visual Search':     { color: 'text-cyan-400',   icon: '🔷' },
  'Bing Visual (Upload)':   { color: 'text-cyan-400',   icon: '🔷' },
}

// ── Drop zone ─────────────────────────────────────────────────────
function DropZone({ onFile, loading }) {
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: useCallback(files => files[0] && onFile(files[0]), [onFile]),
    accept: { 'image/*': ['.jpg','.jpeg','.png','.webp','.bmp','.gif'] },
    maxFiles: 1,
    disabled: loading,
  })
  return (
    <div {...getRootProps()} className={`
      border-2 border-dashed rounded-lg p-8 text-center cursor-pointer
      transition-all duration-200
      ${isDragActive ? 'border-brand bg-brand/5 shadow-[0_0_24px_rgba(0,255,136,0.12)]'
                     : 'border-surface-500 hover:border-brand/50 hover:bg-surface-800/50'}
    `}>
      <input {...getInputProps()} />
      {loading ? (
        <div className="flex flex-col items-center gap-3">
          <Loader size={28} className="text-brand animate-spin" />
          <p className="text-xs font-mono text-slate-500">Analysing image & building search links…</p>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3">
          <Upload size={28} className={isDragActive ? 'text-brand' : 'text-slate-600'} />
          <div>
            <p className="text-sm font-mono text-slate-400">
              {isDragActive ? 'Drop image here' : 'Drag & drop or click to select'}
            </p>
            <p className="text-xs font-mono text-slate-700 mt-1">
              JPG · PNG · WEBP · GIF · BMP — max 10 MB
            </p>
          </div>
        </div>
      )}
    </div>
  )
}

// ── Single result row ─────────────────────────────────────────────
function SearchResultCard({ result, searchId }) {
  const [expanded, setExpanded] = useState(false)
  const links  = result.search_links || {}
  const apiRes = result.api_results  || []

  // Separate direct links from upload-page fallbacks
  const directLinks = Object.entries(links).filter(([k]) => !k.includes('(Upload)'))
  const uploadLinks = Object.entries(links).filter(([k]) =>  k.includes('(Upload)'))

  return (
    <div className="card overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 bg-surface-800 border-b border-surface-600 flex items-start justify-between">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <Image size={14} className="text-brand flex-shrink-0" />
            <span className="font-mono font-semibold text-slate-200 text-sm truncate max-w-xs">
              {result.filename}
            </span>
            <span className="badge badge-found">{result.status}</span>
            {result.serpapi_used && (
              <span className="badge badge-active text-[10px]">Google Lens API</span>
            )}
            {result.tineye_used && (
              <span className="badge badge-medium text-[10px]">TinEye API</span>
            )}
          </div>
          <div className="flex gap-4 mt-1 text-[10px] font-mono text-slate-600">
            {result.image_width  && <span>{result.image_width}×{result.image_height}px</span>}
            {result.file_size    && <span>{formatBytes(result.file_size)}</span>}
            {result.mime_type    && <span>{result.mime_type}</span>}
            {result.total_found  > 0 && (
              <span className="text-brand font-bold">{result.total_found} web matches found</span>
            )}
            {result.created_at   && (
              <span>{formatDistanceToNow(new Date(result.created_at), { addSuffix: true })}</span>
            )}
          </div>
        </div>
        <button onClick={() => setExpanded(e => !e)} className="btn-icon ml-2 flex-shrink-0">
          {expanded ? <ChevronUp size={14}/> : <ChevronDown size={14}/>}
        </button>
      </div>

      {/* Direct search links — always shown */}
      <div className="px-4 py-3 border-b border-surface-600">
        <div className="text-[10px] font-mono text-slate-600 uppercase tracking-wider mb-2">
          Open in search engine
        </div>
        <div className="flex flex-wrap gap-2">
          {(directLinks.length ? directLinks : uploadLinks).map(([engine, url]) => {
            const meta = ENGINE_META[engine] || { color: 'text-slate-400', icon: '🔗' }
            return (
              <a
                key={engine}
                href={url}
                target="_blank"
                rel="noreferrer noopener"
                className={`flex items-center gap-1.5 text-xs font-mono px-2.5 py-1.5 rounded
                           bg-surface-800 border border-surface-600 hover:border-brand/40
                           hover:bg-surface-700 transition-all ${meta.color}`}
              >
                <span>{meta.icon}</span>
                {engine.replace(' (Upload)', '')}
                <ExternalLink size={10} className="opacity-50" />
              </a>
            )
          })}
        </div>
      </div>

      {/* Expandable: API results + EXIF */}
      {expanded && (
        <div className="px-4 py-3 space-y-4">

          {/* API results */}
          {apiRes.length > 0 ? (
            <div>
              <div className="text-[10px] font-mono text-slate-600 uppercase tracking-wider mb-2">
                {apiRes.length} web matches
              </div>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {apiRes.map((m, i) => (
                  <div key={i} className="flex items-start gap-3 bg-surface-800
                                          border border-surface-600 rounded-md p-2">
                    {m.thumbnail_url && (
                      <img src={m.thumbnail_url} alt=""
                           className="w-12 h-12 object-cover rounded flex-shrink-0 opacity-80" />
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-brand">{m.source}</span>
                        {m.domain && (
                          <span className="text-[10px] font-mono text-slate-600">{m.domain}</span>
                        )}
                      </div>
                      <p className="text-xs font-mono text-slate-300 truncate mt-0.5">
                        {m.title || m.url}
                      </p>
                      <a href={m.url} target="_blank" rel="noreferrer"
                         className="text-[10px] font-mono text-blue-400 hover:underline
                                    flex items-center gap-1 mt-0.5 truncate">
                        {m.url} <ExternalLink size={8} />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-xs font-mono text-slate-600 py-2">
              No API results — use the search links above to open results in your browser.
              Configure <code className="text-brand">SERPAPI_KEY</code> or{' '}
              <code className="text-brand">TINEYE_API_KEY</code> for structured results.
            </div>
          )}

          {/* EXIF metadata */}
          {Object.keys(result.exif_data || {}).length > 0 && (
            <div>
              <div className="text-[10px] font-mono text-slate-600 uppercase tracking-wider mb-2">
                EXIF / GPS metadata
              </div>
              <div className="grid grid-cols-2 gap-1">
                {Object.entries(result.exif_data).slice(0, 12).map(([k, v]) => (
                  <div key={k} className="text-[10px] font-mono">
                    <span className="text-slate-600">{k}:</span>{' '}
                    <span className="text-slate-400">{String(v).slice(0, 40)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Upload links always available as fallback */}
          {directLinks.length > 0 && uploadLinks.length > 0 && (
            <div>
              <div className="text-[10px] font-mono text-slate-600 uppercase tracking-wider mb-2">
                Manual upload (drag image to these pages)
              </div>
              <div className="flex flex-wrap gap-2">
                {uploadLinks.map(([engine, url]) => (
                  <a key={engine} href={url} target="_blank" rel="noreferrer"
                     className="text-[10px] font-mono text-slate-600 hover:text-slate-400
                                underline underline-offset-2 transition-colors">
                    {engine}
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ── Main Page ─────────────────────────────────────────────────────
export default function ReverseImageSearchPage() {
  const [searchParams]     = useSearchParams()
  const [caseId, setCaseId]       = useState(searchParams.get('case_id') || '')
  const [subjectId, setSubjectId] = useState(searchParams.get('subject_id') || '')
  const [pubUrl, setPubUrl]       = useState('')
  const qc = useQueryClient()

  const { data: cases } = useQuery({
    queryKey: ['cases-list-simple'],
    queryFn:  () => casesAPI.list({}).then(r => r.data),
  })
  const { data: subjects } = useQuery({
    queryKey: ['subjects-for-case', caseId],
    queryFn:  () => casesAPI.listSubjects(caseId).then(r => r.data),
    enabled:  !!caseId,
  })
  const { data: searches, isLoading } = useQuery({
    queryKey: ['image-searches', caseId],
    queryFn:  () => api.get(`/images/case/${caseId}`).then(r => r.data),
    enabled:  !!caseId,
  })

  const uploadMutation = useMutation({
    mutationFn: async (file) => {
      if (!caseId) throw new Error('Select a case first')
      const form = new FormData()
      form.append('file',    file)
      form.append('case_id', caseId)
      if (subjectId)  form.append('subject_id',      subjectId)
      if (pubUrl.trim()) form.append('public_base_url', pubUrl.trim())
      return api.post('/images/search', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
        timeout: 60_000,
      }).then(r => r.data)
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['image-searches', caseId] })
      toast.success('Image uploaded — search links ready')
    },
    onError: (e) => toast.error(e.response?.data?.detail || e.message || 'Upload failed'),
  })

  const deleteMutation = useMutation({
    mutationFn: (id) => api.delete(`/images/${id}`),
    onSuccess:  () => {
      qc.invalidateQueries({ queryKey: ['image-searches', caseId] })
      toast.success('Deleted')
    },
  })

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-lg font-mono font-bold text-slate-200 tracking-wider">
          Reverse Image Search
        </h1>
        <p className="text-xs font-mono text-slate-600 mt-0.5">
          Upload any image — get instant search links for Google, Yandex, TinEye &amp; Bing
        </p>
      </div>

      {/* Info banner */}
      <div className="bg-blue-900/20 border border-blue-900/40 rounded-md p-3 flex gap-2">
        <Info size={14} className="text-blue-400 flex-shrink-0 mt-0.5" />
        <div className="text-xs font-mono text-blue-400/90 space-y-1">
          <p>
            <strong>Free mode</strong> — always generates deep-link URLs you can open directly
            in a browser with the image pre-loaded for reverse search.
          </p>
          <p>
            <strong>API mode</strong> — set <code className="bg-blue-900/30 px-1 rounded">SERPAPI_KEY</code> or{' '}
            <code className="bg-blue-900/30 px-1 rounded">TINEYE_API_KEY</code> in your{' '}
            <code className="bg-blue-900/30 px-1 rounded">.env</code> to get structured result lists automatically.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Upload panel */}
        <div className="card p-4 space-y-4">
          <div className="section-header"><Upload size={12} />Upload Image</div>

          {/* Case selector */}
          <div>
            <label className="input-label">Case *</label>
            <select className="input" value={caseId}
              onChange={e => { setCaseId(e.target.value); setSubjectId('') }}>
              <option value="">Select a case…</option>
              {cases?.map(c => (
                <option key={c.id} value={c.id}>{c.case_number} — {c.title}</option>
              ))}
            </select>
          </div>

          {/* Subject (optional) */}
          <div>
            <label className="input-label">Subject (optional)</label>
            <select className="input" value={subjectId}
              onChange={e => setSubjectId(e.target.value)}>
              <option value="">None</option>
              {subjects?.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>

          {/* Public URL (optional) */}
          <div>
            <label className="input-label">
              Server public URL — enables direct search links
            </label>
            <input
              type="text"
              className="input text-xs"
              placeholder="https://your-server.example.com"
              value={pubUrl}
              onChange={e => setPubUrl(e.target.value)}
            />
            <p className="text-[10px] font-mono text-slate-700 mt-1">
              Leave blank for upload-page links only.
              Set if your OSINT Nexus server is publicly reachable.
            </p>
          </div>

          <DropZone
            onFile={(file) => uploadMutation.mutate(file)}
            loading={uploadMutation.isPending}
          />
        </div>

        {/* Results panel */}
        <div className="lg:col-span-2 space-y-4">
          {!caseId ? (
            <div className="card p-12 text-center">
              <Globe size={32} className="text-slate-700 mx-auto mb-3" />
              <p className="text-xs font-mono text-slate-600">
                Select a case to view reverse image searches
              </p>
            </div>
          ) : isLoading ? (
            <div className="space-y-3">
              {[1,2].map(i => <div key={i} className="card p-4"><div className="skeleton h-20" /></div>)}
            </div>
          ) : searches?.length === 0 ? (
            <div className="card p-12 text-center">
              <Image size={32} className="text-slate-700 mx-auto mb-3" />
              <p className="text-xs font-mono text-slate-600">No images uploaded for this case</p>
              <p className="text-[10px] font-mono text-slate-700 mt-1">
                Upload a profile photo, screenshot, or any image to find it on the web
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-slate-600">
                  {searches.length} image search{searches.length !== 1 ? 'es' : ''}
                </span>
              </div>
              {searches.map(s => (
                <div key={s.id} className="relative">
                  <button
                    onClick={() => deleteMutation.mutate(s.id)}
                    className="absolute top-3 right-3 z-10 btn-icon text-red-500
                               hover:text-red-400 opacity-60 hover:opacity-100"
                    title="Delete"
                  >
                    <Trash2 size={13} />
                  </button>
                  <SearchResultCard result={s} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
