/**
 * OSINT Nexus - Username Search Page
 * Sherlock integration for social platform username discovery.
 */
import React, { useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  AtSign, Search, ExternalLink, CheckCircle, XCircle,
  Clock, Loader, Trash2, RefreshCw, Download
} from 'lucide-react'
import { usernameAPI, casesAPI } from '../services/api'
import { formatDistanceToNow } from 'date-fns'
import toast from 'react-hot-toast'

// ── Status config ─────────────────────────────────────────────────
const STATUS_META = {
  pending:   { color: 'text-amber-400',  label: 'PENDING',    icon: Clock },
  running:   { color: 'text-blue-400',   label: 'RUNNING',    icon: Loader },
  found:     { color: 'text-brand',      label: 'FOUND',      icon: CheckCircle },
  not_found: { color: 'text-slate-500',  label: 'NO RESULTS', icon: XCircle },
  error:     { color: 'text-red-400',    label: 'ERROR',      icon: XCircle },
  demo:      { color: 'text-purple-400', label: 'DEMO',       icon: CheckCircle },
}

// ── Search Result Row ─────────────────────────────────────────────
function ProfileRow({ profile }) {
  return (
    <tr className={profile.is_found ? '' : 'opacity-40'}>
      <td>
        <div className="flex items-center gap-2">
          <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
            profile.is_found ? 'bg-brand' : 'bg-slate-700'}`} />
          <span className="font-mono text-xs text-slate-300">{profile.platform}</span>
        </div>
      </td>
      <td>
        {profile.is_found ? (
          <a href={profile.url} target="_blank" rel="noreferrer"
             className="text-xs font-mono text-blue-400 hover:text-blue-300 flex items-center gap-1 max-w-xs truncate">
            {profile.url}
            <ExternalLink size={10} className="flex-shrink-0" />
          </a>
        ) : (
          <span className="text-xs font-mono text-slate-700 line-through">{profile.url}</span>
        )}
      </td>
      <td>
        {profile.is_found ? (
          <span className="badge badge-found">FOUND</span>
        ) : (
          <span className="text-xs font-mono text-slate-700">not found</span>
        )}
      </td>
      <td>
        {profile.http_status && (
          <span className={`text-xs font-mono ${
            profile.http_status === 200 ? 'text-brand' : 'text-slate-600'}`}>
            {profile.http_status}
          </span>
        )}
      </td>
      <td>
        {profile.response_time_ms && (
          <span className="text-xs font-mono text-slate-600">{profile.response_time_ms}ms</span>
        )}
      </td>
    </tr>
  )
}

// ── Search Result Card ────────────────────────────────────────────
function SearchResultCard({ search, onDelete }) {
  const meta = STATUS_META[search.status] || STATUS_META.pending
  const Icon = meta.icon
  const isRunning = ['pending', 'running'].includes(search.status)

  // Poll while running
  const { data: liveSearch } = useQuery({
    queryKey: ['username-search', search.id],
    queryFn: () => usernameAPI.getSearch(search.id).then(r => r.data),
    refetchInterval: isRunning ? 3000 : false,
    initialData: search,
  })

  const current = liveSearch || search
  const foundProfiles = current.profiles?.filter(p => p.is_found) || []
  const allProfiles   = current.profiles || []

  const exportCSV = () => {
    const rows = [
      ['Platform', 'URL', 'Status', 'HTTP Status'],
      ...allProfiles.map(p => [p.platform, p.url, p.is_found ? 'FOUND' : 'NOT FOUND', p.http_status || '']),
    ]
    const csv = rows.map(r => r.join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url  = URL.createObjectURL(blob)
    const a    = document.createElement('a')
    a.href = url; a.download = `username_${current.username}.csv`; a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="card overflow-hidden">
      {/* Card header */}
      <div className="px-4 py-3 bg-surface-800 border-b border-surface-600 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <AtSign size={16} className="text-brand" />
          <span className="font-mono font-bold text-slate-200 text-sm">@{current.username}</span>
          <span className={`flex items-center gap-1 text-xs font-mono ${meta.color}`}>
            <Icon size={11} className={isRunning ? 'animate-spin' : ''} />
            {meta.label}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {!isRunning && allProfiles.length > 0 && (
            <button onClick={exportCSV} className="btn-ghost text-xs" title="Export CSV">
              <Download size={13} />
            </button>
          )}
          <button onClick={() => onDelete(search.id)} className="btn-ghost text-red-500 hover:text-red-400">
            <Trash2 size={13} />
          </button>
        </div>
      </div>

      {/* Progress bar when running */}
      {isRunning && (
        <div className="h-0.5 bg-surface-600 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-brand to-transparent scan-bar" />
        </div>
      )}

      {/* Stats */}
      <div className="px-4 py-3 border-b border-surface-600 flex items-center gap-6">
        <div className="text-xs font-mono">
          <span className="text-brand font-bold text-lg">{current.total_found}</span>
          <span className="text-slate-600"> / {current.total_checked} found</span>
        </div>
        {current.completed_at && (
          <span className="text-xs font-mono text-slate-600">
            Completed {formatDistanceToNow(new Date(current.completed_at), { addSuffix: true })}
          </span>
        )}
        {current.error_message && (
          <span className="text-xs font-mono text-red-400">⚠ {current.error_message}</span>
        )}
      </div>

      {/* Found platforms summary */}
      {foundProfiles.length > 0 && (
        <div className="px-4 py-3 border-b border-surface-600 flex flex-wrap gap-1.5">
          {foundProfiles.map(p => (
            <a key={p.id} href={p.url} target="_blank" rel="noreferrer"
               className="flex items-center gap-1 text-[10px] font-mono bg-brand/10 text-brand
                          border border-brand/20 px-1.5 py-0.5 rounded hover:bg-brand/20 transition-colors">
              {p.platform} <ExternalLink size={8} />
            </a>
          ))}
        </div>
      )}

      {/* Full results table */}
      {allProfiles.length > 0 && (
        <div className="max-h-64 overflow-y-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>Platform</th>
                <th>URL</th>
                <th>Status</th>
                <th>HTTP</th>
                <th>Time</th>
              </tr>
            </thead>
            <tbody>
              {allProfiles.map(p => <ProfileRow key={p.id} profile={p} />)}
            </tbody>
          </table>
        </div>
      )}

      {isRunning && allProfiles.length === 0 && (
        <div className="px-4 py-8 text-center">
          <div className="text-xs font-mono text-slate-600 flex items-center justify-center gap-2">
            <Loader size={13} className="animate-spin text-brand" />
            Scanning platforms... this may take 30–60 seconds
          </div>
        </div>
      )}
    </div>
  )
}

// ── Main Page ─────────────────────────────────────────────────────
export default function UsernameSearchPage() {
  const [searchParams] = useSearchParams()
  const [username, setUsername]   = useState('')
  const [caseId, setCaseId]       = useState(searchParams.get('case_id') || '')
  const [subjectId, setSubjectId] = useState(searchParams.get('subject_id') || '')
  const qc = useQueryClient()

  const { data: cases } = useQuery({
    queryKey: ['cases-list-simple'],
    queryFn: () => casesAPI.list({}).then(r => r.data),
  })

  const { data: subjects } = useQuery({
    queryKey: ['subjects-for-case', caseId],
    queryFn: () => casesAPI.listSubjects(caseId).then(r => r.data),
    enabled: !!caseId,
  })

  const { data: searches, isLoading } = useQuery({
    queryKey: ['username-searches', caseId],
    queryFn: () => caseId
      ? usernameAPI.listCaseSearches(caseId).then(r => r.data)
      : Promise.resolve([]),
    enabled: !!caseId,
    refetchInterval: 10_000,
  })

  const startSearch = useMutation({
    mutationFn: (data) => usernameAPI.startSearch(data).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['username-searches', caseId] })
      setUsername('')
      toast.success('Username scan started')
    },
    onError: (e) => toast.error(e.response?.data?.detail || 'Search failed'),
  })

  const deleteSearch = useMutation({
    mutationFn: (id) => usernameAPI.deleteSearch(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['username-searches', caseId] })
      toast.success('Search deleted')
    },
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!username.trim()) return toast.error('Enter a username')
    if (!caseId) return toast.error('Select a case first')
    startSearch.mutate({
      username: username.trim(),
      case_id: parseInt(caseId),
      subject_id: subjectId ? parseInt(subjectId) : null,
    })
  }

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-lg font-mono font-bold text-slate-200 tracking-wider">
          Username OSINT
        </h1>
        <p className="text-xs font-mono text-slate-600 mt-0.5">
          Search for a username across 400+ social platforms using Sherlock
        </p>
      </div>

      {/* Search Form */}
      <div className="card p-4">
        <div className="section-header"><Search size={12} />New Username Search</div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* Username */}
            <div>
              <label className="input-label">Username to Search *</label>
              <div className="relative">
                <AtSign size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-600" />
                <input
                  type="text"
                  className="input pl-8"
                  placeholder="johndoe"
                  value={username}
                  onChange={e => setUsername(e.target.value.replace(/\s/g, ''))}
                  pattern="[a-zA-Z0-9._\-]+"
                  title="Alphanumeric, dots, dashes and underscores only"
                  required
                />
              </div>
            </div>

            {/* Case selector */}
            <div>
              <label className="input-label">Case *</label>
              <select className="input" value={caseId}
                onChange={e => { setCaseId(e.target.value); setSubjectId('') }} required>
                <option value="">Select a case...</option>
                {cases?.map(c => (
                  <option key={c.id} value={c.id}>{c.case_number} — {c.title}</option>
                ))}
              </select>
            </div>

            {/* Subject selector */}
            <div>
              <label className="input-label">Subject (optional)</label>
              <select className="input" value={subjectId} onChange={e => setSubjectId(e.target.value)}>
                <option value="">No specific subject</option>
                {subjects?.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Info banner */}
          <div className="bg-blue-900/20 border border-blue-900/40 rounded-md p-3">
            <p className="text-xs font-mono text-blue-400/80">
              ℹ Sherlock checks 400+ platforms for the given username. Results arrive within 30–90 seconds.
              {' '}If Sherlock is not installed, demo mode returns synthetic results for learning.
            </p>
          </div>

          <button
            type="submit"
            disabled={startSearch.isPending || !username || !caseId}
            className="btn-primary"
          >
            {startSearch.isPending ? (
              <><Loader size={13} className="animate-spin" /> SEARCHING...</>
            ) : (
              <><Search size={13} /> START SEARCH</>
            )}
          </button>
        </form>
      </div>

      {/* Results */}
      {!caseId ? (
        <div className="card p-12 text-center">
          <AtSign size={32} className="text-slate-700 mx-auto mb-3" />
          <p className="text-xs font-mono text-slate-600">Select a case above to view searches</p>
        </div>
      ) : isLoading ? (
        <div className="space-y-3">
          {[1, 2].map(i => <div key={i} className="card p-4"><div className="skeleton h-24" /></div>)}
        </div>
      ) : searches?.length === 0 ? (
        <div className="card p-12 text-center">
          <Search size={32} className="text-slate-700 mx-auto mb-3" />
          <p className="text-xs font-mono text-slate-600">No searches yet for this case</p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-slate-600">
              {searches.length} search{searches.length !== 1 ? 'es' : ''} in this case
            </span>
            <button
              onClick={() => qc.invalidateQueries({ queryKey: ['username-searches', caseId] })}
              className="btn-ghost text-xs"
            >
              <RefreshCw size={12} /> Refresh
            </button>
          </div>
          {searches.map(s => (
            <SearchResultCard
              key={s.id}
              search={s}
              onDelete={(id) => deleteSearch.mutate(id)}
            />
          ))}
        </div>
      )}
    </div>
  )
}
