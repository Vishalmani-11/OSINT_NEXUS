/**
 * OSINT Nexus - API Service
 * Axios instance with JWT auto-refresh, all endpoint helpers.
 * VITE_API_URL defaults to empty string so Vite's /api proxy is used inside Docker.
 */
import axios from 'axios'

// In Docker dev: Vite proxies /api → backend:8000 (same origin, no CORS)
// In production / direct access: set VITE_API_URL=http://localhost:8000
const BASE_URL  = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '')
const API_PREFIX = `${BASE_URL}/api/v1`

// ── Axios instance ────────────────────────────────────────────
const api = axios.create({
  baseURL: API_PREFIX,
  headers: { 'Content-Type': 'application/json' },
  timeout: 30_000,
})

// ── Attach JWT ────────────────────────────────────────────────
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// ── Auto-refresh on 401 ───────────────────────────────────────
let refreshing = false
let queue = []

api.interceptors.response.use(
  (res) => res,
  async (err) => {
    const orig = err.config
    if (err.response?.status === 401 && !orig._retry) {
      if (refreshing) {
        return new Promise((res, rej) => queue.push({ res, rej }))
          .then((token) => { orig.headers.Authorization = `Bearer ${token}`; return api(orig) })
      }
      orig._retry = true
      refreshing  = true
      try {
        const rt = localStorage.getItem('refresh_token')
        if (!rt) throw new Error('no refresh token')
        const { data } = await axios.post(`${API_PREFIX}/auth/refresh`, { refresh_token: rt })
        localStorage.setItem('access_token',  data.access_token)
        localStorage.setItem('refresh_token', data.refresh_token)
        queue.forEach(({ res }) => res(data.access_token))
        queue = []; refreshing = false
        orig.headers.Authorization = `Bearer ${data.access_token}`
        return api(orig)
      } catch {
        queue.forEach(({ rej }) => rej(err))
        queue = []; refreshing = false
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
        window.location.href = '/login'
        return Promise.reject(err)
      }
    }
    return Promise.reject(err)
  }
)

// ════════════════════════════════════════════════════════════════
// Auth
// ════════════════════════════════════════════════════════════════
export const authAPI = {
  register:       (d) => api.post('/auth/register', d),
  login:          (d) => api.post('/auth/login', d),
  refresh:        (d) => api.post('/auth/refresh', d),
  me:             ()  => api.get('/auth/me'),
  updateMe:       (d) => api.patch('/auth/me', d),
  changePassword: (d) => api.post('/auth/change-password', d),
  logout:         ()  => api.post('/auth/logout'),
}

// ════════════════════════════════════════════════════════════════
// Cases
// ════════════════════════════════════════════════════════════════
export const casesAPI = {
  list:          (p)         => api.get('/cases', { params: p }),
  get:           (id)        => api.get(`/cases/${id}`),
  create:        (d)         => api.post('/cases', d),
  update:        (id, d)     => api.patch(`/cases/${id}`, d),
  delete:        (id)        => api.delete(`/cases/${id}`),
  getTimeline:   (id)        => api.get(`/cases/${id}/timeline`),
  // Subjects
  listSubjects:  (cid)       => api.get(`/cases/${cid}/subjects`),
  createSubject: (cid, d)    => api.post(`/cases/${cid}/subjects`, d),
  updateSubject: (cid, sid, d) => api.patch(`/cases/${cid}/subjects/${sid}`, d),
  deleteSubject: (cid, sid)  => api.delete(`/cases/${cid}/subjects/${sid}`),
  // Evidence
  listEvidence:  (cid)       => api.get(`/cases/${cid}/evidence`),
  createEvidence:(cid, d)    => api.post(`/cases/${cid}/evidence`, d),
  deleteEvidence:(cid, eid)  => api.delete(`/cases/${cid}/evidence/${eid}`),
  // Notes
  listNotes:     (cid)       => api.get(`/cases/${cid}/notes`),
  createNote:    (cid, d)    => api.post(`/cases/${cid}/notes`, d),
  deleteNote:    (cid, nid)  => api.delete(`/cases/${cid}/notes/${nid}`),
}

// ════════════════════════════════════════════════════════════════
// Username OSINT
// ════════════════════════════════════════════════════════════════
export const usernameAPI = {
  startSearch:      (d)   => api.post('/usernames/search', d),
  getSearch:        (id)  => api.get(`/usernames/search/${id}`),
  listCaseSearches: (cid) => api.get(`/usernames/case/${cid}`),
  deleteSearch:     (id)  => api.delete(`/usernames/${id}`),
}

// ════════════════════════════════════════════════════════════════
// Face Analysis
// ════════════════════════════════════════════════════════════════
export const facesAPI = {
  upload:   (formData) => api.post('/faces/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    timeout: 60_000,
  }),
  search:   (d)   => api.post('/faces/search', d),
  get:      (id)  => api.get(`/faces/${id}`),
  listCase: (cid) => api.get(`/faces/case/${cid}`),
}

// ════════════════════════════════════════════════════════════════
// Reports
// ════════════════════════════════════════════════════════════════
export const reportsAPI = {
  generate: (d)  => api.post('/reports/generate', d),
  list:     (p)  => api.get('/reports', { params: p }),
  get:      (id) => api.get(`/reports/${id}`),
  downloadUrl: (id) => `${API_PREFIX}/reports/${id}/download`,
}

// ════════════════════════════════════════════════════════════════
// Graph
// ════════════════════════════════════════════════════════════════
export const graphAPI = {
  getCaseGraph: (cid, p) => api.get(`/graph/case/${cid}`, { params: p }),
  query:        (d)      => api.post('/graph/query', d),
}

// ════════════════════════════════════════════════════════════════
// Dashboard
// ════════════════════════════════════════════════════════════════
export const dashboardAPI = {
  getStats:               () => api.get('/dashboard/stats'),
  getActivity:          (n)  => api.get('/dashboard/activity', { params: { limit: n } }),
  getPlatformDistribution: () => api.get('/dashboard/platform-distribution'),
  getTimeline:          (d)  => api.get('/dashboard/timeline-orm', { params: { days: d } }),
}

// ════════════════════════════════════════════════════════════════
// Health
// ════════════════════════════════════════════════════════════════
export const healthAPI = {
  check: () => api.get('/health'),
}

export default api
