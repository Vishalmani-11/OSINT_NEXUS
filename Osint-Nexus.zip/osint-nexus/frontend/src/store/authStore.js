/**
 * OSINT Nexus - Auth Store (Zustand)
 * Manages authentication state, token storage, and user session.
 */
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { authAPI } from '../services/api'

const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,

      // ── Actions ─────────────────────────────────────────────────

      login: async (credentials) => {
        set({ isLoading: true })
        try {
          const { data } = await authAPI.login(credentials)
          localStorage.setItem('access_token', data.access_token)
          localStorage.setItem('refresh_token', data.refresh_token)
          set({ user: data.user, isAuthenticated: true, isLoading: false })
          return { success: true }
        } catch (error) {
          set({ isLoading: false })
          const message = error.response?.data?.detail || 'Login failed'
          return { success: false, error: message }
        }
      },

      register: async (userData) => {
        set({ isLoading: true })
        try {
          await authAPI.register(userData)
          set({ isLoading: false })
          return { success: true }
        } catch (error) {
          set({ isLoading: false })
          const message = error.response?.data?.detail || 'Registration failed'
          return { success: false, error: message }
        }
      },

      logout: async () => {
        try {
          await authAPI.logout()
        } catch (_) {
          // Logout API call failing shouldn't block clearing local session state below
        }
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
        set({ user: null, isAuthenticated: false })
      },

      fetchMe: async () => {
        try {
          const { data } = await authAPI.me()
          set({ user: data, isAuthenticated: true })
        } catch (_) {
          set({ user: null, isAuthenticated: false })
        }
      },

      // Helpers
      isAdmin: () => get().user?.role === 'admin',
      isAnalyst: () => ['admin', 'analyst'].includes(get().user?.role),
    }),
    {
      name: 'osint-auth',
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
)

export default useAuthStore
