/**
 * OSINT Nexus - Utility Helpers
 * Date formatting, string manipulation, and common helper functions.
 */
import { formatDistanceToNow, format, parseISO } from 'date-fns'

// ── Date / Time ───────────────────────────────────────────────────

export function timeAgo(dateStr) {
  if (!dateStr) return '—'
  try {
    return formatDistanceToNow(parseISO(dateStr), { addSuffix: true })
  } catch {
    return dateStr
  }
}

export function formatDate(dateStr, fmt = 'MMM d, yyyy') {
  if (!dateStr) return '—'
  try {
    return format(parseISO(dateStr), fmt)
  } catch {
    return dateStr
  }
}

export function formatDateTime(dateStr) {
  return formatDate(dateStr, 'MMM d, yyyy HH:mm')
}

// ── Numbers ───────────────────────────────────────────────────────

export function formatBytes(bytes) {
  if (!bytes || bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`
}

export function percentage(value, total, decimals = 1) {
  if (!total || total === 0) return '0%'
  return `${((value / total) * 100).toFixed(decimals)}%`
}

export function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max)
}

// ── Strings ───────────────────────────────────────────────────────

export function truncate(str, maxLen = 60) {
  if (!str) return ''
  return str.length > maxLen ? `${str.slice(0, maxLen)}…` : str
}

export function capitalize(str) {
  if (!str) return ''
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase()
}

export function slugify(str) {
  return str.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]+/g, '')
}

export function initials(name) {
  if (!name) return '?'
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() || '')
    .join('')
}

// ── Validation ────────────────────────────────────────────────────

export function isValidUsername(str) {
  return /^[a-zA-Z0-9._-]{1,100}$/.test(str)
}

export function isValidEmail(str) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str)
}

export function isValidUrl(str) {
  try { new URL(str); return true } catch { return false }
}

// ── Colour utilities ──────────────────────────────────────────────

export const PRIORITY_COLOR = {
  critical: 'text-red-400 bg-red-900/30 border-red-800',
  high:     'text-amber-400 bg-amber-900/30 border-amber-800',
  medium:   'text-blue-400 bg-blue-900/30 border-blue-800',
  low:      'text-slate-400 bg-slate-800 border-slate-700',
}

export const STATUS_COLOR = {
  open:      'text-brand bg-brand/10 border-brand/30',
  active:    'text-blue-400 bg-blue-900/30 border-blue-800',
  on_hold:   'text-amber-400 bg-amber-900/30 border-amber-800',
  closed:    'text-slate-500 bg-slate-800 border-slate-700',
  archived:  'text-slate-600 bg-slate-900 border-slate-800',
  pending:   'text-amber-400 bg-amber-900/30 border-amber-800',
  running:   'text-blue-400 bg-blue-900/30 border-blue-800',
  found:     'text-brand bg-brand/10 border-brand/30',
  not_found: 'text-slate-500 bg-slate-800 border-slate-700',
  error:     'text-red-400 bg-red-900/30 border-red-800',
  completed: 'text-brand bg-brand/10 border-brand/30',
  failed:    'text-red-400 bg-red-900/30 border-red-800',
  generating:'text-blue-400 bg-blue-900/30 border-blue-800',
}

// ── CSV export ────────────────────────────────────────────────────

export function downloadCSV(rows, filename = 'export.csv') {
  const csv = rows.map((r) => r.map((cell) => `"${String(cell ?? '').replace(/"/g, '""')}"`).join(',')).join('\n')
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  const url  = URL.createObjectURL(blob)
  const a    = Object.assign(document.createElement('a'), { href: url, download: filename })
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

// ── Clipboard ─────────────────────────────────────────────────────

export async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    return false
  }
}

// ── Error message extraction ──────────────────────────────────────

export function getErrorMessage(error) {
  return (
    error?.response?.data?.detail ||
    error?.message ||
    'An unexpected error occurred'
  )
}

// ── Query string helpers ──────────────────────────────────────────

export function buildQueryString(params) {
  const q = new URLSearchParams()
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') q.set(k, String(v))
  })
  return q.toString() ? `?${q.toString()}` : ''
}
