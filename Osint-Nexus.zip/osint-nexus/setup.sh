#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
#  OSINT Nexus — One-command Docker setup
# ════════════════════════════════════════════════════════════════
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}[NEXUS]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC}  $1"; }
err()  { echo -e "${RED}[ERROR]${NC} $1"; }

log "🔍 OSINT Nexus Setup"

# Ensure Docker is available
command -v docker >/dev/null 2>&1     || { err "Docker not found"; exit 1; }
docker compose version >/dev/null 2>&1 || { err "Docker Compose v2 not found"; exit 1; }

# Create .env from example if absent
if [ ! -f .env ]; then
  cp .env.example .env
  # Auto-generate SECRET_KEY
  if command -v openssl >/dev/null 2>&1; then
    SECRET=$(openssl rand -hex 32)
  else
    SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
  fi
  # Replace placeholder (works on both GNU and BSD sed)
  sed -i.bak "s/CHANGE_ME_min_32_chars_random_hex/$SECRET/" .env
  rm -f .env.bak
  warn ".env created with a random SECRET_KEY."
  warn "EDIT .env and change all CHANGE_ME passwords before production use."
  echo ""
fi

log "Building Docker images (this may take 2–5 minutes first time)..."
docker compose build

log "Starting services..."
docker compose up -d

log "Waiting for PostgreSQL to be healthy..."
RETRIES=20
until docker compose exec postgres pg_isready -U "${POSTGRES_USER:-osint}" >/dev/null 2>&1; do
  RETRIES=$((RETRIES-1))
  [ $RETRIES -eq 0 ] && { err "PostgreSQL never became ready"; docker compose logs postgres; exit 1; }
  sleep 3
done
log "PostgreSQL ready"

log "Waiting for backend to pass health check..."
RETRIES=20
until curl -sf http://localhost:8000/api/v1/health >/dev/null 2>&1; do
  RETRIES=$((RETRIES-1))
  [ $RETRIES -eq 0 ] && { err "Backend never became healthy"; docker compose logs backend; exit 1; }
  sleep 4
done
log "Backend healthy"

log "Running Alembic migrations..."
docker compose exec backend alembic upgrade head

echo ""
log "✅ OSINT Nexus is running!"
echo ""
echo "  🖥  Frontend:   http://localhost:3000"
echo "  🌐  Gateway:    http://localhost"
echo "  📚  API Docs:   http://localhost:8000/api/v1/docs"
echo "  🗄  Neo4j:      http://localhost:7474"
echo "  ❤  Health:     http://localhost:8000/api/v1/health"
echo ""
echo "  👤  Register at http://localhost:3000/register"
echo "      (first account is automatically Admin)"
echo ""
echo "  ℹ  Load demo data: make seed"
echo "  ℹ  View logs:      make logs"
echo "  ℹ  Stop:           make down"
echo ""
